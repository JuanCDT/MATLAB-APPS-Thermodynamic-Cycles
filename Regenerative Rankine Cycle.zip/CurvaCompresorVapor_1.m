function valores=CurvaCompresorVapor_1(P_Inicial,rp, T_Inicial, eficiencia,  N_Puntos)
    

    presiones= linspace(P_Inicial,P_Inicial*rp,N_Puntos);  % en bar (para diagramas T-s y se han de introducir en bar)
  
    temperaturas=ones(1,N_Puntos);
    entropias=ones(1,N_Puntos);
    entalpias=ones(1,N_Puntos);
    volumen=ones(1,N_Puntos);
    
    % Valores iniciales
    
    temperaturas(1)=T_Inicial;
    entropias(1)=CoolProp.PropsSI('S', 'P',P_Inicial*1E5, 'T', T_Inicial, 'water')/1000;
    entalpias(1)=CoolProp.PropsSI('H', 'P',P_Inicial*1E5, 'T', T_Inicial,  'water')/1000;
    volumen(1)=CoolProp.PropsSI('D', 'P',P_Inicial*1E5, 'T',T_Inicial,  'water')^-1;
        
    % Compresor ideal 
    entropias=ones(1,N_Puntos)*entropias(1);
    for i=2:N_Puntos
        temperaturas(i)=CoolProp.PropsSI('T', 'P',presiones(i)*1E5, 'S', entropias(1)*1E3, 'water'); % en kJ/kg�K
        volumen(i)=CoolProp.PropsSI('D', 'P',presiones(i)*1E5, 'S', entropias(1)*1E3, 'water')^-1;  % en m3/kg
        entalpias(i)=CoolProp.PropsSI('H', 'P',presiones(i)*1E5, 'S', entropias(1)*1E3, 'water')/1000; % en kJ/kg  
    end
    
    
    % Compresor real
    
    if eficiencia~=1
        entapias_ideales=entalpias;        
        for i=2:N_Puntos
            entalpias(i)=entapias_ideales(1)+(entapias_ideales(i)-entapias_ideales(1))/eficiencia;            
            temperaturas(i)=CoolProp.PropsSI('T', 'P',presiones(i)*1E5, 'H', entalpias(i)*1E3, 'water'); % en kJ/kg�K
            volumen(i)=CoolProp.PropsSI('D', 'P',presiones(i)*1E5, 'H', entalpias(i)*1E3, 'water')^-1;  % en m3/kg
            entropias(i)=CoolProp.PropsSI('S', 'P',presiones(i)*1E5, 'H', entalpias(i)*1E3, 'water')/1000; % en kJ/kg 
        end
    
        
    end
     
    
    valores=struct();
    valores.presiones=presiones;
    valores.entalpias=entalpias;
    valores.volumen=volumen;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;
end