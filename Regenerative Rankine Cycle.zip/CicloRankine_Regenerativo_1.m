classdef CicloRankine_Regenerativo_1 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                        matlab.ui.Figure
        TabGroup                        matlab.ui.container.TabGroup
        DatosInicialesTab               matlab.ui.container.Tab
        TextArea_3                      matlab.ui.control.TextArea
        UITable_DatosIniciales          matlab.ui.control.Table
        TextArea_4                      matlab.ui.control.TextArea
        UIAxes_PH                       matlab.ui.control.UIAxes
        UIAxes_TS                       matlab.ui.control.UIAxes
        UIAxes_PV                       matlab.ui.control.UIAxes
        Image                           matlab.ui.control.Image
        EjecutarButton_2                matlab.ui.control.Button
        MostrargrficosButton            matlab.ui.control.Button
        MostrarresultadosButton         matlab.ui.control.Button
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        ExportarresultadosButton        matlab.ui.control.Button
        UITable_Eficiencias             matlab.ui.control.Table
        ResultadosTab                   matlab.ui.container.Tab
        UITable_Resultados              matlab.ui.control.Table
        TextArea_5                      matlab.ui.control.TextArea
        UITable_Resultados_2            matlab.ui.control.Table
        Image2                          matlab.ui.control.Image
        UITable_Procesos                matlab.ui.control.Table
        TextArea_8                      matlab.ui.control.TextArea
        UITable_Resultados_TituloVapor  matlab.ui.control.Table
        UITable_Resultados_Masas        matlab.ui.control.Table
    end

    
    properties (Access = private)        
       
        parametros=[];
        fluido='water';
        Tc=647.096; % Temp. cr�tica del agua en K
            
        Punto1=[], Punto2=[]; Punto3=[]; Punto4=[];Punto5=[];Punto6=[];Punto7=[];  tituloVapor=[];
        solucion=[];x3=[]       
        
        eficienciaBombas=[];eficienciaTurbina_1=[];eficienciaTurbina_2=[];
        w_bomba1=[];w_bomba2=[];w_turbina1=[];w_turbina2=[];q_caldera=[];q_condensador=[]; Eficiencia_termica=[];
        PotenciaNeta=[];
        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)           
            
            app.Punto1=app.solucion.Punto1;
            app.Punto2=app.solucion.Punto2;
            app.Punto3=app.solucion.Punto3;
            app.Punto4=app.solucion.Punto4;
            app.Punto5=app.solucion.Punto5;
            app.Punto6=app.solucion.Punto6;
            app.Punto7=app.solucion.Punto7;
            
            app.tituloVapor=app.Punto7(6);
            
            % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K) (y X4 para Punto4). 
            
            ParametrosCiclo=app.solucion.ParametrosCiclo;
            
            % w_bomba1,w_bomba2,w_turbina1,w_turbina2,q_caldera,q_condensador,eficiencia_termica,PotenciaNeta
            
            app.w_bomba1=ParametrosCiclo(1);
            app.w_bomba2=ParametrosCiclo(2);
            app.w_turbina1=ParametrosCiclo(3);
            app.w_turbina2=ParametrosCiclo(4);
            app.q_caldera=ParametrosCiclo(5);
            app.q_condensador=ParametrosCiclo(6);
            app.Eficiencia_termica=ParametrosCiclo(7);
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)           
                        
            % Valores propiedades a lo largo de los procesos            
            % Puntos del proceso
            
           Entalpias=[app.Punto1(3),app.Punto2(3),app.Punto3(3),app.Punto4(3),app.Punto5(3),app.Punto6(3),app.Punto7(3)];
           Temperaturas=[app.Punto1(1),app.Punto2(1),app.Punto3(1),app.Punto4(1),app.Punto5(1),app.Punto6(1),app.Punto7(1)];
           Presiones=[app.Punto1(2),app.Punto2(2),app.Punto3(2),app.Punto4(2),app.Punto5(2),app.Punto6(2),app.Punto7(2)];
           Volumenes=[app.Punto1(4),app.Punto2(4),app.Punto3(4),app.Punto4(4),app.Punto5(4),app.Punto6(4),app.Punto7(4)];
           Entropias=[app.Punto1(5),app.Punto2(5),app.Punto3(5),app.Punto4(5),app.Punto5(5),app.Punto6(5),app.Punto7(5)];
           
           % Domo saturacion
           %T_Final=app.Punto3(1)+5;
           T_Inicial=app.Punto1(1)-5;
           
           valores_VaporSaturado=CurvaVaporSaturado(T_Inicial, app.Tc, 500);
           valores_LiquidoSaturado=CurvaLiquidoSaturado(T_Inicial, app.Tc, 500);
           
            h_VaporSaturado=valores_VaporSaturado.entalpias;
            p_VaporSaturado=valores_VaporSaturado.presiones;
            v_VaporSaturado=valores_VaporSaturado.volumen;
            s_VaporSaturado=valores_VaporSaturado.entropias;
            T_VaporSaturado=valores_VaporSaturado.temperaturas;
            
            h_LiquidoSaturado=valores_LiquidoSaturado.entalpias;
            p_LiquidoSaturado=valores_LiquidoSaturado.presiones;
            v_LiquidoSaturado=valores_LiquidoSaturado.volumen;
            s_LiquidoSaturado=valores_LiquidoSaturado.entropias;
            T_LiquidoSaturado=valores_LiquidoSaturado.temperaturas;
            
            p1=app.parametros(1);
            p2=app.parametros(2);
            p4=app.parametros(3);
            
            
            rp1=p4/p2;
            rp2=p2/p1;
            
            % Proceso 1 - Compresi�n 1
            valoresProceso1=CurvaCompresorVapor(app.Punto1(2),rp2, app.Punto1(1), app.eficienciaBombas,  200);        
            
            h_Proceso1=valoresProceso1.entalpias;
            p_Proceso1=valoresProceso1.presiones;
            v_Proceso1=valoresProceso1.volumen;
            s_Proceso1=valoresProceso1.entropias;
            T_Proceso1=valoresProceso1.temperaturas;
            
            
            % Proceso 2 - mezclador
            valoresProceso2_1=CurvaIsobara(app.Punto2(3),app.Punto2(2), app.Punto3(3), 500);         
            
            h_Proceso2_1=valoresProceso2_1.entalpias;
            p_Proceso2_1=valoresProceso2_1.presiones;
            v_Proceso2_1=valoresProceso2_1.volumen;
            s_Proceso2_1=valoresProceso2_1.entropias;
            T_Proceso2_1=valoresProceso2_1.temperaturas;
            
            valoresProceso2_2=CurvaIsobara(app.Punto6(3),app.Punto6(2), app.Punto3(3), 500);         
            
            h_Proceso2_2=valoresProceso2_2.entalpias;
            p_Proceso2_2=valoresProceso2_2.presiones;
            v_Proceso2_2=valoresProceso2_2.volumen;
            s_Proceso2_2=valoresProceso2_2.entropias;
            T_Proceso2_2=valoresProceso2_2.temperaturas;
            
            
            % Proceso 3 - Compresi�n 2
            
            
            if app.x3==0
                valoresProceso3=CurvaCompresorVapor(app.Punto3(2),rp1, app.Punto3(1), app.eficienciaBombas,  200); 
            else
                valoresProceso3=CurvaCompresorVapor_1(app.Punto3(2),rp1, app.Punto3(1), app.eficienciaBombas,  200); 
            end
            
            h_Proceso3=valoresProceso3.entalpias;
            p_Proceso3=valoresProceso3.presiones;
            v_Proceso3=valoresProceso3.volumen;
            s_Proceso3=valoresProceso3.entropias;
            T_Proceso3=valoresProceso3.temperaturas;
            
            % Proceso 4 - caldera            
            valoresProceso4=CurvaIsobara(app.Punto4(3),app.Punto4(2), app.Punto5(3), 500);                                     

            h_Proceso4=valoresProceso4.entalpias;
            p_Proceso4=valoresProceso4.presiones;
            v_Proceso4=valoresProceso4.volumen;
            s_Proceso4=valoresProceso4.entropias;
            T_Proceso4=valoresProceso4.temperaturas;
            
            
                        
            % Proceso 5 - Expansion  1
            valoresProceso5=CurvaExpansionVapor(app.Punto5(2),1/rp1, app.Punto5(1), app.eficienciaTurbina_1,  200);                       
                        
            h_Proceso5=valoresProceso5.entalpias;
            p_Proceso5=valoresProceso5.presiones;
            v_Proceso5=valoresProceso5.volumen;
            s_Proceso5=valoresProceso5.entropias;
            T_Proceso5=valoresProceso5.temperaturas;
            
          
                                    
            % Proceso 6 - Expansion  2

            valoresProceso6=CurvaExpansionVapor(app.Punto6(2),1/rp2, app.Punto6(1), app.eficienciaTurbina_2,  200);                        
                        
            h_Proceso6=valoresProceso6.entalpias;
            p_Proceso6=valoresProceso6.presiones;
            v_Proceso6=valoresProceso6.volumen;
            s_Proceso6=valoresProceso6.entropias;
            T_Proceso6=valoresProceso6.temperaturas;
            
            
            % Proceso 7 - Condensador            
            valoresProceso7=CurvaIsobara(app.Punto7(3),app.Punto7(2), app.Punto1(3), 200);                
    
            h_Proceso7=valoresProceso7.entalpias;
            p_Proceso7=valoresProceso7.presiones;
            v_Proceso7=valoresProceso7.volumen;
            s_Proceso7=valoresProceso7.entropias;
            T_Proceso7=valoresProceso7.temperaturas;
            
            % Diagrama p-h
            hold(app.UIAxes_PH,'on');
            
            app.UIAxes_PH.YScale = 'log';
            
            %domo
            plot(app.UIAxes_PH,  h_LiquidoSaturado,p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
                        
            % puntos y procesos
            plot(app.UIAxes_PH, Entalpias, Presiones,'color','r','Marker','o','LineStyle','none');
            plot(app.UIAxes_PH, h_Proceso1, p_Proceso1,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso2_1, p_Proceso2_1,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso2_2, p_Proceso2_2,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso3, p_Proceso3,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso4, p_Proceso4,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso5, p_Proceso5,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso6, p_Proceso6,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso7, p_Proceso7,'color','r','Marker','none','LineStyle','-');

            hold(app.UIAxes_PH,'off');
            
            app.UIAxes_PH.XLimMode = 'auto';
            app.UIAxes_PH.YLimMode = 'auto';
 
            % Diagrama p-v
     
            
            hold(app.UIAxes_PV,'on');
            
            app.UIAxes_PV.YScale = 'log';
            app.UIAxes_PV.XScale = 'log';
            
%             % domo
            plot(app.UIAxes_PV, v_LiquidoSaturado, p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
            
            
            % puntos y procesos
            plot(app.UIAxes_PV,Volumenes, Presiones,'color','b','Marker','o','LineStyle','none');
            plot(app.UIAxes_PV, v_Proceso1, p_Proceso1,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso2_1, p_Proceso2_1,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso2_2, p_Proceso2_2,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso3, p_Proceso3,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso4, p_Proceso4,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso5, p_Proceso5,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso6, p_Proceso6,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso7, p_Proceso7,'color','b','Marker','none','LineStyle','-');

            hold(app.UIAxes_PV,'off');
            
            app.UIAxes_PV.XLimMode = 'auto';
            app.UIAxes_PV.YLimMode = 'auto';

            
            % Diagrama T-s
            
           hold(app.UIAxes_TS,'on');
           
           
%             
%             % domo
            plot(app.UIAxes_TS, s_LiquidoSaturado, T_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_VaporSaturado, T_VaporSaturado,'color','k','Marker','none','LineStyle','-');
                        
            % puntos y procesos
            plot(app.UIAxes_TS, Entropias,Temperaturas,'color','g','Marker','o','LineStyle','none');
            plot(app.UIAxes_TS, s_Proceso1, T_Proceso1,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso2_1, T_Proceso2_1,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso2_2, T_Proceso2_2,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso3, T_Proceso3,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso4, T_Proceso4,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso5, T_Proceso5,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso6, T_Proceso6,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso7, T_Proceso7,'color','g','Marker','none','LineStyle','-');


            hold(app.UIAxes_TS,'off');
             
            app.UIAxes_TS.XLimMode = 'auto';
            app.UIAxes_TS.YLimMode = 'auto';

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UITable_Procesos.Data={'1-2','Compression 1';'2,6-3','Open Feedwater Heater (FWH)';...
               '3-4','Compression 2';'4-5','Boiler: heat-addition';'5-6','Expansion 1';'6-7','Expansion 2';...
               '7-1','Condenser: heat-rejection'};
           
            app.UITable_Procesos.RowName={};          
                        
            while 1
                app.parametros= generadorParametrosRankineRegenerativo(); 
    
                if app.parametros(6)~=-10
                    break
                end
            end
    
                        
%             CeldaParametros=num2cell(app.parametros);
%             [T1,p1,X4,h3,p3,T4,rp,app.eficienciaCompresor,app.eficienciaTurbina]=deal(CeldaParametros{:});
%             
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
                        
        end

        % Button pushed function: EjecutarButton_2
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
            app.UITable_Resultados.Data={''};
            app.UITable_Resultados_2.Data={''};     
            app.UITable_Resultados_TituloVapor.Data={''};
            while 1
                app.parametros= generadorParametrosRankineRegenerativo();      
            
            
            
                CeldaParametros=num2cell(app.parametros);
            
            
                [p1,p2,p4,T5,T3,app.x3,~,~,~,~,app.eficienciaBombas,app.eficienciaTurbina_1,...
                    app.eficienciaTurbina_2]=deal(CeldaParametros{:});
    
                if app.x3~=-10
                    break
                end
            end
    
        app.solucion=CicloRankine_Regenerativo(app.parametros);
            if app.x3==-1

                app.UITable_DatosIniciales.Data={'Sat. Liq.';p1;T5+273.15;p4;p2;T3+273.15};
                % app.UITable_DatosIniciales.ColumnName = {'Variable'; 'Valor'};
                app.UITable_DatosIniciales.RowName={'State at compressor 1 inlet','Pump 1 inlet pressure 1 (bar)',...
                   'Turbine 1 inlet temperature (K)','Turbine 1 inlet pressure 1 (bar)', ...
                   'Turbine 1 outlet pressure 1(bar)','FWH inlet temperature  (K)'};
            else
                app.UITable_DatosIniciales.Data={'Sat. Liq.';p1;T5+273.15;p4;p2;'L�q. Sat.'};
                % app.UITable_DatosIniciales.ColumnName = {'Variable'; 'Valor'};
                app.UITable_DatosIniciales.RowName={'State at compressor 1 inlet','Pump 1 inlet pressure 1 (bar)',...
                   'Turbine 1 inlet temperature (K)','Turbine 1 inlet pressure 1 (bar)', ...
                   'Turbine 1 outlet pressure 1(bar)','State at FWH outlet'};
                
            end
            
            app.PotenciaNeta=app.solucion.ParametrosCiclo(end)*1E-3; % Potencia neta en MW
            
            app.UITable_Eficiencias.Data={app.eficienciaBombas,app.eficienciaTurbina_1,app.eficienciaTurbina_2,app.PotenciaNeta};

        end

        % Button pushed function: MostrargrficosButton
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end

        % Button pushed function: MostrarresultadosButton
        function MostrarresultadosButtonPushed(app, ~)
            MostrargrficosButtonPushed(app, 'push');
            format shortG        
            
            app.UITable_Resultados.Data={'1',app.Punto1(2),app.Punto1(1), app.Punto1(3),app.Punto1(5),app.Punto1(4);...
            '2',app.Punto2(2),app.Punto2(1),app.Punto2(3),app.Punto2(5),app.Punto2(4);...
           '3',app.Punto3(2),app.Punto3(1), app.Punto3(3),app.Punto3(5),app.Punto3(4);...
            '4',app.Punto4(2),app.Punto4(1), app.Punto4(3),app.Punto4(5),app.Punto4(4);...
            '5',app.Punto5(2),app.Punto5(1), app.Punto5(3),app.Punto5(5),app.Punto5(4);...
            '6',app.Punto6(2),app.Punto6(1), app.Punto6(3),app.Punto6(5),app.Punto6(4)
            '7',app.Punto7(2),app.Punto7(1), app.Punto7(3),app.Punto7(5),app.Punto7(4)};

            app.UITable_Resultados_2.Data={app.w_bomba1;app.w_bomba2;app.w_turbina1; app.w_turbina2; app.q_caldera;...
                app.q_condensador; app.Eficiencia_termica};
            
                        
            app.UITable_Resultados_TituloVapor.Data={app.tituloVapor};
            
            app.UITable_Resultados_Masas.Data={'Total Mass Flowrate',app.solucion.Masas(1);'Bleed steam Flowrate',...
                app.solucion.Masas(2);'Turbine 2 Inlet Flowrate',app.solucion.Masas(3)};
 
 
            
            
        end

        % Button pushed function: ExportarresultadosButton
        function ExportarresultadosButtonPushed(app, ~)
            
            Data=get(app.UITable_Resultados,'Data');
            ColumnName=get(app.UITable_Resultados,'ColumnName');
            ColumnName=ColumnName';
            NewData=num2cell(Data);
            Datos1 = cell2table(NewData,'VariableNames',ColumnName);
            writetable(Datos1,'Datos del ciclo de Rankine con Regeneracion.xls','Sheet','Datos Procesos');
            
            Data1=get(app.UITable_Resultados_2,'Data');
            ColumnName1=get(app.UITable_Resultados_2,'ColumnName');
            ColumnName1=ColumnName1';
            RowName1=get(app.UITable_Resultados_2,'RowName');
            RowName1=RowName1';
            NewData1=num2cell(Data1);
            Datos2= cell2table(NewData1,'VariableNames',ColumnName1,'RowNames',RowName1);
            writetable(Datos2,'Datos del ciclo de Rankine con Regeneracion.xls','Sheet','Datos ciclo','WriteRowNames',true);
            
            Data2=get(app.UITable_Resultados_Masas,'Data');
            ColumnName2=get(app.UITable_Resultados_Masas,'ColumnName');
            ColumnName2=ColumnName2';
            NewData2=num2cell(Data2);
            ColumnName2{1}=' ';
            Datos3 = cell2table(NewData2,'VariableNames',ColumnName2);
            writetable(Datos3,'Datos del ciclo de Rankine con Regeneracion.xls','Sheet','Caudales masicos');


        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 952 734];
            app.UIFigure.Name = 'Regenerative Rankine Cycle';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 1 952 734];

            % Create DatosInicialesTab
            app.DatosInicialesTab = uitab(app.TabGroup);
            app.DatosInicialesTab.Title = 'Initial values';

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.DatosInicialesTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [42 639 372 30];
            app.TextArea_3.Value = {'Regenerative Rankine Cycle'};

            % Create UITable_DatosIniciales
            app.UITable_DatosIniciales = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales.ColumnName = {''; 'Value'};
            app.UITable_DatosIniciales.RowName = {''};
            app.UITable_DatosIniciales.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales.FontWeight = 'bold';
            app.UITable_DatosIniciales.Position = [16 387 455 158];

            % Create TextArea_4
            app.TextArea_4 = uitextarea(app.DatosInicialesTab);
            app.TextArea_4.HorizontalAlignment = 'center';
            app.TextArea_4.FontSize = 18;
            app.TextArea_4.FontWeight = 'bold';
            app.TextArea_4.Position = [64 560 327 30];
            app.TextArea_4.Value = {'Initial values'};

            % Create UIAxes_PH
            app.UIAxes_PH = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH, 'Diagram p-h')
            xlabel(app.UIAxes_PH, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH, 'Pressure (bar)')
            app.UIAxes_PH.PlotBoxAspectRatio = [1.92307692307692 1 1];
            app.UIAxes_PH.Position = [568 473 362 220];

            % Create UIAxes_TS
            app.UIAxes_TS = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS, 'Diagram T-s')
            xlabel(app.UIAxes_TS, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS, 'Temperature (K)')
            app.UIAxes_TS.Position = [568 250 362 220];

            % Create UIAxes_PV
            app.UIAxes_PV = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV, 'Diagram p-v')
            xlabel(app.UIAxes_PV, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV, 'Pressure (bar)')
            app.UIAxes_PV.Position = [568 26 362 220];

            % Create Image
            app.Image = uiimage(app.DatosInicialesTab);
            app.Image.Position = [27 26 182 148];
            app.Image.ImageSource = 'Pollo Transparente.gif';

            % Create EjecutarButton_2
            app.EjecutarButton_2 = uibutton(app.DatosInicialesTab, 'push');
            app.EjecutarButton_2.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton_2.Position = [177 609 100 22];
            app.EjecutarButton_2.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [57 273 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [281 273 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Position = [226 110 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [226 77 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Steam power cycles';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [216 42 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create ExportarresultadosButton
            app.ExportarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.ExportarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @ExportarresultadosButtonPushed, true);
            app.ExportarresultadosButton.Position = [159 240 120 22];
            app.ExportarresultadosButton.Text = 'Export results';

            % Create UITable_Eficiencias
            app.UITable_Eficiencias = uitable(app.DatosInicialesTab);
            app.UITable_Eficiencias.ColumnName = {'Efic. pumps'; 'Efic. turbine 1'; 'Efic. turbine 2'; 'Net power (MW)'};
            app.UITable_Eficiencias.RowName = {};
            app.UITable_Eficiencias.ForegroundColor = [0.4667 0.6745 0.1882];
            app.UITable_Eficiencias.FontWeight = 'bold';
            app.UITable_Eficiencias.Position = [17 321 419 48];

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Results';

            % Create UITable_Resultados
            app.UITable_Resultados = uitable(app.ResultadosTab);
            app.UITable_Resultados.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados.RowName = {};
            app.UITable_Resultados.Position = [18 475 626 180];

            % Create TextArea_5
            app.TextArea_5 = uitextarea(app.ResultadosTab);
            app.TextArea_5.HorizontalAlignment = 'center';
            app.TextArea_5.FontSize = 18;
            app.TextArea_5.FontWeight = 'bold';
            app.TextArea_5.Position = [150 662 327 30];
            app.TextArea_5.Value = {'Results of the cycle'};

            % Create UITable_Resultados_2
            app.UITable_Resultados_2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2.ColumnName = {'Heat and work exchanged'};
            app.UITable_Resultados_2.RowName = {'w (pump 1) (kJ/kg)'; 'w (pump 2) (kJ/kg)'; 'w (turbine 1) (kJ/kg)'; 'w (turbine 2) (kJ/kg)'; 'q (boiler) (kJ/kg)'; 'q (condenser) (kJ/kg)'; 'Thermal efficiency'};
            app.UITable_Resultados_2.Position = [18 283 373 181];

            % Create Image2
            app.Image2 = uiimage(app.ResultadosTab);
            % app.Image2.Position = [528 18 390 312];
            app.Image2.Position = [480 18 480 450];
            app.Image2.ScaleMethod = 'fit';
            app.Image2.ImageSource = 'Rankine regenerativo.png';

            % Create UITable_Procesos
            app.UITable_Procesos = uitable(app.ResultadosTab);
            app.UITable_Procesos.ColumnName = {'Process'; 'Description'};
            app.UITable_Procesos.ColumnWidth = {60, 'auto'};
            app.UITable_Procesos.RowName = {''};
            app.UITable_Procesos.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Procesos.FontWeight = 'bold';
            app.UITable_Procesos.FontSize = 14;
            app.UITable_Procesos.Position = [24 18 440 203];

            % Create TextArea_8
            app.TextArea_8 = uitextarea(app.ResultadosTab);
            app.TextArea_8.HorizontalAlignment = 'center';
            app.TextArea_8.FontSize = 18;
            app.TextArea_8.FontWeight = 'bold';
            app.TextArea_8.Position = [32 229 327 30];
            app.TextArea_8.Value = {'Processes'};

            % Create UITable_Resultados_TituloVapor
            app.UITable_Resultados_TituloVapor = uitable(app.ResultadosTab);
            app.UITable_Resultados_TituloVapor.ColumnName = {'Quality - Turbine 2 outlet'};
            app.UITable_Resultados_TituloVapor.RowName = {};
            app.UITable_Resultados_TituloVapor.Position = [663 605 229 50];

            % Create UITable_Resultados_Masas
            app.UITable_Resultados_Masas = uitable(app.ResultadosTab);
            app.UITable_Resultados_Masas.ColumnName = {''; 'Mass Flowrate (kg/s)'};
            app.UITable_Resultados_Masas.RowName = {};
            app.UITable_Resultados_Masas.Position = [663 475 280 92];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = CicloRankine_Regenerativo_1

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end