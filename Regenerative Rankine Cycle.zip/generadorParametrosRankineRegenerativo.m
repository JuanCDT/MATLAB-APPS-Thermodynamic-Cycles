function [parametros]=generadorParametrosRankineRegenerativo()


    fluido='water';
    
    a=randi([0 1]);b=randi([0 1]); c=randi([0 1]);
    if a && b&& c % todos ideales
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=1;
        eficienciaCompresor=1;
    elseif a % turbina 1 ideal
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=random('Uniform',0.7, 0.95);
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif b % compresor ideal
        eficienciaTurbina_1 = random('Uniform',0.7, 0.95);
        eficienciaTurbina_2=random('Uniform',0.7, 0.95);
        eficienciaCompresor = 1;
    elseif c % turbina 2 ideal
        eficienciaTurbina_2=1;
        eficienciaTurbina_1=random('Uniform',0.7, 0.95);
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif a && b % turbina 1 y compresor ideales
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=random('Uniform',0.7, 0.95);
        eficienciaCompresor=1;
    elseif b && c % turbina 2 y turbina 2 ideales
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=1;
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif a && c % turbina 2 y compresor ideales
        eficienciaTurbina_1=random('Uniform',0.7, 0.95);
        eficienciaTurbina_2=1;
        eficienciaCompresor=1;
    else % real
        eficienciaTurbina_1 = random('Uniform',0.7, 0.95);
        eficienciaTurbina_2 = random('Uniform',0.7, 0.95);
        eficienciaCompresor = random('Uniform',0.7, 0.95);
    end
    
    % Define si el problema es con subenfriamiento, sobrecalentamiento o
    % ambos casos
       % Genera las condiciones a la entrada del compresor, a las turbina 1
       % y a la turbina 2
    iter=0;
    while 1 && iter<1000
    p1 = round(random('Uniform',0.06,0.1),3);  % En bar, se convierte en Pa multiplicando por 1E5
    p4 = round(random('Uniform',50,80),3); % En bar, se convierte en Pa multiplicando por 1E5
    p2 = round(random('Uniform',10,30),3); % En bar, se convierte en Pa multiplicando por 1E5
    T5= round(random('Uniform',450,600),3); % En �C
%     rp_1 = p2/p4; % Relaci�n de presi�n primera expansi�n
%     rp_2 = p4/p1; % Relaci�n de presi�n segunda expansi�n
%     
    

    % C�lculo 6
    s5=CoolProp.PropsSI('S', 'P', p4*1E5, 'T', T5+273.15, fluido)/1000;% kJ/kg�K
    h5=CoolProp.PropsSI('H', 'P', p4*1E5, 'T', T5+273.15, fluido)/1000;% kJ/kg
    s6_a=s5;
    p6=p2; % bar
    h6_a= CoolProp.PropsSI('H','S',s6_a*1E3,'P',p6*1E5,'Water')*1E-3; % kJ/kg
    w_turbina1_a=h5-h6_a;
    w_turbina1=eficienciaTurbina_1*w_turbina1_a;
    h6=h5-w_turbina1;
    s6=CoolProp.PropsSI('S', 'P', p6*1E5, 'H', h6*1E3, fluido)/1000;% kJ/kg�K
    
    % C�lculo entalp�as y trabajo en la turbina 2
    s7_a=s6;
    h7_a= CoolProp.PropsSI('H','S',s7_a*1E3,'P',p1*1E5,'Water')*1E-3; % kJ/kg
    w_turbina2_a=h6-h7_a;
    w_turbina2=eficienciaTurbina_2*w_turbina2_a;
    h7=h6-w_turbina2;
    x7= CoolProp.PropsSI('Q', 'P', p1*1E5, 'H', h7*1E3, 'water');% t�tulo
    
    
    % C�lculo 2
    s1=CoolProp.PropsSI('S', 'P', p1*1E5, 'Q', 0, fluido)/1000;% kJ/kg�K
    h1=CoolProp.PropsSI('H', 'P', p1*1E5, 'Q', 0, fluido)/1000;% kJ/kg
    s2_a=s1;
    h2_a= CoolProp.PropsSI('H','S',s2_a*1E3,'P',p2*1E5,'Water')*1E-3; % kJ/kg
    w_bomba1_a=h2_a-h1;
    w_bomba1=w_bomba1_a/eficienciaCompresor;
    h2=h1+w_bomba1;

    T3_sat =CoolProp.PropsSI('T', 'P', p2*1E5, 'Q', 0, fluido)-273.15 ;% �C Temperatura de saturaci�n
    h3_sat=CoolProp.PropsSI('H', 'P', p2*1E5, 'Q', 0, fluido)/1000;% kJ/kg
    
    
    % Balance ent�lpico
    w2=(h3_sat-h6)/(h2-h6);  % fracci�n m�sica de vapor en la segunda expansi�n
    w1=1-w2;
    iter=iter+1;
    
    if (w1<0.1 || w1>0.3) || (x7>0.97 || x7<0.9)
        
        continue
    end  
       
    d=randi([0 1]);
       
    if d==1 % l�quido saturado
        T3=T3_sat; x3=0;
        h3=h3_sat;
    else % l�quido subenfriado
        T3=T3_sat*random('Uniform',0.75,0.85);
        h3=CoolProp.PropsSI('H', 'P', p2*1E5, 'T', T3+273.15, fluido)/1000;% kJ/kg
        x3=-1;
    end
    
    w2=(h3-h6)/(h2-h6);  % fracci�n m�sica de vapor en la segunda expansi�n
    break
        
        
    end
    
        
    m=round(random('Uniform',1,50),1); % masa total del ciclo
    m2=m*w2; % masa de vapor en la segunda expansi�n 
    m1=m*w1;  % masa de vapor extra�da hac�a el mezclador
              
    
    if iter==1000
        T3=0;
        x3=-10;
    end
    parametros=[p1,p2,p4,T5,T3,x3,x7,m,m1,m2,eficienciaCompresor,eficienciaTurbina_1,...
        eficienciaTurbina_2] ;

end