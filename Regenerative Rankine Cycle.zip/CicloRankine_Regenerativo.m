function [solucion]=CicloRankine_Regenerativo(parametros)
    
    solucion=struct;
    
     % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K).  
    
    CeldaParametros=num2cell(parametros);
    [p1,p2,p4,T5,T3,x3,x7,m,m1,m2,eficienciaBombas,eficienciaTurbina_1,...
        eficienciaTurbina_2]=deal(CeldaParametros{:});
    
    % Condiciones conocidas
    P1=p1*1E5; % Cambio a Pa
    P2=p2*1E5; % Cambio a Pa
    P4=p4*1E5; % Cambio a Pa
    T5=T5+273.15;
    T3=T3+273.15;
    
    % C�lculo 1
    s1=CoolProp.PropsSI('S', 'Q',0 , 'P', P1, 'water')/1000;
    T1=CoolProp.PropsSI('T', 'Q',0 , 'P', P1, 'water');
    h1= CoolProp.PropsSI('H', 'Q',0 , 'P', P1, 'water')/1000;
    V1= CoolProp.PropsSI('D', 'Q',0 , 'P', P1, 'water')^-1;% en m3/kg
    
    Punto1=[T1,p1,h1,V1,s1];
    solucion.Punto1=Punto1;
    
    % C�lculo 2
    s2_a=s1;
    h2_a= CoolProp.PropsSI('H','S',s2_a*1E3,'P',p2*1E5,'Water')*1E-3; % kJ/kg
    w_bomba1_a=h2_a-h1;
    w_bomba1=w_bomba1_a/eficienciaBombas;
    h2=h1+w_bomba1;
    s2=CoolProp.PropsSI('S', 'H',h2*1E3 , 'P', P2, 'water')/1000;
    T2=CoolProp.PropsSI('T', 'H',h2*1E3 , 'P', P2, 'water');
    V2= CoolProp.PropsSI('D', 'H',h2*1E3 , 'P', P2, 'water')^-1;% en m3/kg
    
    Punto2=[T2,p2,h2,V2,s2];
    solucion.Punto2=Punto2;        

    % C�lculo salida del mezclador   
    if x3==0
        s3=CoolProp.PropsSI('S', 'Q',x3 , 'P', P2, 'water')/1000;
        h3= CoolProp.PropsSI('H', 'Q',x3 , 'P', P2, 'water')/1000;
        V3= CoolProp.PropsSI('D', 'Q',x3 , 'P', P2, 'water')^-1;% en m3/kg
    else
        s3=CoolProp.PropsSI('S', 'T',T3 , 'P', P2, 'water')/1000;
        h3= CoolProp.PropsSI('H', 'T',T3 , 'P', P2, 'water')/1000;
        V3= CoolProp.PropsSI('D', 'T',T3 , 'P', P2, 'water')^-1;% en m3/kg
        
    end

    Punto3=[T3,p2,h3,V3,s3,x3];
    solucion.Punto3=Punto3;
    
    
    % C�lculo salida de la segunda bomba   
    s4_a=s3;
    h4_a= CoolProp.PropsSI('H','S',s4_a*1E3,'P',p4*1E5,'Water')*1E-3; % kJ/kg
    w_bomba2_a=h4_a-h3;
    w_bomba2=w_bomba2_a/eficienciaBombas;
    h4=h3+w_bomba2;
    s4=CoolProp.PropsSI('S', 'H',h4*1E3 , 'P', P4, 'water')/1000;
    T4=CoolProp.PropsSI('T', 'H',h4*1E3 , 'P', P4, 'water');
    V4= CoolProp.PropsSI('D', 'H',h4*1E3 , 'P', P4, 'water')^-1;% en m3/kg
    
    Punto4=[T4,p4,h4,V4,s4];
    solucion.Punto4=Punto4;     
    
    % Calculo calentamiento
    s5=CoolProp.PropsSI('S', 'P',P4 , 'T', T5, 'water')/1000; % en kJ/kg�K
    h5= CoolProp.PropsSI('H', 'P',P4 , 'T', T5, 'water')/1000; % en kJ/kg
    v5= CoolProp.PropsSI('D', 'P',P4 , 'T', T5, 'water')^-1;% en m3/kg

    Punto5=[T5,p4,h5,v5,s5];
    solucion.Punto5=Punto5;

    % C�lculo entalp�as y trabajo en la turbina 1 
    s6_a=s5;
    p6=p2; % bar
    h6_a= CoolProp.PropsSI('H','S',s6_a*1E3,'P',p6*1E5,'Water')*1E-3; % kJ/kg
    w_turbina1_a=h5-h6_a;
    w_turbina1=eficienciaTurbina_1*w_turbina1_a;
    h6=h5-w_turbina1; 
    V6= CoolProp.PropsSI('D', 'P', P2, 'H', h6*1E3, 'water')^-1;% en m3/kg
    T6= CoolProp.PropsSI('T', 'P', P2, 'H', h6*1E3, 'water');% en K 
    s6= CoolProp.PropsSI('S', 'P', P2, 'H', h6*1E3, 'water')/1000; % en kJ/kg�K
    
    Punto6=[T6,p2,h6,V6,s6];
    solucion.Punto6=Punto6;
    
    % C�lculo entalp�as y trabajo en la turbina 2
    s7_a=s6;
    h7_a= CoolProp.PropsSI('H','S',s7_a*1E3,'P',p1*1E5,'Water')*1E-3; % kJ/kg
    w_turbina2_a=h6-h7_a;
    w_turbina2=eficienciaTurbina_2*w_turbina2_a;
    h7=h6-w_turbina2;
    V7= CoolProp.PropsSI('D', 'P', P1, 'Q', x7, 'water')^-1;% en m3/kg
    s7= CoolProp.PropsSI('S', 'P', P1, 'Q', x7, 'water')/1000; % en kJ/kg�K
    T7= CoolProp.PropsSI('T', 'P', P1, 'Q', x7, 'water'); % en �C
    
    Punto7=[T7,p1,h7,V7,s7,x7];
    solucion.Punto7=Punto7;
    
    solucion.Masas=[m,m1,m2];
    

    q_condensador=h7-h1; % en kJ/kg
    q_caldera=h5-h4;  % en kJ/kg
    %QNeta=h5-h4; % en kJ/kg
    
    eficiencia_termica=(m*w_turbina1+m2*w_turbina2-m2*w_bomba1-m*w_bomba2)/(m*q_caldera);
    
    PotenciaNeta=(m*w_turbina1+w_turbina2*m2-m2*w_bomba1*m2-w_bomba2*m); %kW
    solucion.Masas=[round(m,1),round(m1,1),round(m2,1)];
    
    % Soluci�n - valores ciclo. Trabajos compresor y turbina y Calores
    % caldera y condensador  Todos en kJ/kg.
    % Eficiencia t�rmica del ciclo.
    solucion.ParametrosCiclo=[w_bomba1,w_bomba2,w_turbina1,w_turbina2,q_caldera,...
        q_condensador,eficiencia_termica,PotenciaNeta];
   
end

