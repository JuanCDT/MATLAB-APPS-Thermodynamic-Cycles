% This is the setup script for CoolProp.
