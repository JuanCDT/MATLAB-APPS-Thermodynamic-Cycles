function varargout = set_debug_level(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(348,varargin{:});
end
