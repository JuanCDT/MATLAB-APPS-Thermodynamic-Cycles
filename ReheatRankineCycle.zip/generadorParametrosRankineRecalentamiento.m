function [parametros]=generadorParametrosRankineRecalentamiento()


    fluido='water';
    
    a=randi([0 1]);b=randi([0 1]); c=randi([0 1]);
    if a && b&& c % todos ideales
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=1;
        eficienciaCompresor=1;
    elseif a % turbina 1 ideal
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=random('Uniform',0.7, 0.95);
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif b % compresor ideal
        eficienciaTurbina_1 = random('Uniform',0.7, 0.95);
        eficienciaTurbina_2=random('Uniform',0.7, 0.95);
        eficienciaCompresor = 1;
    elseif c % turbina 2 ideal
        eficienciaTurbina_2=1;
        eficienciaTurbina_1=random('Uniform',0.7, 0.95);
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif a && b % turbina 1 y compresor ideales
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=random('Uniform',0.7, 0.95);
        eficienciaCompresor=1;
    elseif b && c % turbina 2 y turbina 2 ideales
        eficienciaTurbina_1=1;
        eficienciaTurbina_2=1;
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif a && c % turbina 2 y compresor ideales
        eficienciaTurbina_1=random('Uniform',0.7, 0.95);
        eficienciaTurbina_2=1;
        eficienciaCompresor=1;
    else % real
        eficienciaTurbina_1 = random('Uniform',0.7, 0.95);
        eficienciaTurbina_2 = random('Uniform',0.7, 0.95);
        eficienciaCompresor = random('Uniform',0.7, 0.95);
    end
    
    % Define si el problema es con subenfriamiento, sobrecalentamiento o
    % ambos casos
       % Genera las condiciones a la entrada del compresor, a las turbina 1
       % y a la turbina 2
    
    p1 = round(random('Uniform',0.06,0.1),3);  % En bar, se convierte en Pa multiplicando por 1E5
    T1 =CoolProp.PropsSI('T', 'P', p1*1E5, 'Q', 0, fluido) ;% Temperatura en K
    p3 = round(random('Uniform',50,80),3); % En bar, se convierte en Pa multiplicando por 1E5
    p4 = round(random('Uniform',10,30),3); % En bar, se convierte en Pa multiplicando por 1E5
    p5=p4;
    rp_1 = p3/p4; % Relaci�n de presi�n primera expansi�n
    rp_2 = p4/p1; % Relaci�n de presi�n segunda expansi�n
    
   while 1
        X6_ideal=round(random('Uniform',0.85,0.95),3);  
        s6=CoolProp.PropsSI('S', 'P', p1*1E5, 'Q', X6_ideal, fluido)/1000 ;% Entrop�a en kJ/kg�K
        %T4 = CoolProp.PropsSI('T', 'P', p1*1E5, 'Q', X4, fluido) % Temperatura en K
        h6_ideal = CoolProp.PropsSI('H', 'P', p1*1E5, 'Q', X6_ideal, fluido)/1000 ;% Entalp�a en kJ/k
        T6_vaporSaturado=CoolProp.PropsSI('T', 'P', p1*1E5, 'Q', 1, fluido); % Temperatura en K
        %T3=CoolProp.PropsSI('T', 'P', p3*1E5, 'S', s4*1000, fluido); % Temperatura en K
        h5=CoolProp.PropsSI('H', 'P', p5*1E5, 'S', s6*1000, fluido)/1000 ;% Entalp�a en kJ/kg

        h6=h5-eficienciaTurbina_2*(h5-h6_ideal);
        T6=CoolProp.PropsSI('T', 'P', p1*1E5, 'H', h6*1000, fluido); % Temperatura en K
        T5_vaporSaturado=CoolProp.PropsSI('T', 'P', p4*1E5, 'Q', 1, fluido); % Temperatura en K
        T5 =CoolProp.PropsSI('T', 'P', p4*1E5, 'H', h5*1000, fluido) ;% Temperatura en K
        if T6==T6_vaporSaturado
            X6=CoolProp.PropsSI('Q', 'P', p1*1E5, 'H', h6*1000, fluido); % Temperatura en K
            if X6<=0.97 && X6>=0.9 && T5>T5_vaporSaturado 
                break
            end
        end
   end
   
   
   T3=random('Uniform',1,1.05)*T5; % Temperatura en K
   h3 =CoolProp.PropsSI('H', 'P', p3*1E5, 'T', T3, fluido)/1000 ;% Entalp�a en kJ/kg
   s3 =CoolProp.PropsSI('S', 'P', p3*1E5, 'T', T3, fluido)/1000 ;% Entalp�a en kJ/kg
   h4_ideal = CoolProp.PropsSI('H', 'P', p4*1E5, 'S', s3*1000, fluido)/1000; % Entrop�a en kJ/kg�K
   h4=h3-eficienciaTurbina_1*(h3-h4_ideal);
          
    

    parametros=[T1,p1,h3,p3,h4, p4 ,h5,T6,X6,rp_1,rp_2,eficienciaCompresor,eficienciaTurbina_1,...
        eficienciaTurbina_2] ;

end