classdef Rankine_conRecalentamiento < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                        matlab.ui.Figure
        TabGroup                        matlab.ui.container.TabGroup
        DatosInicialesTab               matlab.ui.container.Tab
        TextArea_3                      matlab.ui.control.TextArea
        UITable_DatosIniciales          matlab.ui.control.Table
        TextArea_4                      matlab.ui.control.TextArea
        UIAxes_PH                       matlab.ui.control.UIAxes
        UIAxes_TS                       matlab.ui.control.UIAxes
        UIAxes_PV                       matlab.ui.control.UIAxes
        Image                           matlab.ui.control.Image
        EjecutarButton_2                matlab.ui.control.Button
        MostrargrficosButton            matlab.ui.control.Button
        MostrarresultadosButton         matlab.ui.control.Button
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        ExportarresultadosButton        matlab.ui.control.Button
        UITable_Eficiencias             matlab.ui.control.Table
        ResultadosTab                   matlab.ui.container.Tab
        UITable_Resultados              matlab.ui.control.Table
        TextArea_5                      matlab.ui.control.TextArea
        UITable_Resultados_2            matlab.ui.control.Table
        Image2                          matlab.ui.control.Image
        UITable_Procesos                matlab.ui.control.Table
        TextArea_8                      matlab.ui.control.TextArea
        UITable_Resultados_TituloVapor  matlab.ui.control.Table
    end

    
    properties (Access = private)        
       
        parametros=[];
        fluido='water';
        Tc=647.096; % Temp. cr�tica del agua en K
            
        Punto1=[], Punto2=[]; Punto3=[]; Punto4=[];Punto5=[];Punto6=[]; tituloVapor=[];
        solucion=[];       
        
        eficienciaCompresor=[];eficienciaTurbina_1=[];eficienciaTurbina_2=[];
        w_compresor=[];w_turbina_1=[];w_turbina_2=[];Q_caldera=[];Q_recalentador=[];Q_condensador=[]; Eficiencia_termica=[];
        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)
            
                      
            app.solucion=CicloRankine_Recalentamiento(app.parametros);
            
            app.Punto1=app.solucion.Punto1;
            app.Punto2=app.solucion.Punto2;
            app.Punto3=app.solucion.Punto3;
            app.Punto4=app.solucion.Punto4;
            app.Punto5=app.solucion.Punto5;
            app.Punto6=app.solucion.Punto6;
            
            app.tituloVapor=app.Punto6(6);
            
            % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K) (y X4 para Punto4). 
            
            ParametrosCiclo=app.solucion.ParametrosCiclo;
            
            % w_compresor,w_turbina_1,w_turbina_2,q_caldera,q_recalentador,  q_condensador,eficiencia_termica
            
            app.w_compresor=ParametrosCiclo(1);
            app.w_turbina_1=ParametrosCiclo(2);
            app.w_turbina_2=ParametrosCiclo(3);
            app.Q_caldera=ParametrosCiclo(4);
            app.Q_recalentador=ParametrosCiclo(5);
            app.Q_condensador=ParametrosCiclo(6);
            app.Eficiencia_termica=ParametrosCiclo(7);
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)           
                        
            % Valores propiedades a lo largo de los procesos            
            % Puntos del proceso
            
           Entalpias=[app.Punto1(3),app.Punto2(3),app.Punto3(3),app.Punto4(3),app.Punto5(3),app.Punto6(3)];
           Temperaturas=[app.Punto1(1),app.Punto2(1),app.Punto3(1),app.Punto4(1),app.Punto5(1),app.Punto6(1)];
           Presiones=[app.Punto1(2),app.Punto2(2),app.Punto3(2),app.Punto4(2),app.Punto5(2),app.Punto6(2)];
           Volumenes=[app.Punto1(4),app.Punto2(4),app.Punto3(4),app.Punto4(4),app.Punto5(4),app.Punto6(4)];
           Entropias=[app.Punto1(5),app.Punto2(5),app.Punto3(5),app.Punto4(5),app.Punto5(5),app.Punto6(5)];
           
           % Domo saturacion
           %T_Final=app.Punto3(1)+5;
           T_Inicial=app.Punto1(1)-5;
           
           valores_VaporSaturado=CurvaVaporSaturado(T_Inicial, app.Tc, 500);
           valores_LiquidoSaturado=CurvaLiquidoSaturado(T_Inicial, app.Tc, 500);
           
            h_VaporSaturado=valores_VaporSaturado.entalpias;
            p_VaporSaturado=valores_VaporSaturado.presiones;
            v_VaporSaturado=valores_VaporSaturado.volumen;
            s_VaporSaturado=valores_VaporSaturado.entropias;
            T_VaporSaturado=valores_VaporSaturado.temperaturas;
            
            h_LiquidoSaturado=valores_LiquidoSaturado.entalpias;
            p_LiquidoSaturado=valores_LiquidoSaturado.presiones;
            v_LiquidoSaturado=valores_LiquidoSaturado.volumen;
            s_LiquidoSaturado=valores_LiquidoSaturado.entropias;
            T_LiquidoSaturado=valores_LiquidoSaturado.temperaturas;
            
            p3=app.parametros(4);
            p1=app.parametros(2);
            p4=app.parametros(6);
            
            rp=p3/p1;
            rp1=p3/p4;
            rp2=p4/p1;
            
            % Proceso 1 - Compresi�n
            valoresProceso1=CurvaCompresorVapor(app.Punto1(2),rp, app.Punto1(1), app.eficienciaCompresor,  200);        
            
            h_Proceso1=valoresProceso1.entalpias;
            p_Proceso1=valoresProceso1.presiones;
            v_Proceso1=valoresProceso1.volumen;
            s_Proceso1=valoresProceso1.entropias;
            T_Proceso1=valoresProceso1.temperaturas;
            
            % Proceso 2 - caldera            
            valoresProceso2=CurvaIsobara(app.Punto2(3),app.Punto2(2), app.Punto3(3), 500);          
                           

            h_Proceso2=valoresProceso2.entalpias;
            p_Proceso2=valoresProceso2.presiones;
            v_Proceso2=valoresProceso2.volumen;
            s_Proceso2=valoresProceso2.entropias;
            T_Proceso2=valoresProceso2.temperaturas;
            
            
                        
            % Proceso 3 - Expansion  1

            valoresProceso3=CurvaExpansionVapor(app.Punto3(2),1/rp1, app.Punto3(1), app.eficienciaTurbina_1,  200);            
            
                        
            h_Proceso3=valoresProceso3.entalpias;
            p_Proceso3=valoresProceso3.presiones;
            v_Proceso3=valoresProceso3.volumen;
            s_Proceso3=valoresProceso3.entropias;
            T_Proceso3=valoresProceso3.temperaturas;
            
            
            % Proceso 4 - regenerador            
            valoresProceso4=CurvaIsobara(app.Punto4(3),app.Punto4(2), app.Punto5(3), 500);          
                           

            h_Proceso4=valoresProceso4.entalpias;
            p_Proceso4=valoresProceso4.presiones;
            v_Proceso4=valoresProceso4.volumen;
            s_Proceso4=valoresProceso4.entropias;
            T_Proceso4=valoresProceso4.temperaturas;
            
            
                                    
            % Proceso 5 - Expansion  2

            valoresProceso5=CurvaExpansionVapor(app.Punto5(2),1/rp2, app.Punto5(1), app.eficienciaTurbina_2,  200);            
            
                        
            h_Proceso5=valoresProceso5.entalpias;
            p_Proceso5=valoresProceso5.presiones;
            v_Proceso5=valoresProceso5.volumen;
            s_Proceso5=valoresProceso5.entropias;
            T_Proceso5=valoresProceso5.temperaturas;
            
            
            % Proceso 6 - Condensador            
            valoresProceso6=CurvaIsobara(app.Punto6(3),app.Punto6(2), app.Punto1(3), 200);                      
                
    
            h_Proceso6=valoresProceso6.entalpias;
            p_Proceso6=valoresProceso6.presiones;
            v_Proceso6=valoresProceso6.volumen;
            s_Proceso6=valoresProceso6.entropias;
            T_Proceso6=valoresProceso6.temperaturas;
            
            % Diagrama p-h
            hold(app.UIAxes_PH,'on');
            
            app.UIAxes_PH.YScale = 'log';
            
            %domo
            plot(app.UIAxes_PH,  h_LiquidoSaturado,p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
                        
            % puntos y procesos
            plot(app.UIAxes_PH, Entalpias, Presiones,'color','r','Marker','o','LineStyle','none');
            plot(app.UIAxes_PH, h_Proceso1, p_Proceso1,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso2, p_Proceso2,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso3, p_Proceso3,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso4, p_Proceso4,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso5, p_Proceso5,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso6, p_Proceso6,'color','r','Marker','none','LineStyle','-');

            hold(app.UIAxes_PH,'off');
            
            app.UIAxes_PH.XLimMode = 'auto';
            app.UIAxes_PH.YLimMode = 'auto';
 
            % Diagrama p-v
     
            
            hold(app.UIAxes_PV,'on');
            
            app.UIAxes_PV.YScale = 'log';
            app.UIAxes_PV.XScale = 'log';
            
%             % domo
            plot(app.UIAxes_PV, v_LiquidoSaturado, p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
            
            
            % puntos y procesos
            plot(app.UIAxes_PV,Volumenes, Presiones,'color','b','Marker','o','LineStyle','none');
            plot(app.UIAxes_PV, v_Proceso1, p_Proceso1,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso2, p_Proceso2,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso3, p_Proceso3,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso4, p_Proceso4,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso5, p_Proceso5,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso6, p_Proceso6,'color','b','Marker','none','LineStyle','-');

            hold(app.UIAxes_PV,'off');
            
            app.UIAxes_PV.XLimMode = 'auto';
            app.UIAxes_PV.YLimMode = 'auto';

            
            % Diagrama T-s
            
           hold(app.UIAxes_TS,'on');
           
           
%             
%             % domo
            plot(app.UIAxes_TS, s_LiquidoSaturado, T_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_VaporSaturado, T_VaporSaturado,'color','k','Marker','none','LineStyle','-');
                        
            % puntos y procesos
            plot(app.UIAxes_TS, Entropias,Temperaturas,'color','g','Marker','o','LineStyle','none');
            plot(app.UIAxes_TS, s_Proceso1, T_Proceso1,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso2, T_Proceso2,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso3, T_Proceso3,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso4, T_Proceso4,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso5, T_Proceso5,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso6, T_Proceso6,'color','g','Marker','none','LineStyle','-');


            hold(app.UIAxes_TS,'off');
             
            app.UIAxes_TS.XLimMode = 'auto';
            app.UIAxes_TS.YLimMode = 'auto';

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UITable_Procesos.Data={'1-2','Compression';'2-3','Boiler: heat-addition';...
               '3-4','Expansion 1';'4-5','Reheat';'5-6','Expansion 2';'6-1','Condenser: heat-rejection'};
            app.UITable_Procesos.RowName={};          
                        
            
            app.parametros= generadorParametrosRankineRecalentamiento();           
                        
%             CeldaParametros=num2cell(app.parametros);
%             [T1,p1,X4,h3,p3,T4,rp,app.eficienciaCompresor,app.eficienciaTurbina]=deal(CeldaParametros{:});
%             
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
                        
        end

        % Button pushed function: EjecutarButton_2
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
            app.UITable_Resultados.Data={''};
            app.UITable_Resultados_2.Data={''};     
            app.UITable_Resultados_TituloVapor.Data={''};

            app.parametros= generadorParametrosRankineRecalentamiento();     
            
            
            
            CeldaParametros=num2cell(app.parametros);
            [T1,p1,h3,p3,h4, p4 ,h5,~,~,~,~,app.eficienciaCompresor,app.eficienciaTurbina_1,...
        app.eficienciaTurbina_2]=deal(CeldaParametros{:});
            T3=CoolProp.PropsSI('T', 'P', p3*1E5, 'H', h3*1000, 'water') ;% en K
            Caso=round(rand());
            app.Q_recalentador=h5-h4;
            T5= CoolProp.PropsSI('T', 'P', p4*1E5, 'H', h5*1E3, 'water');% en K 
            if Caso==1
                app.UITable_DatosIniciales.Data={T1;p1; T3;p3;p4;T5};
                app.UITable_DatosIniciales.ColumnName = {'Variable'; 'Value'};
                app.UITable_DatosIniciales.RowName={'Pump inlet temperature (K)','Pump inlet pressure (bar)',...
                   'Turbine inlet temperature 1(K)','Turbine inlet pressure 1 (bar)', ...
                   'Turbine outlet pressure 1 (bar)','Turbine inlet temperature 2 (K)'};
            else
                app.UITable_DatosIniciales.Data={T1;p1; T3;p3;p4;app.Q_recalentador};
                app.UITable_DatosIniciales.ColumnName = {'Variable'; 'Valor'};
                app.UITable_DatosIniciales.RowName={'Pump inlet temperature (K)','Pump inlet pressure (bar)',...
                   'Turbine inlet temperature 1(K)','Turbine inlet pressure 1 (bar)', ...
                   'Turbine outlet pressure 1 (bar)','Heat exchanged - Reheater (kJ/kg)'};
                
            end
            
            app.UITable_Eficiencias.Data={app.eficienciaCompresor,app.eficienciaTurbina_1,app.eficienciaTurbina_2};

        end

        % Button pushed function: MostrargrficosButton
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end

        % Button pushed function: MostrarresultadosButton
        function MostrarresultadosButtonPushed(app, ~)
            MostrargrficosButtonPushed(app, 'push');
            format shortG        
            
            app.UITable_Resultados.Data={'1',app.Punto1(2),app.Punto1(1), app.Punto1(3),app.Punto1(5),app.Punto1(4);...
            '2',app.Punto2(2),app.Punto2(1),app.Punto2(3),app.Punto2(5),app.Punto2(4);...
           '3',app.Punto3(2),app.Punto3(1), app.Punto3(3),app.Punto3(5),app.Punto3(4);...
            '4',app.Punto4(2),app.Punto4(1), app.Punto4(3),app.Punto4(5),app.Punto4(4);...
            '5',app.Punto5(2),app.Punto5(1), app.Punto5(3),app.Punto5(5),app.Punto5(4);...
            '6',app.Punto6(2),app.Punto6(1), app.Punto6(3),app.Punto6(5),app.Punto6(4)};

            app.UITable_Resultados_2.Data={app.w_compresor;app.w_turbina_1; app.w_turbina_2; app.Q_caldera;app.Q_recalentador;...
                app.Q_condensador; app.Eficiencia_termica};
            
                        
            app.UITable_Resultados_TituloVapor.Data={app.tituloVapor};
 
 
            
            
        end

        % Button pushed function: ExportarresultadosButton
        function ExportarresultadosButtonPushed(app, ~)
            
            Data=get(app.UITable_Resultados,'Data');
            ColumnName=get(app.UITable_Resultados,'ColumnName');
            ColumnName=ColumnName';
            NewData=num2cell(Data);
            Datos1 = cell2table(NewData,'VariableNames',ColumnName);
            writetable(Datos1,'Datos del ciclo de Rankine con Recalentamiento.xls','Sheet','Datos Procesos');
            
            Data1=get(app.UITable_Resultados_2,'Data');
            ColumnName1=get(app.UITable_Resultados_2,'ColumnName');
            ColumnName1=ColumnName1';
            RowName1=get(app.UITable_Resultados_2,'RowName');
            RowName1=RowName1';
            NewData1=num2cell(Data1);
            Datos2= cell2table(NewData1,'VariableNames',ColumnName1,'RowNames',RowName1);
            writetable(Datos2,'Datos del ciclo de Rankine con Recalentamiento.xls','Sheet','Datos ciclo','WriteRowNames',true);


        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 895 671];
            app.UIFigure.Name = 'Reheat Rankine Cycle';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 -1 895 673];

            % Create DatosInicialesTab
            app.DatosInicialesTab = uitab(app.TabGroup);
            app.DatosInicialesTab.Title = 'Initial values';

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.DatosInicialesTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [42 578 372 30];
            app.TextArea_3.Value = {'Reheat Rankine Cycle'};

            % Create UITable_DatosIniciales
            app.UITable_DatosIniciales = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales.ColumnName = {'Variable'; 'Value'};
            app.UITable_DatosIniciales.RowName = {''};
            app.UITable_DatosIniciales.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales.FontWeight = 'bold';
            app.UITable_DatosIniciales.Position = [16 326 455 158];

            % Create TextArea_4
            app.TextArea_4 = uitextarea(app.DatosInicialesTab);
            app.TextArea_4.HorizontalAlignment = 'center';
            app.TextArea_4.FontSize = 18;
            app.TextArea_4.FontWeight = 'bold';
            app.TextArea_4.Position = [64 499 327 30];
            app.TextArea_4.Value = {'Initial values'};

            % Create UIAxes_PH
            app.UIAxes_PH = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH, 'Diagram p-h')
            xlabel(app.UIAxes_PH, 'Enthaply (kJ/kg)')
            ylabel(app.UIAxes_PH, 'Pressure (bar)')
            app.UIAxes_PH.PlotBoxAspectRatio = [1.92307692307692 1 1];
            app.UIAxes_PH.Position = [583 437 300 185];

            % Create UIAxes_TS
            app.UIAxes_TS = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS, 'Diagram T-s')
            xlabel(app.UIAxes_TS, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS, 'Temperatura (K)')
            app.UIAxes_TS.Position = [583 238 300 185];

            % Create UIAxes_PV
            app.UIAxes_PV = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV, 'Diagram p-v')
            xlabel(app.UIAxes_PV, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV, 'Pressure (bar)')
            app.UIAxes_PV.Position = [583 39 300 185];

            % Create Image
            app.Image = uiimage(app.DatosInicialesTab);
            app.Image.Position = [27 11 182 148];
            app.Image.ImageSource = 'Pollo Transparente.gif';

            % Create EjecutarButton_2
            app.EjecutarButton_2 = uibutton(app.DatosInicialesTab, 'push');
            app.EjecutarButton_2.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton_2.Position = [177 548 100 22];
            app.EjecutarButton_2.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [57 212 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [281 212 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Position = [226 95 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [226 62 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Steam power cycles';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [216 27 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create ExportarresultadosButton
            app.ExportarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.ExportarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @ExportarresultadosButtonPushed, true);
            app.ExportarresultadosButton.Position = [159 179 120 22];
            app.ExportarresultadosButton.Text = 'Export results';

            % Create UITable_Eficiencias
            app.UITable_Eficiencias = uitable(app.DatosInicialesTab);
            app.UITable_Eficiencias.ColumnName = {'Efic. Pump'; 'Efic. Turbine 1'; 'Efic. Turbine 2'};
            app.UITable_Eficiencias.RowName = {};
            app.UITable_Eficiencias.ForegroundColor = [0.4667 0.6745 0.1882];
            app.UITable_Eficiencias.FontWeight = 'bold';
            app.UITable_Eficiencias.Position = [17 260 302 48];

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Results';

            % Create UITable_Resultados
            app.UITable_Resultados = uitable(app.ResultadosTab);
            app.UITable_Resultados.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados.RowName = {};
            app.UITable_Resultados.Position = [18 434 626 160];

            % Create TextArea_5
            app.TextArea_5 = uitextarea(app.ResultadosTab);
            app.TextArea_5.HorizontalAlignment = 'center';
            app.TextArea_5.FontSize = 18;
            app.TextArea_5.FontWeight = 'bold';
            app.TextArea_5.Position = [150 601 327 30];
            app.TextArea_5.Value = {'Results of the cycle'};

            % Create UITable_Resultados_2
            app.UITable_Resultados_2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2.ColumnName = {'Heat and work exchanged'};
            app.UITable_Resultados_2.RowName = {'w (compressor) (kJ/kg)'; 'w (turbine 1) (kJ/kg)'; 'w (turbine 2) (kJ/kg)'; 'q (boiler) (kJ/kg)'; 'q (reheater) (kJ/kg)'; 'q (condenser) (kJ/kg)'; 'Thermal efficiency'};
            app.UITable_Resultados_2.Position = [18 247 373 182];

            % Create Image2
            app.Image2 = uiimage(app.ResultadosTab);
            app.Image2.ScaleMethod= 'fit';
            app.Image2.Position = [600 18 280 400];
            app.Image2.ImageSource = 'CicloRankine_Recalentamiento.png';

            % Create UITable_Procesos
            app.UITable_Procesos = uitable(app.ResultadosTab);
            app.UITable_Procesos.ColumnName = {'Process'; 'Descripction'};
            app.UITable_Procesos.ColumnWidth = {60, 'auto'};
            app.UITable_Procesos.RowName = {''};
            app.UITable_Procesos.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Procesos.FontWeight = 'bold';
            app.UITable_Procesos.FontSize = 14;
            app.UITable_Procesos.Position = [24 9 440 175];

            % Create TextArea_8
            app.TextArea_8 = uitextarea(app.ResultadosTab);
            app.TextArea_8.HorizontalAlignment = 'center';
            app.TextArea_8.FontSize = 18;
            app.TextArea_8.FontWeight = 'bold';
            app.TextArea_8.Position = [32 200 327 30];
            app.TextArea_8.Value = {'Processes'};

            % Create UITable_Resultados_TituloVapor
            app.UITable_Resultados_TituloVapor = uitable(app.ResultadosTab);
            app.UITable_Resultados_TituloVapor.ColumnName = {'Quality - Turbine 2 outlet'};
            app.UITable_Resultados_TituloVapor.RowName = {};
            app.UITable_Resultados_TituloVapor.Position = [654 544 229 50];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = Rankine_conRecalentamiento

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end