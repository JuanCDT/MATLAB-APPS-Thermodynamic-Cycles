function solucion=CicloRankine_Recalentamiento(parametros)
    
    solucion=struct;
    
     % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K).  
    
    CeldaParametros=num2cell(parametros);
    [T1,p1,h3,p3,h4, p4 ,h5,T6,X6,~,~,eficienciaCompresor,~,~]=deal(CeldaParametros{:});
    
    % Condiciones conocidas
    P1=p1*1E5; % Cambio a Pa
    P3=p3*1E5; % Cambio a Pa
    P4=p4*1E5; % Cambio a Pa

    % C�lculo salida del compresor
    
    
    s1=CoolProp.PropsSI('S', 'Q',0 , 'P', P1, 'water')/1000;
    h1= CoolProp.PropsSI('H', 'Q',0 , 'P', P1, 'water')/1000;
    V1= CoolProp.PropsSI('D', 'P', P1, 'Q', 0, 'water')^-1;% en m3/kg
    
    Punto1=[T1,p1,h1,V1,s1];
    solucion.Punto1=Punto1;


    % C�lculo entalp�as y trabajo en el compresor ideal
    T2= CoolProp.PropsSI('T', 'P', P3, 'S', s1*1E3, 'water');
    h2= CoolProp.PropsSI('H', 'P', P3, 'S', s1*1E3, 'water')/1000; % en kJ/kg    
    w_compresor=h2-h1;% en kJ/kg
    
    
    % C�lculo entalp�as y trabajo en el compresor real
    if eficienciaCompresor~=1
        h2=w_compresor/eficienciaCompresor+h1;
        w_compresor=w_compresor/eficienciaCompresor;
        T2= CoolProp.PropsSI('T', 'P', P3, 'H', h2*1000, 'water');
    end
    V2= CoolProp.PropsSI('D', 'P', P3, 'T', T2, 'water')^-1;% en m3/kg
    s2= CoolProp.PropsSI('S', 'P', P3, 'T', T2, 'water')/1000; % en kJ/kg�K
    
    Punto2=[T2,p3,h2,V2,s2];
    solucion.Punto2=Punto2;
    
    
    % Calculo calentamiento
    
    s3=CoolProp.PropsSI('S', 'P',P3 , 'H', h3*1000, 'water')/1000; % en kJ/kg�K
    T3= CoolProp.PropsSI('T',  'P',P3 , 'H', h3*1000, 'water');% en K
    v3= CoolProp.PropsSI('D', 'P',P3 , 'H', h3*1000, 'water')^-1;% en m3/kg

    Punto3=[T3,p3,h3,v3,s3];
    solucion.Punto3=Punto3;

    % C�lculo entalp�as y trabajo en la turbina 1 
    V4= CoolProp.PropsSI('D', 'P', P4, 'H', h4*1E3, 'water')^-1;% en m3/kg
    T4= CoolProp.PropsSI('T', 'P', P4, 'H', h4*1E3, 'water');% en K 
    s4= CoolProp.PropsSI('S', 'P', P4, 'H', h4*1E3, 'water')/1000; % en kJ/kg�K
    
    Punto4=[T4,p4,h4,V4,s4];
    solucion.Punto4=Punto4;
    
    % C�lculo entalp�as tras el regenerador
    V5= CoolProp.PropsSI('D', 'P', P4, 'H', h5*1E3, 'water')^-1;% en m3/kg
    T5= CoolProp.PropsSI('T', 'P', P4, 'H', h5*1E3, 'water');% en K 
    s5= CoolProp.PropsSI('S', 'P', P4, 'H', h5*1E3, 'water')/1000; % en kJ/kg�K
    
    Punto5=[T5,p4,h5,V5,s5];
    solucion.Punto5=Punto5;
    
    
    % C�lculo entalp�as y trabajo en la turbina 2
    V6= CoolProp.PropsSI('D', 'P', P1, 'Q', X6, 'water')^-1;% en m3/kg
    s6= CoolProp.PropsSI('S', 'P', P1, 'Q', X6, 'water')/1000; % en kJ/kg�K
    h6= CoolProp.PropsSI('H', 'P', P1, 'Q', X6, 'water')/1000; % en kJ/kg�K
    
    Punto6=[T6,p1,h6,V6,s6,X6];
    solucion.Punto6=Punto6;
    
    
    w_turbina_1=h3-h4;% en kJ/kg
    w_turbina_2=h5-h6;% en kJ/kg
    q_condensador=h6-h1; % en kJ/kg
    q_caldera=h3-h2;  % en kJ/kg
    q_recalentador=h5-h4; % en kJ/kg
    
    eficiencia_termica=(w_turbina_1+w_turbina_2-w_compresor)/(q_caldera+q_recalentador);

    % Soluci�n - valores ciclo. Trabajos compresor y turbina y Calores
    % caldera y condensador  Todos en kJ/kg.
    % Eficiencia t�rmica del ciclo.
    solucion.ParametrosCiclo=[w_compresor,w_turbina_1,w_turbina_2,q_caldera,q_recalentador,...
        q_condensador,eficiencia_termica];
   
end

