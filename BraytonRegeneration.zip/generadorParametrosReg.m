function parametros=generadorParametrosReg()

    % Genera dos valores para la selecci�n del tipo de problema (completamente
    %ideal, turbina ideal, compresor ideal,real)
    
    a=randi([0 1]);b=randi([0 1]);
    if a && b % ideal
        eficienciaTurbina=1;
        eficienciaCompresor=1;
    elseif a % turbina ideal
        eficienciaTurbina=1;
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif b % compresor ideal
        eficienciaTurbina = random('Uniform',0.7, 0.95);
        eficienciaCompresor = 1;
    else % real
        eficienciaTurbina = random('Uniform',0.7, 0.95);
        eficienciaCompresor = random('Uniform',0.7, 0.95);
    end
    
    rendimientoRegenerador= random('Uniform',0.7, 1);
    % Genera las condiciones a la entrada del compresor y de la turbina
    T1 = round(random('Uniform',288.15,323.15),1); % Temperatura en K
    p1 = round(random('Uniform',1.1,1.4),3);  % En bar, se convierte en Pa multiplicando por 1E5
    rp = round(random('Uniform',3.0,8.0),1);
    T3 = round(T1+ random('Uniform',700,1000),1);
    p3 = round(p1 * rp,3);
    
    % Genera valores aleatorios para gamma y Cp
    PM=round(random('Uniform',20,44),2);
    R=(8.314462*1E-3)*PM; % en kJ/kg�k
    Cp=(7/2)*R; % Cp en kJ/kg�K
    
    gamma=round(Cp/(Cp-R),4);
    
    EntradaCompresor=[T1,p1];
    EntradaTurbina=[T3,p3];
    Eficiencias=[eficienciaTurbina,eficienciaCompresor,rendimientoRegenerador];
    Eficiencias=round(Eficiencias,3);
    parametros=[EntradaCompresor,EntradaTurbina,Eficiencias,Cp,gamma,R] ;

end