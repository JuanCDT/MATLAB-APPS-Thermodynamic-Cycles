function solucion=CicloBraytonRegeneracion(parametros,h1)
    
    % hreferencia es la entalp�a de referencia a la entrada del compresor
    
    EntradaCompresor=parametros(1:2);
    EntradaTurbina=parametros(3:4);
    Eficiencias=parametros(5:6);
    eficienciaRegenerador=parametros(7);
    Cp=parametros(8);
    gamma=parametros(9);
    
    
    
   
    P1=EntradaCompresor(2); % En bar
    P2=EntradaTurbina(2); % En bar
    T1= EntradaCompresor(1);
    T3= EntradaTurbina(1);
    rp=P2/P1;
    
    % Calculo compresor
    [T2, h2, T2_ideal, w_compresor] = Compresor(T1, P1, h1, rp,Eficiencias(2), gamma, Cp);
    
    % Calculo caldera
    h3=h2+Cp*(T3-T2);
    Q_entrada=h3-h2;
    
    % Calculo turbina
    [T4,h4, T4_ideal, w_turbina] = Turbina(T3, P2, h3, rp,Eficiencias(1), gamma, Cp);
    
        
    % Calculo escape
    Q_salida=h4-h1;
    
    % Regeneradores
    Q_regeneradorIdeal=h4-h2;
    Q_regenerador=Q_regeneradorIdeal*eficienciaRegenerador;
    h5=h2+Q_regenerador;
    T5=Q_regenerador/Cp+T2;
    P5=P2;
    h6=h4-Q_regenerador;
    T6=T4-Q_regenerador/Cp;
    P6=P1;
    
    
    
    
    % C�lculo eficiencia t�rmica del ciclo
    Eficiencia_termica=1-Q_salida/Q_entrada; % en kJ/kg
    
    SalidaCompresor=[T2,P2, T2_ideal,h2];
    SalidaTurbina=[T4,P1, T4_ideal,h4];
    SalidaRegenerador1=[T5,P5,h5];
    SalidaRegenerador2=[T6,P6, h6];
    Trabajos=[w_turbina,w_compresor];
    Calores=[Q_entrada,Q_salida,Q_regenerador];
    solucion=[SalidaCompresor,SalidaTurbina,SalidaRegenerador1,SalidaRegenerador2,...
        Trabajos,Calores,Eficiencia_termica];
   
end