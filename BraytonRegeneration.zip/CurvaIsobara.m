function valores=CurvaIsobara(T_Inicial,h_Inicial,s_inicial, T_Final, Cp, N_Puntos)

    temperaturas= linspace(T_Inicial,T_Final,N_Puntos);
    
    entalpias=(temperaturas-temperaturas(1))*Cp+h_Inicial;
    entropias=s_inicial+Cp*log(temperaturas./temperaturas(1));
    
    valores=struct();
    valores.entalpias=entalpias;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;


end