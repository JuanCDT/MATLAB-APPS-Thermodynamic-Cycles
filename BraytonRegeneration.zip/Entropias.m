
function entropia=Entropias(P,T,s_referencia,P_referencia, T_referencia,Cp,R)
    % Temperatura en K y presi�n en bar.
    %R=0.28705; % Para el aire en kJ/kg�K o (m3*Pa)/(K*kg)
    relaciones_Presion=P/P_referencia;
    relaciones_Temperatura=T/T_referencia;
    
    entropia=s_referencia+Cp*log(relaciones_Temperatura)-R*log(relaciones_Presion); % en kJ/kg�K
end