
function volumen=Volumenes(P,T,R)
    % Temperatura en K y presi�n en bar.
    %R=0.28705; % Para el aire en kJ/kg�K o (m3*Pa)/(K*kg)            
    volumen=R*1000*T/(P*1E5); % en m3/kg
end