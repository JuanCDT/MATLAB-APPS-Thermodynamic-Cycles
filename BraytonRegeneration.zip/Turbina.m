function [Tsalida, hsalida, Tisentropica, TrabajoReal] = Turbina(Tentrada, Pentrada, hentrada, rp,eficiencia, gamma, Cp)

    Tisentropica=Tentrada*(rp)^((1-gamma)/gamma); % Temperaturas en K
    Psalida=Pentrada/rp; % Presiones en bar
    Trabajoideal=Cp*(Tentrada-Tisentropica);  % trabajos y entalp�as en kJ/kg y Cp en kJ/kg�K
    TrabajoReal=Trabajoideal*eficiencia;
    hsalida=hentrada-TrabajoReal;
    Tsalida=Tentrada-TrabajoReal/Cp;  


end