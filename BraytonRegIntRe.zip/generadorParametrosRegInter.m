function parametros=generadorParametrosRegInter()

    % Genera dos valores para la selecci�n del tipo de problema (completamente
    %ideal, turbina ideal, compresor ideal,real)
    
    % punto 1 - entrada compresor 1
    % punto 2 - salida compresor 1   
    % punto 3- entrada compresor 2
    % punto 4 - salida compresor 2
    
    % punto 5 - entrada turbina 1
    % punto 6 - salida turbina 1   
    % punto 7- entrada turbina 2
    % punto 8 - salida turbina 2
    
    % punto 9 - salida regenerador (fluido caliente a alta presi�n)
    % punto 10 - entrada regenerador (fluido fr�o a baja presi�n)
    
    
    a=randi([0 1]);b=randi([0 1]);c=randi([0 1]);d=randi([0 1]);
    if a&&b % todos ideales
        eficienciaCompresor1=1;
        eficienciaCompresor2=1;
         if c
            eficienciaTurbina1=1;
            eficienciaTurbina2=round(random('Uniform',0.7, 0.95),3);
        elseif d
            eficienciaTurbina2=1;
            eficienciaTurbina1=round(random('Uniform',0.7, 0.95),3);
        else 
            eficienciaTurbina1=round(random('Uniform',0.7, 0.95),3);
            eficienciaTurbina2=round(random('Uniform',0.7, 0.95),3);
            
         end           
    
    elseif a 
        eficienciaCompresor1=1;
        eficienciaCompresor2=random('Uniform',0.7, 0.95);
         if c
            eficienciaTurbina1=1;
            eficienciaTurbina2=random('Uniform',0.7, 0.95);
        elseif d
            eficienciaTurbina2=1;
            eficienciaTurbina1=random('Uniform',0.7, 0.95);
        else 
            eficienciaTurbina1=random('Uniform',0.7, 0.95);
            eficienciaTurbina2=random('Uniform',0.7, 0.95);
            
         end
    
    elseif b % compresor ideal
        eficienciaCompresor2=1;
        eficienciaCompresor1=round(random('Uniform',0.7, 0.95),3);
        if c
            eficienciaTurbina1=1;
            eficienciaTurbina2=round(random('Uniform',0.7, 0.95),3);
        elseif d
            eficienciaTurbina2=1;
            eficienciaTurbina1=round(random('Uniform',0.7, 0.95),3);
        else 
            eficienciaTurbina1=round(random('Uniform',0.7, 0.95),3);
            eficienciaTurbina2=round(random('Uniform',0.7, 0.95),3);
            
        end
        
    else
        eficienciaCompresor2=round(random('Uniform',0.7, 0.95),3);
        eficienciaCompresor1=round(random('Uniform',0.7, 0.95),3);
        if c
            eficienciaTurbina1=1;
            eficienciaTurbina2=round(random('Uniform',0.7, 0.95),3);
        elseif d
            eficienciaTurbina2=1;
            eficienciaTurbina1=round(random('Uniform',0.7, 0.95),3);
        else 
            eficienciaTurbina1=round(random('Uniform',0.7, 0.95),3);
            eficienciaTurbina2=round(random('Uniform',0.7, 0.95),3);
            
        end  
        
    end
    
    rendimientoRegenerador= random('Uniform',0.7, 1);
    % Genera las condiciones a lclca entrada del compresor y de la turbina
    T1 = round(random('Uniform',288.15,323.15),1); % Temperatura en K
    p1 = round(random('Uniform',1.1,1.4),3);  % En bar, se convierte en Pa multiplicando por 1E5
    rp = round(random('Uniform',3.0,8.0),1);
    T5 = round(T1+ random('Uniform',700,1000),1);
    p5 = round(p1 * rp,3);
    
    e=randi([0 1]);f=randi([0 1]);
    
    if e && f
        p3=round(sqrt(p1*p5),3);
        p6=p3;
        
    elseif e        
        p3=round(sqrt(p1*p5),3);
        p6=round(1/(rp*random('Uniform',0.4, 0.75))*p5,3);
        
    elseif f        
        p3=round(rp*random('Uniform',0.4, 0.75)*p1,3);
        p6=round(sqrt(p1*p5),3);
        
    else
        p6=round(1/(rp*random('Uniform',0.4, 0.75))*p5,3);
        p3=round(rp*random('Uniform',0.4, 0.75)*p1,3);
    
    end
    
    
    % Genera valores aleatorios para gamma y Cp
    PM=round(random('Uniform',28,36),2);
    R=(8.314462*1E-3)*PM; % en kJ/kg�k
    Cp=(7/2)*R; % Cp en kJ/kg�K
    
    gamma=round(Cp/(Cp-R),2);
    
    EntradaCompresor1=[T1,p1];
    PSalidaCompresor2=p3;
    EntradaTurbina1=[T5,p5];
    PSalidaTurbina1=p6;    
    
    Eficiencias=[eficienciaTurbina1,eficienciaTurbina2,eficienciaCompresor1,eficienciaCompresor2, rendimientoRegenerador];
    Eficiencias=round(Eficiencias,3);
    parametros=[EntradaCompresor1,PSalidaCompresor2,EntradaTurbina1,PSalidaTurbina1,Eficiencias,Cp,gamma,R] ;

end