classdef BraytonRegIntRe < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                      matlab.ui.Figure
        TabGroup                      matlab.ui.container.TabGroup
        DatosInicialesTab             matlab.ui.container.Tab
        TextArea_3                    matlab.ui.control.TextArea
        UITable_DatosIniciales        matlab.ui.control.Table
        TextArea_4                    matlab.ui.control.TextArea
        UIAxes_PH                     matlab.ui.control.UIAxes
        UIAxes_TS                     matlab.ui.control.UIAxes
        UIAxes_PV                     matlab.ui.control.UIAxes
        Image                         matlab.ui.control.Image
        UITable_Referencia            matlab.ui.control.Table
        TextArea_6                    matlab.ui.control.TextArea
        UITable_ParametrosAire        matlab.ui.control.Table
        TextArea_7                    matlab.ui.control.TextArea
        UITable_Eficiencias           matlab.ui.control.Table
        EjecutarButton_2              matlab.ui.control.Button
        MostrargrficosButton          matlab.ui.control.Button
        MostrarresultadosButton       matlab.ui.control.Button
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        ExportarresultadosButton      matlab.ui.control.Button
        Button_CondicionesAleatorias  matlab.ui.control.Button
        Button_ReferenciaInicial      matlab.ui.control.Button
        UITable_Eficiencias_2         matlab.ui.control.Table
        UITable_DatosIniciales_rp     matlab.ui.control.Table
        TextArea_9                    matlab.ui.control.TextArea
        ParmetrostablasButton         matlab.ui.control.Button
        ResultadosTab                 matlab.ui.container.Tab
        UITable_Resultados            matlab.ui.control.Table
        TextArea_5                    matlab.ui.control.TextArea
        UITable_Resultados_2          matlab.ui.control.Table
        Image2                        matlab.ui.control.Image
        UITable_Procesos              matlab.ui.control.Table
        TextArea_8                    matlab.ui.control.TextArea
    end

    
    properties (Access = private)
        
        sreferencia=1.73498; % Entrop�a del aire a 300 K y 1 bar en kJ/kg�K
        hreferencia=300.19; % Entalp�a del aire a 300 K y 1 bar en kJ/kg
        Treferencia=300; % En K
        Preferencia=1; % En bar
        parametros=generadorParametrosRegInter();
        Punto1=[], Punto2=[]; Punto3=[]; Punto4=[]; Punto5=[]; Punto6=[];Punto7=[], Punto8=[]; Punto9=[]; Punto10=[]; 
        rp1=[];rp2=[];rp3=[];rp4=[];
        
        Cp=[];gamma=[]; R=[];
        
        eficienciaTurbina1=[];eficienciaTurbina2=[];eficienciaCompresor1=[];eficienciaCompresor2=[]; rendimientoRegenerador=[];
        
        w_turbina1=[];w_turbina2=[]; w_compresor1=[]; w_compresor2=[];Q_caldera=[];Q_Recalentamiento=[];Q_escape=[];
        Q_Interenfriamiento=[];Q_entrada=[];Q_salida=[];Q_regenerador=[];Eficiencia_termica=[];
        
        solucion=[];       
        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)           
            
            
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)                         
            
            
            CeldaParametros=num2cell(app.parametros);
            [T1,P1,P3,T5,P5,P6, app.eficienciaTurbina1,app.eficienciaTurbina2,app.eficienciaCompresor1,app.eficienciaCompresor2,...
                app.rendimientoRegenerador,app.Cp,app.gamma,app.R]=deal(CeldaParametros{:});
            
           % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K).          
            
            app.Punto1(1)=T1;app.Punto1(2)= P1; app.Punto1(3)=app.hreferencia+app.Cp*(T1-app.Treferencia);
            app.solucion=CicloBraytonRegeneracionInter(app.parametros,app.Punto1(3));
            
            CeldaSolucion=num2cell(app.solucion);
            [T2,P2, ~,h2,T3,~,h3,T4,P4, ~,h4,T6,~, ~,h6,T7,P7,h7,T8,P8, ~,h8,T9,P9,h9,T10,P10, h10,...
                app.w_turbina1,app.w_turbina2, app.w_compresor1, app.w_compresor2,app.Q_caldera,app.Q_Recalentamiento,app.Q_escape,...
                app.Q_Interenfriamiento,app.Q_entrada,app.Q_salida,app.Q_regenerador,app.Eficiencia_termica]=deal(CeldaSolucion{:});                
            
    
            app.Punto2(1)=T2; app.Punto2(2)=P2; app.Punto2(3)=h2;  
            app.Punto3(1)=T3; app.Punto3(2)=P3; app.Punto3(3)=h3;
            app.Punto4(1)=T4; app.Punto4(2)=P4; app.Punto4(3)=h4;
            app.Punto5(1)=T5; app.Punto5(2)=P5; app.Punto5(3)=h7;
            app.Punto6(1)=T6; app.Punto6(2)=P6; app.Punto6(3)=h6;
            app.Punto7(1)=T7; app.Punto7(2)=P7; app.Punto7(3)=h7;
            app.Punto8(1)=T8; app.Punto8(2)=P8; app.Punto8(3)=h8;
            app.Punto9(1)=T9; app.Punto9(2)=P9; app.Punto9(3)=h9;
            app.Punto10(1)=T10; app.Punto10(2)=P10; app.Punto10(3)=h10;

           
            h=[app.Punto1(3),app.Punto2(3),app.Punto3(3),app.Punto4(3),app.Punto5(3),app.Punto6(3),app.Punto7(3),app.Punto8(3),...
                app.Punto9(3),app.Punto10(3)]; % entalpias
            P=[app.Punto1(2),app.Punto2(2),app.Punto3(2),app.Punto4(2),app.Punto5(2),app.Punto6(2),app.Punto7(2),app.Punto8(2),...
                app.Punto9(2),app.Punto10(2)]; % presiones
            v=[Volumenes(app.Punto1(2),app.Punto1(1),app.R),Volumenes(app.Punto2(2),app.Punto2(1),app.R),...
                Volumenes(app.Punto3(2),app.Punto3(1),app.R),Volumenes(app.Punto4(2),app.Punto4(1),app.R),...
                Volumenes(app.Punto5(2),app.Punto5(1),app.R),Volumenes(app.Punto6(2),app.Punto6(1),app.R),...
                Volumenes(app.Punto7(2),app.Punto7(1),app.R),Volumenes(app.Punto8(2),app.Punto8(1),app.R),...
                Volumenes(app.Punto9(2),app.Punto9(1),app.R),Volumenes(app.Punto10(2),app.Punto10(1),app.R)];% Vol�menes espec�ficos
            
            
            app.Punto1(4)=v(1);app.Punto2(4)=v(2);app.Punto3(4)=v(3);app.Punto4(4)=v(4);
            app.Punto5(4)=v(5);app.Punto6(4)=v(6); app.Punto7(4)=v(1);app.Punto8(4)=v(2);app.Punto9(4)=v(3);app.Punto10(4)=v(4);
            
            app.Punto1(5)=Entropias(app.Punto1(2),app.Punto1(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R, app.Cp); 
            app.Punto2(5)=Entropias(app.Punto2(2),app.Punto2(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto3(5)=Entropias(app.Punto3(2),app.Punto3(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto4(5)=Entropias(app.Punto4(2),app.Punto4(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto5(5)=Entropias(app.Punto5(2),app.Punto5(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto6(5)=Entropias(app.Punto6(2),app.Punto6(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto7(5)=Entropias(app.Punto7(2),app.Punto7(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto8(5)=Entropias(app.Punto8(2),app.Punto8(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto9(5)=Entropias(app.Punto9(2),app.Punto9(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp); 
            app.Punto10(5)=Entropias(app.Punto10(2),app.Punto10(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.Cp);            
            
                       
            % Procesos compresi�n y expansi�n
            
            % Compresi�n 1
            valoresCompresion1=CurvaTrabajo(app.Punto1(2),app.rp1, app.Punto1(1),app.Punto1(5),app.Punto1(3),1, app.eficienciaCompresor1, app.gamma,...
                app.Cp,app.R, 200); % Compresi�n

            % Diagrama p-h
            h1=valoresCompresion1.entalpias;
            p1=valoresCompresion1.presiones;
            v1=valoresCompresion1.volumen;
            s1=valoresCompresion1.entropias;
            T1=valoresCompresion1.temperaturas;
            
            % Entrop�as
            app.Punto2(5)=s1(end);
            
            % Recalentamiente entre compresiones            
            valoresRecalentamiento=CurvaIsobara(app.Punto2(1),app.Punto2(3),app.Punto2(5), app.Punto3(1),app.Punto2(2),app.Cp, app.R,200); % calentamiento
            
            h2=valoresRecalentamiento.entalpias;
            p2=valoresRecalentamiento.presiones;
            v2=valoresRecalentamiento.volumen;
            s2=valoresRecalentamiento.entropias;
            T2=valoresRecalentamiento.temperaturas;
           
            
            
             % Compresi�n 2
            valoresCompresion2=CurvaTrabajo(app.Punto3(2),app.rp2, app.Punto3(1),app.Punto3(5),app.Punto3(3),1, app.eficienciaCompresor2, app.gamma,...
                app.Cp,app.R, 200); % Compresi�n
            
            h3=valoresCompresion2.entalpias;
            p3=valoresCompresion2.presiones;
            v3=valoresCompresion2.volumen;
            s3=valoresCompresion2.entropias;
            T3=valoresCompresion2.temperaturas;
            
            
            % Entrop�as
            app.Punto4(5)=s3(end);
            
            
            
            % Calentamiento         
            valoresCalentamiento=CurvaIsobara(app.Punto4(1),app.Punto4(3),app.Punto4(5), app.Punto5(1),app.Punto4(2),app.Cp,app.R, 200); % calentamiento
            
            h4=valoresCalentamiento.entalpias;
            p4=valoresCalentamiento.presiones;
            v4=valoresCalentamiento.volumen;
            s4=valoresCalentamiento.entropias;
            T4=valoresCalentamiento.temperaturas;
            
             % Expansi�n 1            
             valoresExpansion1=CurvaTrabajo(app.Punto5(2),app.rp3, app.Punto5(1),app.Punto5(5),app.Punto5(3),0, app.eficienciaTurbina1, app.gamma,...
             app.Cp, app.R, 200); % Expansi�n

                        
            h5=valoresExpansion1.entalpias;
            p5=valoresExpansion1.presiones;
            v5=valoresExpansion1.volumen;
            s5=valoresExpansion1.entropias;
            T5=valoresExpansion1.temperaturas;
            
                        
            % Entrop�a
            app.Punto6(5)=s5(end);
            

             % Recalentamiento         
            valoresRecalentamiento=CurvaIsobara(app.Punto6(1),app.Punto6(3),app.Punto6(5), app.Punto7(1),app.Punto6(2),app.Cp,app.R, 200); % calentamiento
            
            h6=valoresRecalentamiento.entalpias;
            p6=valoresRecalentamiento.presiones;
            v6=valoresRecalentamiento.volumen;
            s6=valoresRecalentamiento.entropias;
            T6=valoresRecalentamiento.temperaturas;
            
             % Expansi�n 2            
             valoresExpansion2=CurvaTrabajo(app.Punto7(2),app.rp4, app.Punto7(1),app.Punto7(5),app.Punto7(3),0, app.eficienciaTurbina2, app.gamma,...
             app.Cp,app.R, 200); % Expansi�n

                        
            h7=valoresExpansion2.entalpias;
            p7=valoresExpansion2.presiones;
            v7=valoresExpansion2.volumen;
            s7=valoresExpansion2.entropias;
            T7=valoresExpansion2.temperaturas;
            
                                    
            % Entrop�a
            app.Punto8(5)=s7(end);
            
            % Enfriamiento         
            valoresEnfriamiento=CurvaIsobara(app.Punto8(1),app.Punto8(3),app.Punto8(5), app.Punto1(1),app.Punto8(2),app.Cp,app.R, 200); % calentamiento
            
            h8=valoresEnfriamiento.entalpias;
            p8=valoresEnfriamiento.presiones;
            v8=valoresEnfriamiento.volumen;
            s8=valoresEnfriamiento.entropias;
            T8=valoresEnfriamiento.temperaturas;            
                    
            % Puntos regeneraci�n
            %app.Punto9(5)=app.Punto2(5)+Cp*log(app.Punto9(1)/app.Punto2(1));
            %app.Punto10(5)=app.Punto10(5)-Cp*log(app.Punto10(1)/app.Punto1(1));

            s=[app.Punto1(5),app.Punto2(5),app.Punto3(5),app.Punto4(5),app.Punto5(5),app.Punto6(5)...
               app.Punto7(5),app.Punto8(5),app.Punto9(5),app.Punto10(5) ];
            T=[app.Punto1(1),app.Punto2(1),app.Punto3(1),app.Punto4(1),app.Punto5(1),app.Punto6(1)...
                 app.Punto7(1),app.Punto8(1),app.Punto9(1),app.Punto10(1) ];
    
            % Diagrama p-h
            hold(app.UIAxes_PH,'on');
            plot(app.UIAxes_PH, h, P,'color','r','Marker','o','LineStyle','none'); % Dibuja los puntos
            plot(app.UIAxes_PH, h1, p1,'color','r','Marker','none','LineStyle','-'); %Proceso 1            
            plot(app.UIAxes_PH, h2, p2,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h3, p3,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h4, p4,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h5, p5,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h6, p6,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h7, p7,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h8, p8,'color','r','Marker','none','LineStyle','-');
            hold(app.UIAxes_PH,'off');
            
            app.UIAxes_PH.XLimMode = 'auto';
            app.UIAxes_PH.YLimMode = 'auto';
            
            % Diagrama p-v   
            
            hold(app.UIAxes_PV,'on');
            plot(app.UIAxes_PV, v, P,'color','b','Marker','o','LineStyle','none'); % Dibuja los puntos
            plot(app.UIAxes_PV, v1, p1,'color','b','Marker','none','LineStyle','-'); %Proceso 1            
            plot(app.UIAxes_PV, v2, p2,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v3, p3,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v4, p4,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v5, p5,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v6, p6,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v7, p7,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v8, p8,'color','b','Marker','none','LineStyle','-');

            hold(app.UIAxes_PV,'off');
            
            app.UIAxes_PV.XLimMode = 'auto';
            app.UIAxes_PV.YLimMode = 'auto';

            % Diagrama T-s
            
            hold(app.UIAxes_TS,'on');
            plot(app.UIAxes_TS, s, T,'color','g','Marker','o','LineStyle','none'); % Dibuja los puntos
            plot(app.UIAxes_TS, s1, T1,'color','g','Marker','none','LineStyle','-'); %Proceso 1            
            plot(app.UIAxes_TS, s2, T2,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s3, T3,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s4, T4,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s5, T5,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s6, T6,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s7, T7,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s8, T8,'color','g','Marker','none','LineStyle','-');

            hold(app.UIAxes_TS,'off');
             
            app.UIAxes_TS.XLimMode = 'auto';
            app.UIAxes_TS.YLimMode = 'auto';

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UITable_Procesos.Data={'1-2','Compression - 1';'2-3','Intercooler: heat-rejection';'3-4','Compression - 2';...
               '4-9','Regenerator: heat-addition';'9-5','Combustion chamber: heat-addition';...
               '5-6','Expansion - 1';'6-7','Reheater: heat-addition';'7-8','Expansion - 2';...
               '8-10','Regenerator: heat-rejection';'10-1','Heat exchanger: heat-rejection'};

            app.UITable_Procesos.RowName={};
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
            app.parametros = generadorParametrosRegInter();

             CeldaParametros=num2cell(app.parametros);
            [~,p1,p3,~,p5,p6, app.eficienciaTurbina1,app.eficienciaTurbina2,app.eficienciaCompresor1,app.eficienciaCompresor2,...
                app.rendimientoRegenerador,app.Cp,app.gamma,app.R]=deal(CeldaParametros{:});
         
            app.rp1=p3/p1;
            app.rp2=p5/p3;
            app.rp3=p5/p6;
            app.rp4=p6/p1;
            
                        
        end

        % Button pushed function: EjecutarButton_2
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
            app.UITable_Resultados.Data={};         
            app.UITable_Resultados_2.Data={};           
            
            app.parametros = generadorParametrosRegInter();
            
            
            
            CeldaParametros=num2cell(app.parametros);
            [T1,p1,p3,T5,p5,p6, app.eficienciaTurbina1,app.eficienciaTurbina2,app.eficienciaCompresor1,app.eficienciaCompresor2,...
                app.rendimientoRegenerador,app.Cp,app.gamma,app.R]=deal(CeldaParametros{:});
         
            app.rp1=p3/p1;
            app.rp2=p5/p3;
            app.rp3=p5/p6;
            app.rp4=p6/p1;
            
            app.UITable_DatosIniciales.Data={1,p1,T1; 5,T5,p5};
            app.UITable_DatosIniciales.RowName={};
            
            app.UITable_Eficiencias.Data={app.eficienciaCompresor1,app.eficienciaCompresor2,app.rendimientoRegenerador};
            
            app.UITable_Eficiencias_2.Data={app.eficienciaTurbina1,app.eficienciaTurbina2};
            
            app.UITable_ParametrosAire.Data={app.gamma,app.Cp};
            
            app.UITable_Referencia.Data={app.Treferencia,app.Preferencia,app.hreferencia,app.sreferencia};
            
            app.UITable_DatosIniciales_rp.Data={'Comp. 1',round(app.rp1,3); 'Comp. 2',round(app.rp2,3);'Turb. 1',round(app.rp3,3);...
                'Turb. 2',round(app.rp4,3)};   
            app.UITable_DatosIniciales_rp.RowName={};
            
            
            
        end

        % Button pushed function: MostrargrficosButton
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end

        % Button pushed function: MostrarresultadosButton
        function MostrarresultadosButtonPushed(app, ~)
            MostrargrficosButtonPushed(app, 'push');
            format short        
            
            app.UITable_Resultados.Data={1,round(app.Punto1(2),3),round(app.Punto1(1),1), round(app.Punto1(3),1),round(app.Punto1(5),4),round(app.Punto1(4),4);...
            2,round(app.Punto2(2),3),round(app.Punto2(1),1),round(app.Punto2(3),1),round(app.Punto2(5),4),round(app.Punto2(4),4);...
            3,round(app.Punto3(2),3),round(app.Punto3(1),1),round(app.Punto3(3),1),round(app.Punto3(5),4),round(app.Punto3(4),4);...
            4,round(app.Punto4(2),3),round(app.Punto4(1),1),round(app.Punto4(3),1),round(app.Punto4(5),4),round(app.Punto4(4),4);
            5,round(app.Punto5(2),3),round(app.Punto5(1),1),round(app.Punto5(3),1),round(app.Punto5(5),4),round(app.Punto5(4),4);
            6,round(app.Punto6(2),3),round(app.Punto6(1),1),round(app.Punto6(3),1),round(app.Punto6(5),4),round(app.Punto6(4),4);
            7,round(app.Punto7(2),3),round(app.Punto7(1),1),round(app.Punto7(3),1),round(app.Punto7(5),4),round(app.Punto7(4),4);
            8,round(app.Punto8(2),3),round(app.Punto8(1),1),round(app.Punto8(3),1),round(app.Punto8(5),4),round(app.Punto8(4),4);
            9,round(app.Punto9(2),3),round(app.Punto9(1),1),round(app.Punto9(3),1),round(app.Punto9(5),4),round(app.Punto9(4),4);
            10,round(app.Punto10(2),3),round(app.Punto10(1),1),round(app.Punto10(3),1),round(app.Punto6(5),4),round(app.Punto10(4),4)};
                
        format bank

            app.UITable_Resultados_2.Data={round(app.Q_caldera,1);round(app.Q_Recalentamiento,1);round(app.Q_escape,1);...
                round(app.Q_Interenfriamiento,1);round(app.Q_regenerador,1);round(app.w_compresor1,1);...
                round(app.w_compresor2,1);round(app.w_turbina1,1);round(app.w_turbina2,1);...
                round(app.Eficiencia_termica,3)};
 
            
            
        end

        % Button pushed function: ExportarresultadosButton
        function ExportarresultadosButtonPushed(app, ~)
                        
            Data=get(app.UITable_Resultados,'Data');
            ColumnName=get(app.UITable_Resultados,'ColumnName');
            ColumnName=ColumnName';
            NewData=num2cell(Data);
            T = cell2table(NewData,'VariableNames',ColumnName);
            writetable(T,'Datos del ciclo Brayton Regeneracion_inter_recalentamiento.xls','Sheet','Datos Procesos');
            
            Data1=get(app.UITable_Resultados_2,'Data');
            ColumnName1=get(app.UITable_Resultados_2,'ColumnName');
            ColumnName1=ColumnName1';
            RowName1=get(app.UITable_Resultados_2,'RowName');
            RowName1=RowName1';
            NewData1=num2cell(Data1);
            T1= cell2table(NewData1,'VariableNames',ColumnName1,'RowNames',RowName1);
            writetable(T1,'Datos del ciclo Brayton Regeneracion_inter_recalentamiento.xls','Sheet','Datos ciclo','WriteRowNames',true);

            
            Data2=get(app.UITable_Referencia,'Data');
            ColumnName2=get(app.UITable_Referencia,'ColumnName');
            ColumnName2=ColumnName2';
            NewData2=num2cell(Data2);
            T2 = cell2table(NewData2,'VariableNames',ColumnName2);
            writetable(T2,'Datos del ciclo Brayton Regeneracion_inter_recalentamiento.xls','Sheet','Condiciones Referencia');
                       
            Data3=get(app.UITable_ParametrosAire,'Data');
            ColumnName3=get(app.UITable_ParametrosAire,'ColumnName');
            ColumnName3=ColumnName3';
            NewData3=num2cell(Data3);
            T3 = cell2table(NewData3,'VariableNames',ColumnName3);
            writetable(T3,'Datos del ciclo Brayton Regeneracion_inter_recalentamiento.xls','Sheet','Propiedades Aire');
            
            Data4=get(app.UITable_Eficiencias,'Data');
            ColumnName4=get(app.UITable_Eficiencias,'ColumnName');
            ColumnName4=ColumnName4';
            NewData4=num2cell(Data4);
            T4 = cell2table(NewData4,'VariableNames',ColumnName4);
            writetable(T4,'Datos del ciclo Brayton Regeneracion_inter_recalentamiento.xls','Sheet','Eficiencias Ciclo');
        end

        % Button pushed function: Button_ReferenciaInicial
        function Button_ReferenciaInicialPushed(app, ~)
                       
            app.sreferencia=1.73498; % Entrop�a del aire a 300 K y 1 bar en kJ/kg�K
            app.hreferencia=300.19; % Entalp�a del aire a 300 K y 1 bar en kJ/kg
            app.Treferencia=300; % En K
            app.Preferencia=1; % En bar
            app.UITable_Referencia.Data={app.Treferencia,app.Preferencia,app.hreferencia,app.sreferencia};
           
        end

        % Button pushed function: Button_CondicionesAleatorias
        function Button_CondicionesAleatoriasPushed(app, ~)
                        
            app.sreferencia=random('Uniform',0.8, 2); % Entrop�a del aire kJ/kg�K
            app.hreferencia=random('Uniform',100, 400); % Entalp�a del aire en kJ/kg
            app.Treferencia=random('Uniform',273.15,350); % En K
            app.Preferencia=random('Uniform',1,2.5); % En bar
            app.UITable_Referencia.Data={app.Treferencia,app.Preferencia,app.hreferencia,app.sreferencia};
            
        end

        % Button pushed function: ParmetrostablasButton
        function ParmetrostablasButtonPushed(app, ~)
            app.gamma=1.3747;
            app.Cp=1.0532; 
            app.parametros(12)=1.0532; 
            app.parametros(13)=1.3747;
            app.R=0.28705;
            app.UITable_ParametrosAire.Data={app.gamma,app.Cp};
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 973 733];
            app.UIFigure.Name = 'Brayton Cycle: Intercooling, Reheating, and Regeneration';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [2 0 973 734];

            % Create DatosInicialesTab
            app.DatosInicialesTab = uitab(app.TabGroup);
            app.DatosInicialesTab.Title = 'Initial values';

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.DatosInicialesTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [73 610 333 60];
            app.TextArea_3.Value = {'Brayton Cycle with Intercooling, Reheating, and Regeneration'};

            % Create UITable_DatosIniciales
            app.UITable_DatosIniciales = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'};
            app.UITable_DatosIniciales.ColumnWidth = {60, 'auto', 'auto'};
            app.UITable_DatosIniciales.RowName = {''};
            app.UITable_DatosIniciales.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales.FontWeight = 'bold';
            app.UITable_DatosIniciales.Position = [25 446 422 67];

            % Create TextArea_4
            app.TextArea_4 = uitextarea(app.DatosInicialesTab);
            app.TextArea_4.HorizontalAlignment = 'center';
            app.TextArea_4.FontSize = 18;
            app.TextArea_4.FontWeight = 'bold';
            app.TextArea_4.Position = [73 531 327 30];
            app.TextArea_4.Value = {'Initial values'};

            % Create UIAxes_PH
            app.UIAxes_PH = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH, 'Diagram p-h')
            xlabel(app.UIAxes_PH, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH, 'Pressure (bar)')
            app.UIAxes_PH.Position = [650 437 300 185];

            % Create UIAxes_TS
            app.UIAxes_TS = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS, 'Diagram T-s')
            xlabel(app.UIAxes_TS, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS, 'Temperature (K)')
            app.UIAxes_TS.Position = [650 238 300 185];

            % Create UIAxes_PV
            app.UIAxes_PV = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV, 'Diagram p-v')
            xlabel(app.UIAxes_PV, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV, 'Pressure (bar)')
            app.UIAxes_PV.Position = [650 39 300 185];

            % Create Image
            app.Image = uiimage(app.DatosInicialesTab);
            app.Image.Position = [27 7 182 148];
            app.Image.ImageSource = 'Pollo Blanco.gif';

            % Create UITable_Referencia
            app.UITable_Referencia = uitable(app.DatosInicialesTab);
            app.UITable_Referencia.ColumnName = {'T (K)'; 'P (bar)'; 'h (kJ/kg)'; 's (kJ/kg�K)'};
            app.UITable_Referencia.RowName = {};
            app.UITable_Referencia.ForegroundColor = [0.4941 0.1843 0.5569];
            app.UITable_Referencia.FontWeight = 'bold';
            app.UITable_Referencia.Position = [285 299 343 50];

            % Create TextArea_6
            app.TextArea_6 = uitextarea(app.DatosInicialesTab);
            app.TextArea_6.HorizontalAlignment = 'center';
            app.TextArea_6.FontSize = 18;
            app.TextArea_6.FontWeight = 'bold';
            app.TextArea_6.Position = [338 353 237 30];
            app.TextArea_6.Value = {'Reference state'};

            % Create UITable_ParametrosAire
            app.UITable_ParametrosAire = uitable(app.DatosInicialesTab);
            app.UITable_ParametrosAire.ColumnName = {'Gamma'; 'Cp (kJ/kg�K)'};
            app.UITable_ParametrosAire.RowName = {};
            app.UITable_ParametrosAire.ForegroundColor = [0.8392 0.6706 0.2706];
            app.UITable_ParametrosAire.FontWeight = 'bold';
            app.UITable_ParametrosAire.Position = [27 299 202 50];

            % Create TextArea_7
            app.TextArea_7 = uitextarea(app.DatosInicialesTab);
            app.TextArea_7.HorizontalAlignment = 'center';
            app.TextArea_7.FontSize = 18;
            app.TextArea_7.FontWeight = 'bold';
            app.TextArea_7.Position = [29 353 198 30];
            app.TextArea_7.Value = {'Air-standard'};

            % Create UITable_Eficiencias
            app.UITable_Eficiencias = uitable(app.DatosInicialesTab);
            app.UITable_Eficiencias.ColumnName = {'Efic. comp. 1'; 'Efic. comp. 2'; 'Efic. reg.'};
            app.UITable_Eficiencias.RowName = {};
            app.UITable_Eficiencias.ForegroundColor = [0.4667 0.6745 0.1882];
            app.UITable_Eficiencias.FontWeight = 'bold';
            app.UITable_Eficiencias.Position = [25 215 278 50];

            % Create EjecutarButton_2
            app.EjecutarButton_2 = uibutton(app.DatosInicialesTab, 'push');
            app.EjecutarButton_2.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton_2.Position = [186 579 100 22];
            app.EjecutarButton_2.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [66 420 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [290 420 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Position = [226 91 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [226 58 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Gas power cycles';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [216 23 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create ExportarresultadosButton
            app.ExportarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.ExportarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @ExportarresultadosButtonPushed, true);
            app.ExportarresultadosButton.Position = [431 579 120 22];
            app.ExportarresultadosButton.Text = 'Export results';

            % Create Button_CondicionesAleatorias
            app.Button_CondicionesAleatorias = uibutton(app.DatosInicialesTab, 'push');
            app.Button_CondicionesAleatorias.ButtonPushedFcn = createCallbackFcn(app, @Button_CondicionesAleatoriasPushed, true);
            app.Button_CondicionesAleatorias.Position = [329 272 135 22];
            app.Button_CondicionesAleatorias.Text = 'Change reference state';

            % Create Button_ReferenciaInicial
            app.Button_ReferenciaInicial = uibutton(app.DatosInicialesTab, 'push');
            app.Button_ReferenciaInicial.ButtonPushedFcn = createCallbackFcn(app, @Button_ReferenciaInicialPushed, true);
            app.Button_ReferenciaInicial.Position = [479 272 120 22];
            app.Button_ReferenciaInicial.Text = 'Initial reference state';

            % Create UITable_Eficiencias_2
            app.UITable_Eficiencias_2 = uitable(app.DatosInicialesTab);
            app.UITable_Eficiencias_2.ColumnName = {'Efic. turbine 1'; 'Efic. turbine 2'};
            app.UITable_Eficiencias_2.RowName = {};
            app.UITable_Eficiencias_2.ForegroundColor = [0.4667 0.6745 0.1882];
            app.UITable_Eficiencias_2.FontWeight = 'bold';
            app.UITable_Eficiencias_2.Position = [25 160 261 50];

            % Create UITable_DatosIniciales_rp
            app.UITable_DatosIniciales_rp = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales_rp.ColumnName = {'Unit'; 'pr'};
            app.UITable_DatosIniciales_rp.ColumnWidth = {90, 'auto'};
            app.UITable_DatosIniciales_rp.RowName = {''};
            app.UITable_DatosIniciales_rp.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales_rp.FontWeight = 'bold';
            app.UITable_DatosIniciales_rp.Position = [461 407 172 110];

            % Create TextArea_9
            app.TextArea_9 = uitextarea(app.DatosInicialesTab);
            app.TextArea_9.HorizontalAlignment = 'center';
            app.TextArea_9.FontSize = 18;
            app.TextArea_9.FontWeight = 'bold';
            app.TextArea_9.Position = [461 521 172 30];
            app.TextArea_9.Value = {'Pressure ratios'};

            % Create ParmetrostablasButton
            app.ParmetrostablasButton = uibutton(app.DatosInicialesTab, 'push');
            app.ParmetrostablasButton.ButtonPushedFcn = createCallbackFcn(app, @ParmetrostablasButtonPushed, true);
            app.ParmetrostablasButton.Position = [35 272 180 22];
            app.ParmetrostablasButton.Text = 'Change Air-standard properties';

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Results';

            % Create UITable_Resultados
            app.UITable_Resultados = uitable(app.ResultadosTab);
            app.UITable_Resultados.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados.RowName = {};
            app.UITable_Resultados.ColumnWidth = {45, 'auto'};
            app.UITable_Resultados.Position = [37 387 590 244];

            % Create TextArea_5
            app.TextArea_5 = uitextarea(app.ResultadosTab);
            app.TextArea_5.HorizontalAlignment = 'center';
            app.TextArea_5.FontSize = 18;
            app.TextArea_5.FontWeight = 'bold';
            app.TextArea_5.Position = [37 642 327 30];
            app.TextArea_5.Value = {'Results of the cycle'};

            % Create UITable_Resultados_2
            app.UITable_Resultados_2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2.ColumnName = {'Q and W exchanged'};
            app.UITable_Resultados_2.RowName = {'q (in) (kJ/kg)'; 'q (reheat) (kJ/kg)'; 'q (out) (kJ/kg)'; 'q (intercooling) (kJ/kg)'; 'q (regeneration) (kJ/kg)'; 'w (compressor 1) (kJ/kg)'; 'w (compressor 2) (kJ/kg'; 'w (turbine 1) (kJ/kg)'; 'w (turbine 2 ) (kJ/kg)'; 'Thermal efficiency'};
            app.UITable_Resultados_2.Position = [635 387 330 244];

            % Create Image2
            app.Image2 = uiimage(app.ResultadosTab);
            app.Image2.ScaleMethod = 'fit';
            app.Image2.Position = [37 35 400 340];
            app.Image2.ImageSource = 'CicloBrayton_inter_recalentamiento.png';

            % Create UITable_Procesos
            app.UITable_Procesos = uitable(app.ResultadosTab);
            app.UITable_Procesos.ColumnName = {'Process'; 'Description'};
            app.UITable_Procesos.ColumnWidth = {60, 'auto'};
            app.UITable_Procesos.RowName = {''};
            app.UITable_Procesos.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Procesos.FontWeight = 'bold';
            app.UITable_Procesos.FontSize = 14;
            app.UITable_Procesos.Position = [516 35 430 272];

            % Create TextArea_8
            app.TextArea_8 = uitextarea(app.ResultadosTab);
            app.TextArea_8.HorizontalAlignment = 'center';
            app.TextArea_8.FontSize = 18;
            app.TextArea_8.FontWeight = 'bold';
            app.TextArea_8.Position = [680 323 199 30];
            app.TextArea_8.Value = {'Processes'};

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = BraytonRegIntRe

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end