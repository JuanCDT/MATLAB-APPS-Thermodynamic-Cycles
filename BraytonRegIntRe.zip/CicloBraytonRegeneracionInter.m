function solucion=CicloBraytonRegeneracionInter(parametros,h1)
    
    % h1 es la entalp�a a la entrada del compresor (referencia)
    
        
    % punto 1 - entrada compresor 1
    % punto 2 - salida compresor 1   
    % punto 3- entrada compresor 2
    % punto 4 - salida compresor 2
    
    % punto 5 - entrada turbina 1
    % punto 6 - salida turbina 1   
    % punto 7- entrada turbina 2
    % punto 8 - salida turbina 2
    
    % punto 9 - salida regenerador (fluido caliente a alta presi�n)
    % punto 10 - entrada regenerador (fluido fr�o a baja presi�n)
    
    
    EntradaCompresor=parametros(1:2);
    P3=parametros(3);
    EntradaTurbina=parametros(4:5);
    P6=parametros(6);
    eficienciaRegenerador=parametros(11);
    Cp=parametros(12);
    gamma=parametros(13);    
   
    P1=EntradaCompresor(2); % En bar
    P5=EntradaTurbina(2); % En bar
    T1= EntradaCompresor(1);
    T5= EntradaTurbina(1);  
    rp1=P3/P1;
    rp2=P5/P3;
    rp3=P5/P6;
    rp4=P6/P1;
    P4=P5;
    
    eficienciaTurbina1=parametros(7);
    eficienciaTurbina2=parametros(8);
    eficienciaCompresor1=parametros(9);
    eficienciaCompresor2=parametros(10);
    P2=P3;
    
    
    % Calculo compresor 1
    [T2, h2, T2_ideal, w_compresor1] = Compresor(T1, P1, h1, rp1,eficienciaCompresor1, gamma, Cp);
    
    
    % Para todo el generador la temperatura de salida del interenfriamiento
    % es igual a la de entrada al primer compresor
        
    % Calculo interenfriamiento
    T3=T1;
    h3=h1;
    Q_Interenfriamiento=h2-h1;
            
    % Calculo compresor 2
    [T4, h4, T4_ideal, w_compresor2] = Compresor(T3, P3, h3, rp2,eficienciaCompresor2, gamma, Cp);
    
    % Calculo caldera
    h5=h4+Cp*(T5-T4);
    Q_caldera=h5-h4;
    
    % Calculo turbina1
    [T6,h6, T6_ideal, w_turbina1] = Turbina(T5, P5, h5, rp3,eficienciaTurbina1, gamma, Cp);
    
        % Para todo el generador de problemas la temperatura de salida del
        % recalentamiento es igual a la de entrada en la primera turbina
        
    % Calculo recalentamiento
    T7=T5;
    h7=h5;
    P7=P6;
    Q_Recalentamiento=h7-h6;
    
    % Calculo turbina2
    [T8,h8, T8_ideal, w_turbina2] = Turbina(T7, P7, h7, rp4,eficienciaTurbina2, gamma, Cp);
    P8=P1;
         
    % Calculo escape
    Q_escape=h8-h1;
    
    % Regeneradores
    Q_regeneradorIdeal=h8-h4;
    Q_regenerador=Q_regeneradorIdeal*eficienciaRegenerador;
    h9=h4+Q_regenerador;
    T9=Q_regenerador/Cp+T4;
    P9=P4;
    h10=h8-Q_regenerador;
    T10=T8-Q_regenerador/Cp;
    P10=P1;
    
    Q_salida=Q_escape+Q_Interenfriamiento-Q_regenerador;
    Q_entrada=Q_Recalentamiento+Q_caldera-Q_regenerador;
    
    % C�lculo eficiencia t�rmica del ciclo
    Eficiencia_termica=1-Q_salida/Q_entrada; % en kJ/kg
    
    SalidaCompresor1=[T2,P2, T2_ideal,h2];
    EntradaCompresor2=[T3,P3,h3];
    SalidaCompresor2=[T4,P4, T4_ideal,h4];
    
    SalidaTurbina1=[T6,P6, T6_ideal,h6];
    EntradaTurbina2=[T7,P7,h7];
    SalidaTurbina2=[T8,P8, T8_ideal,h8];
    
    SalidaRegenerador1=[T9,P9,h9];
    SalidaRegenerador2=[T10,P10, h10];
    
    Trabajos=[w_turbina1,w_turbina2, w_compresor1, w_compresor2];
    Calores=[Q_caldera,Q_Recalentamiento,Q_escape, Q_Interenfriamiento,Q_entrada,Q_salida,Q_regenerador];
    
    solucion=[SalidaCompresor1, EntradaCompresor2, SalidaCompresor2,...
        SalidaTurbina1, EntradaTurbina2,SalidaTurbina2,...
        SalidaRegenerador1, SalidaRegenerador2,Trabajos,Calores,Eficiencia_termica];
   
end