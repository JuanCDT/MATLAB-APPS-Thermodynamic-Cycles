classdef Datos_termodinamicos < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                 matlab.ui.Figure
        UITable_Resultados       matlab.ui.control.Table
        TextArea_3               matlab.ui.control.TextArea
        Image_1                  matlab.ui.control.Image
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        TextArea_1               matlab.ui.control.TextArea
        UITable_DatosIniciales   matlab.ui.control.Table
        TextArea_2               matlab.ui.control.TextArea
        EjecutarButton           matlab.ui.control.Button
        MostrargrficosButton     matlab.ui.control.Button
        MostrarresultadosButton  matlab.ui.control.Button
        UIAxes_PH                matlab.ui.control.UIAxes
        UIAxes_TS                matlab.ui.control.UIAxes
        UIAxes_PV                matlab.ui.control.UIAxes
    end

    
    properties (Access = private)        
       
        
        fluido='water';
            
        Datos=[];CasoElegido=char(),Caso=[];
        
        Propiedades={'Temperature (�C)', 'Pressure (kPa)','Enthalpy (kJ/kg)','Entropy (kJ/kg�K)',...
                'Specific volume (m3/kg)', 'Quality'};
        estado;
        Tc=647.096; % Temp. cr�tica del agua en K
        Pc=22064000.0/1000; % Presi�n. cr�tica del agua en kPa
        
        IndiceValoresConocidos;

        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)
            
           % T_C,P,h,s,v
            
           % Domo saturacion
           %T_Final=app.Punto3(1)+5;
           T_Inicial=273.15;
           
           valores_VaporSaturado=CurvaVaporSaturado(T_Inicial, app.Tc, 500);
           valores_LiquidoSaturado=CurvaLiquidoSaturado(T_Inicial, app.Tc, 500);
           
           
            h_VaporSaturado=valores_VaporSaturado.entalpias;
            p_VaporSaturado=valores_VaporSaturado.presiones*1E2; % de bar a kPa;
            v_VaporSaturado=valores_VaporSaturado.volumen;
            s_VaporSaturado=valores_VaporSaturado.entropias;
            T_VaporSaturado=valores_VaporSaturado.temperaturas;
            
            h_LiquidoSaturado=valores_LiquidoSaturado.entalpias;
            p_LiquidoSaturado=valores_LiquidoSaturado.presiones*1E2;
            v_LiquidoSaturado=valores_LiquidoSaturado.volumen;
            s_LiquidoSaturado=valores_LiquidoSaturado.entropias;
            T_LiquidoSaturado=valores_LiquidoSaturado.temperaturas;
 
            % Diagrama p-h
            hold(app.UIAxes_PH,'on');
            
            app.UIAxes_PH.YScale = 'log';
            
            %domo
            plot(app.UIAxes_PH,  h_LiquidoSaturado,p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH,  h_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, app.Datos(3), app.Datos(2),'Marker','o','MarkerFaceColor','r','MarkerEdgeColor','r','LineStyle','none');
      

            hold(app.UIAxes_PH,'off');
            
            app.UIAxes_PH.XLimMode = 'auto';
            app.UIAxes_PH.YLimMode = 'auto';
 
            % Diagrama p-v
     
            
            hold(app.UIAxes_PV,'on');
            
            app.UIAxes_PV.YScale = 'log';
            app.UIAxes_PV.XScale = 'log';
            
%             % domo
            plot(app.UIAxes_PV, v_LiquidoSaturado, p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, app.Datos(5), app.Datos(2),'Marker','o','MarkerFaceColor','b','MarkerEdgeColor','b','LineStyle','none');

            hold(app.UIAxes_PV,'off');
            
            app.UIAxes_PV.XLimMode = 'auto';
            app.UIAxes_PV.YLimMode = 'auto';

            
            % Diagrama T-s
            
           hold(app.UIAxes_TS,'on');         
           
%             
%             % domo

            T=(app.Datos(1)+273.15);
            plot(app.UIAxes_TS, s_LiquidoSaturado, T_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_VaporSaturado, T_VaporSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, app.Datos(4) ,T,'Marker','o','MarkerFaceColor','g','MarkerEdgeColor','g','LineStyle','none');

            hold(app.UIAxes_TS,'off');
             
            app.UIAxes_TS.XLimMode = 'auto';
            app.UIAxes_TS.YLimMode = 'auto';

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
                 
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
                        
        end

        % Button pushed function: EjecutarButton
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)

            [app.Datos,app.CasoElegido,app.Caso]=generadorDatos();   
            
            app.UITable_Resultados.Data={''}; 
            app.UITable_Resultados.RowName={''};
            app.UITable_Resultados.ColumnName = {''; 'Value'};
            

            if app.Caso==2
                app.IndiceValoresConocidos=[];
                app.IndiceValoresConocidos=randperm(6);                
            else
                app.IndiceValoresConocidos=[];
                app.IndiceValoresConocidos=randperm(5);                
            end
            
            
            app.UITable_DatosIniciales.ColumnName = {''; 'Value'};
            app.UITable_DatosIniciales.RowName={char(app.Propiedades(app.IndiceValoresConocidos(1)));...
                char(app.Propiedades(app.IndiceValoresConocidos(2)))};
            
            app.UITable_DatosIniciales.Data={app.Datos(app.IndiceValoresConocidos(1));app.Datos(app.IndiceValoresConocidos(2))};    
            


        end

        % Callback function
        function MostrarresultadosButtonPushed(app, ~)
            Diagramas(app);
            format shortG     
            
           if app.Caso==2 && ((app.IndiceValoresConocidos(1)==1 || app.IndiceValoresConocidos(2)==1) && ...
                   (app.IndiceValoresConocidos(1)==2 || app.IndiceValoresConocidos(2)==2))
               app.estado=char(app.CasoElegido);                
                
               app.UITable_Resultados.Data={app.estado; 'Ambiguous results: the quality of the steam cannot be known'};
               
               app.UITable_Resultados.ColumnName = {''; 'Value'};
               app.UITable_Resultados.RowName={'State';''};
               
                
           elseif app.Caso==2
               app.estado=char(app.CasoElegido);   
                              
               
               app.UITable_Resultados.Data={app.Datos(app.IndiceValoresConocidos(3));...
                    app.Datos(app.IndiceValoresConocidos(4)); app.Datos(app.IndiceValoresConocidos(5));...
                    app.Datos(app.IndiceValoresConocidos(6));app.estado};

               app.UITable_Resultados.ColumnName = {''; 'Value'};
               app.UITable_Resultados.RowName={char(app.Propiedades(app.IndiceValoresConocidos(3)));...
                   char(app.Propiedades(app.IndiceValoresConocidos(4)));...
                   char(app.Propiedades(app.IndiceValoresConocidos(5)));...
                   char(app.Propiedades(app.IndiceValoresConocidos(6)));'State'};
                
            else
                app.estado=char(app.CasoElegido);
                
                app.UITable_Resultados.Data={app.Datos(app.IndiceValoresConocidos(3));...
                        app.Datos(app.IndiceValoresConocidos(4)); app.Datos(app.IndiceValoresConocidos(5));app.estado};
                
                app.UITable_Resultados.ColumnName = {''; 'Value'};
                app.UITable_Resultados.RowName={char(app.Propiedades(app.IndiceValoresConocidos(3)));...
                    char(app.Propiedades(app.IndiceValoresConocidos(4)));...
                   char(app.Propiedades(app.IndiceValoresConocidos(5)));'State'};
            end
            
            
           
            
        end

        % Callback function
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 895 671];
            app.UIFigure.Name = 'Thermodynamic Properties: water/steam';

            % Create Image_1
            app.Image_1 = uiimage(app.UIFigure);
            app.Image_1.Position = [31 15 182 148];
            app.Image_1.ImageSource = 'Pollo Transparente.gif';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1 = uilabel(app.UIFigure);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1.Position = [230 106 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_1.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.UIFigure);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [230 66 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Themodynamic Properties';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.UIFigure);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [220 31 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create TextArea_1
            app.TextArea_1 = uitextarea(app.UIFigure);
            app.TextArea_1.HorizontalAlignment = 'center';
            app.TextArea_1.FontSize = 18;
            app.TextArea_1.FontWeight = 'bold';
            app.TextArea_1.Position = [56 603 327 60];
            app.TextArea_1.Value = {'Thermodynamic Properties water/steam'};

            % Create UITable_DatosIniciales
            app.UITable_DatosIniciales = uitable(app.UIFigure);
            app.UITable_DatosIniciales.ColumnName = {''; 'Value'};
            app.UITable_DatosIniciales.RowName = {''};
            app.UITable_DatosIniciales.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales.FontWeight = 'bold';
            app.UITable_DatosIniciales.Position = [8 444 455 70];

            % Create TextArea_2
            app.TextArea_2 = uitextarea(app.UIFigure);
            app.TextArea_2.HorizontalAlignment = 'center';
            app.TextArea_2.FontSize = 18;
            app.TextArea_2.FontWeight = 'bold';
            app.TextArea_2.Position = [56 524 327 30];
            app.TextArea_2.Value = {'Initial values'};

            % Create EjecutarButton
            app.EjecutarButton = uibutton(app.UIFigure, 'push');
            app.EjecutarButton.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton.Position = [169 573 100 22];
            app.EjecutarButton.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.UIFigure, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [56 346 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.UIFigure, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [268 346 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create UIAxes_PH
            app.UIAxes_PH = uiaxes(app.UIFigure);
            title(app.UIAxes_PH, 'Diagram p-h')
            xlabel(app.UIAxes_PH, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH, 'Pressure (kPa)')
            app.UIAxes_PH.PlotBoxAspectRatio = [1.92307692307692 1 1];
            app.UIAxes_PH.Position = [568 444 300 185];

            % Create UITable_Resultados
            app.UITable_Resultados = uitable(app.UIFigure);
            app.UITable_Resultados.ColumnName = {''; 'Value'};
            app.UITable_Resultados.RowName = {''};
            app.UITable_Resultados.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Resultados.FontWeight = 'bold';
            app.UITable_Resultados.Position = [8 196 455 115];

            % Create UIAxes_TS
            app.UIAxes_TS = uiaxes(app.UIFigure);
            title(app.UIAxes_TS, 'Diagram T-s')
            xlabel(app.UIAxes_TS, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS, 'Temperature (K)')
            app.UIAxes_TS.Position = [568 245 300 185];

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.UIFigure);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [57 388 327 30];
            app.TextArea_3.Value = {'Results'};

            % Create UIAxes_PV
            app.UIAxes_PV = uiaxes(app.UIFigure);
            title(app.UIAxes_PV, 'Diagram p-v')
            xlabel(app.UIAxes_PV, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV, 'Pressure (kPa)')
            app.UIAxes_PV.Position = [568 46 300 185];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = Datos_termodinamicos

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end