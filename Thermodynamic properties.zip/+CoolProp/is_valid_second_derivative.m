function varargout = is_valid_second_derivative(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(152,varargin{:});
end
