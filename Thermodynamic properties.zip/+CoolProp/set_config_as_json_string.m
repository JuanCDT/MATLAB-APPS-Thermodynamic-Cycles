function varargout = set_config_as_json_string(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(452,varargin{:});
end
