function [Datos,CasoElegido,Caso]=generadorDatos(varargin)

    numArgumentos = nargin;
    if numArgumentos > 1
        error('La funci�n tiene m�s par�metros de los permitidos: n�mero de puntos');
    end

    % Se definen los valores por defecto de los par�metros: Caso aleatorio
    optargs = {randi([1,7])};

    % Sustituye los valores por defecto si se ha introducido el par�metro
    % opcional
    optargs(1:numArgumentos) = varargin;
    
    % Asignaci�n a la variable Caso
    Caso=optargs{:};
    
    Tipo_Caso={'Compressed liquid water';'Wet steam';'Superheated steam';...
        'Gas';'Supercritical fluid';'Saturated liquid';'Saturated steam'};
    CasoElegido=char(Tipo_Caso(Caso));
    
    fluido='water';
    Tc=647.096; % Temp. cr�tica del agua en K
    Pc=22064000.0/1000; % Presi�n. cr�tica del agua en kPa
    Pc_max= 1E6 ; % Presi�n m�xima permitida   en kPa
    
    % Casos
    % 1: L�q. subenfriado; 2: Vapor h�medo; 3: Vapor sobrecalentado; 4:
    % gas; 5: Fluido supercr�tico; 6: L�quido saturado; 7: Vapor saturado
    
    while 1
        try
           switch Caso
                case 1 % 1: L�q. subenfriado
                    T=round(random('Uniform',300,Tc-5),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    P_LS=CoolProp.PropsSI('P', 'T', T, 'Q', 0, fluido)/1000; % en kPa
                    P=round(random('Uniform',P_LS,Pc-100),1);
                    h=round(CoolProp.PropsSI('H', 'T', T, 'P', P*1000, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T, 'P', P*1000, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'P', P*1000, fluido)^-1,5); % en kJ/kg�K

                case 2 % 2: Vapor h�medo
                    T=round(random('Uniform',300,Tc-5),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    Q=round(rand(),3); % Temp. en �C
                    P=round(CoolProp.PropsSI('P', 'T', T, 'Q',  Q, fluido)/1000,1); % en kPa
                    h=round(CoolProp.PropsSI('H', 'T', T, 'Q',  Q, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T,'Q',  Q, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'Q',  Q, fluido)^-1,5); % en kJ/kg�K          

                case 3 %  3: Vapor sobrecalentado
                    T=round(random('Uniform',373.15,Tc-5),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    P_VS=CoolProp.PropsSI('P', 'T', T, 'Q', 1, fluido)/1000; % en kPa
                    P=round(random('Uniform',50,P_VS-1),1);
                    h=round(CoolProp.PropsSI('H', 'T', T, 'P', P*1000, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T, 'P', P*1000, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'P', P*1000, fluido)^-1,5); % en kJ/kg�K                 

                case 4 % 4: gas
                    T=round(random('Uniform',Tc+5,2000),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    P=round(random('Uniform',101.330,Pc-100),1);
                    h=round(CoolProp.PropsSI('H', 'T', T, 'P', P*1000, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T, 'P', P*1000, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'P', P*1000, fluido)^-1,5); % en kJ/kg�K                            

                case 5 % 5: Fluido supercr�tico

                    T=round(random('Uniform',Tc+5,2000),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    P=round(random('Uniform',Pc+100,Pc_max-100),1);
                    h=round(CoolProp.PropsSI('H', 'T', T, 'P', P*1000, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T, 'P', P*1000, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'P', P*1000, fluido)^-1,5); % en kJ/kg�K      


                case 6 % 6: L�quido saturado
                    T=round(random('Uniform',300,Tc-5),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    P=round(CoolProp.PropsSI('P', 'T', T, 'Q',  0, fluido)/1000,1); % en kPa
                    h=round(CoolProp.PropsSI('H', 'T', T, 'Q',  0, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T,'Q',  0, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'Q',  0, fluido)^-1,5); % en kJ/kg�K  


                case 7 % 7: vapor saturado

                    T=round(random('Uniform',300,Tc-5),1); % T en K
                    T_C=T-273.15; % Temp. en �C
                    P=round(CoolProp.PropsSI('P', 'T', T, 'Q',  1, fluido)/1000,1); % en kPa
                    h=round(CoolProp.PropsSI('H', 'T', T, 'Q',  1, fluido)/1000,1); % en kJ/kg
                    s=round(CoolProp.PropsSI('S', 'T', T,'Q',  1, fluido)/1000,3); % en kJ/kg�K
                    v=round(CoolProp.PropsSI('D', 'T', T, 'Q',  1, fluido)^-1,5); % en kJ/kg�K 
            end
            break
        catch
            continue
        end
        
    end
    if Caso==2
        Datos=[T_C,P,h,s,v,Q];
        
    else
        Datos=[T_C,P,h,s,v];
    end
    
end
            
        
        
    
   