function varargout = get_global_param_string(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(352,varargin{:});
end
