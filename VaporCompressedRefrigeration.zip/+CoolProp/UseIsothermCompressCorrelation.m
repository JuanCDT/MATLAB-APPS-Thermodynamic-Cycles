function varargout = UseIsothermCompressCorrelation(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(458,varargin{:});
end
