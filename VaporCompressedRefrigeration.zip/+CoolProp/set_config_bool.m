function varargout = set_config_bool(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(449,varargin{:});
end
