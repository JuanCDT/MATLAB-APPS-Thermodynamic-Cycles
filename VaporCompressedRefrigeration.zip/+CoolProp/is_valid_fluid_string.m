function varargout = is_valid_fluid_string(varargin)
  [varargout{1:max(1,nargout)}] = CoolPropMATLAB_wrap(354,varargin{:});
end
