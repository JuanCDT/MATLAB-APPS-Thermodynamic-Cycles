classdef VaporCompressedRefrigeration < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        TabGroup                     matlab.ui.container.TabGroup
        DatosInicialesTab            matlab.ui.container.Tab
        TextArea_3                   matlab.ui.control.TextArea
        UITable_DatosIniciales       matlab.ui.control.Table
        TextArea_4                   matlab.ui.control.TextArea
        UIAxes_PH                    matlab.ui.control.UIAxes
        UIAxes_TS                    matlab.ui.control.UIAxes
        UIAxes_PV                    matlab.ui.control.UIAxes
        Image                        matlab.ui.control.Image
        EjecutarButton_2             matlab.ui.control.Button
        MostrargrficosButton         matlab.ui.control.Button
        MostrarresultadosButton      matlab.ui.control.Button
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        ExportarresultadosButton     matlab.ui.control.Button
        RefrigeranteListBoxLabel     matlab.ui.control.Label
        RefrigeranteListBox          matlab.ui.control.ListBox
        RefrigseleccionadoEditFieldLabel  matlab.ui.control.Label
        RefrigseleccionadoEditField  matlab.ui.control.EditField
        ResultadosTab                matlab.ui.container.Tab
        UITable_Resultados           matlab.ui.control.Table
        TextArea_5                   matlab.ui.control.TextArea
        UITable_Resultados_2         matlab.ui.control.Table
        Image2                       matlab.ui.control.Image
        UITable_Procesos             matlab.ui.control.Table
        TextArea_8                   matlab.ui.control.TextArea
    end

    
    properties (Access = private)        
       
        parametros=[];
        refrigerante=[];T1=[];p1=[];T3=[];p3=[];
        eficienciaCompresor=[];sobrecalentamiento=[];subenfriamiento=[];
        TCritica=struct('R22',369.295,'R134a',374.21,'R507A',343.765,'R404A',345.27,'R407C',359.345,'R410A',344.494);
        Punto1=[], Punto2=[]; Punto3=[]; Punto4=[]; tituloVapor=[];
        solucion=[];      
        w_compresor=[];CF_refrigeracion=[];CF_calefaccion=[]; Q_condensador=[]; Q_evaporador=[];
        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)
            
            
            
            app.solucion=CicloRefrigeracion(app.refrigerante,app.parametros);
            app.Punto2=app.solucion(1:3);
            app.Punto4=app.solucion(4:6);
            
            app.tituloVapor=app.solucion(7);
            
            % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K).  
            if app.sobrecalentamiento==0
                
                h1=CoolProp.PropsSI('H', 'Q', 1, 'T', app.T1, app.refrigerante)/1000; % en kJ/kg
                v1=CoolProp.PropsSI('D', 'Q', 1, 'T', app.T1, app.refrigerante)^-1; % en m3/kg
                s1=CoolProp.PropsSI('S', 'Q', 1, 'T', app.T1, app.refrigerante)/1000; % en kJ/kg�K
            else
                h1=CoolProp.PropsSI('H', 'P', app.p1*1E5, 'T', app.T1, app.refrigerante)/1000; % en kJ/kg
                v1=CoolProp.PropsSI('D', 'P', app.p1*1E5, 'T', app.T1, app.refrigerante)^-1;  % en m3/kg
                s1=CoolProp.PropsSI('S', 'P', app.p1*1E5, 'T', app.T1, app.refrigerante)/1000; % en kJ/kg�K
                
            end
            
            if app.subenfriamiento==0
                h3=CoolProp.PropsSI('H', 'Q', 0, 'T', app.T3, app.refrigerante)/1000; % en kJ/kg
                v3=CoolProp.PropsSI('D', 'Q', 0, 'T', app.T3, app.refrigerante)^-1; % en m3/kg
                s3=CoolProp.PropsSI('S', 'Q', 0, 'T', app.T3, app.refrigerante)/1000; % en kJ/kg�K
            else
                h3=CoolProp.PropsSI('H', 'P', app.p3*1E5, 'T', app.T3, app.refrigerante)/1000; % en kJ/kg
                v3=CoolProp.PropsSI('D', 'P', app.p3*1E5, 'T', app.T3, app.refrigerante)^-1;  % en m3/kg
                s3=CoolProp.PropsSI('S', 'P', app.p3*1E5, 'T', app.T3, app.refrigerante)/1000; % en kJ/kg�K
            end  
            
            % entalp�as, vol�menes y entrop�as 2 y4
            v2=CoolProp.PropsSI('D', 'P', app.Punto2(2)*1E5, 'T', app.Punto2(1), app.refrigerante)^-1;  % en m3/kg
            s2=CoolProp.PropsSI('S', 'P', app.Punto2(2)*1E5, 'T', app.Punto2(1), app.refrigerante)/1000; % en kJ/kg�K
            v4=CoolProp.PropsSI('D', 'P', app.Punto4(2)*1E5, 'Q', app.tituloVapor, app.refrigerante)^-1;  % en m3/kg
            s4=CoolProp.PropsSI('S', 'P', app.Punto4(2)*1E5, 'Q', app.tituloVapor, app.refrigerante)/1000; % en kJ/kg�K
                        
            app.Punto1=[app.T1,app.p1,h1,v1,s1];
            app.Punto2(4)=v2;app.Punto2(5)=s2;
            app.Punto3=[app.T3,app.p3,h3,v3,s3];
            app.Punto4(4)=v4;app.Punto4(5)=s4;
            
            
            rp=app.Punto3(2)/app.Punto1(2);
            
            
            app.w_compresor=app.solucion(8);
            app.CF_refrigeracion=app.solucion(9);
            app.CF_calefaccion=app.solucion(10);   
            app.Q_condensador=app.Punto2(3)-app.Punto3(3); 
            app.Q_evaporador=app.Punto1(3)-app.Punto4(3); 
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)           
                        
            % Valores propiedades a lo largo de los procesos
            
            % Puntos del proceso
            
           Entalpias=[app.Punto1(3),app.Punto2(3),app.Punto3(3),app.Punto4(3)];
           Temperaturas=[app.Punto1(1),app.Punto2(1),app.Punto3(1),app.Punto4(1)];
           Presiones=[app.Punto1(2),app.Punto2(2),app.Punto3(2),app.Punto4(2)];
           Volumenes=[app.Punto1(4),app.Punto2(4),app.Punto3(4),app.Punto4(4)];
           Entropias=[app.Punto1(5),app.Punto2(5),app.Punto3(5),app.Punto4(5)];
           
           % Domo saturacion
           
           T_Inicial=app.Punto4(1)-5;           
           Tc=app.TCritica.(app.refrigerante);
           
           valores_VaporSaturado=CurvaVaporSaturado(T_Inicial, Tc,app.refrigerante, 500);
           valores_LiquidoSaturado=CurvaLiquidoSaturado(T_Inicial, Tc,app.refrigerante, 500);
           
            h_VaporSaturado=valores_VaporSaturado.entalpias;
            p_VaporSaturado=valores_VaporSaturado.presiones;
            v_VaporSaturado=valores_VaporSaturado.volumen;
            s_VaporSaturado=valores_VaporSaturado.entropias;
            T_VaporSaturado=valores_VaporSaturado.temperaturas;
            
            h_LiquidoSaturado=valores_LiquidoSaturado.entalpias;
            p_LiquidoSaturado=valores_LiquidoSaturado.presiones;
            v_LiquidoSaturado=valores_LiquidoSaturado.volumen;
            s_LiquidoSaturado=valores_LiquidoSaturado.entropias;
            T_LiquidoSaturado=valores_LiquidoSaturado.temperaturas;
            
            % Proceso 1 - Compresi�n
            valoresProceso1=CurvaCompresorRefrigerantes(app.Punto1(2),rp, app.Punto1(1),app.Punto1(5),app.Punto1(3),...
                app.eficienciaCompresor, app.refrigerante, app.sobrecalentamiento,200);        
            
            h_Proceso1=valoresProceso1.entalpias;
            p_Proceso1=valoresProceso1.presiones;
            v_Proceso1=valoresProceso1.volumen;
            s_Proceso1=valoresProceso1.entropias;
            T_Proceso1=valoresProceso1.temperaturas;
            
            % Proceso 2 - Condensador
            
            valoresProceso2=CurvaIsobara(app.Punto2(3),app.Punto2(2), app.Punto3(3),app.refrigerante,  200);
            
            v_VS=CoolProp.PropsSI('D', 'P', app.Punto2(2)*1E5, 'Q', 1, app.refrigerante)^-1;  % en m3/kg
            s_VS=CoolProp.PropsSI('S', 'P', app.Punto2(2)*1E5, 'Q', 1, app.refrigerante)/1000; % en kJ/kg�K
            T_VS=CoolProp.PropsSI('T', 'P', app.Punto2(2)*1E5, 'Q', 1, app.refrigerante);  % en K
            h_VS=CoolProp.PropsSI('H', 'P', app.Punto2(2)*1E5, 'Q', 1, app.refrigerante)/1000; % en kJ/kg
            
            valoresProceso2.entalpias(end+1)=h_VS; valoresProceso2.entalpias=sort(valoresProceso2.entalpias);
            valoresProceso2.volumen(end+1)=v_VS; valoresProceso2.volumen=sort(valoresProceso2.volumen);
            valoresProceso2.entropias(end+1)=s_VS; valoresProceso2.entropias=sort(valoresProceso2.entropias);
            valoresProceso2.temperaturas(end+1)=T_VS; valoresProceso2.temperaturas=sort(valoresProceso2.temperaturas);
            valoresProceso2.presiones(end+1)=app.Punto2(2);                              
                
   
            if app.subenfriamiento~=0
                v_LS=CoolProp.PropsSI('D', 'P', app.Punto2(2)*1E5, 'Q', 0, app.refrigerante)^-1;  % en m3/kg
                s_LS=CoolProp.PropsSI('S', 'P', app.Punto2(2)*1E5, 'Q', 0, app.refrigerante)/1000; % en kJ/kg�K
                T_LS=CoolProp.PropsSI('T', 'P', app.Punto2(2)*1E5, 'Q', 0, app.refrigerante);  % en K
                h_LS=CoolProp.PropsSI('H', 'P', app.Punto2(2)*1E5, 'Q', 0, app.refrigerante)/1000; % en kJ/kg
                
                valoresProceso2.entalpias(end+1)=h_LS; valoresProceso2.entalpias=sort(valoresProceso2.entalpias);
                valoresProceso2.volumen(end+1)=v_LS; valoresProceso2.volumen=sort(valoresProceso2.volumen);
                valoresProceso2.entropias(end+1)=s_LS; valoresProceso2.entropias=sort(valoresProceso2.entropias);
                valoresProceso2.temperaturas(end+1)=T_LS; valoresProceso2.temperaturas=sort(valoresProceso2.temperaturas);
                valoresProceso2.presiones(end+1)=app.Punto2(2);   
            end
                        
            h_Proceso2=valoresProceso2.entalpias;
            p_Proceso2=valoresProceso2.presiones;
            v_Proceso2=valoresProceso2.volumen;
            s_Proceso2=valoresProceso2.entropias;
            T_Proceso2=valoresProceso2.temperaturas;
            
            
                        
            % Proceso 3 - Expansion isoentalpica
            
            if app.subenfriamiento==0
                valoresProceso3=CurvaIsentalpicaSaturado(app.Punto3(2),app.Punto3(3), app.Punto4(2),app.refrigerante, 200);      
            else
                valoresProceso3=CurvaIsentalpica(app.Punto3(2),app.Punto3(3), app.Punto4(2),app.refrigerante, 200);  
            end
            
                        
            h_Proceso3=valoresProceso3.entalpias;
            p_Proceso3=valoresProceso3.presiones;
            v_Proceso3=valoresProceso3.volumen;
            s_Proceso3=valoresProceso3.entropias;
            T_Proceso3=valoresProceso3.temperaturas;
            
            % Proceso 4 - Evaporador
            
            valoresProceso4=CurvaIsobara(app.Punto4(3),app.Punto4(2), app.Punto1(3),app.refrigerante,  200);                      
                
   
            if app.sobrecalentamiento~=0
                
                v_VS=CoolProp.PropsSI('D', 'P', app.Punto4(2)*1E5, 'Q', 1, app.refrigerante)^-1;  % en m3/kg
                s_VS=CoolProp.PropsSI('S', 'P', app.Punto4(2)*1E5, 'Q', 1, app.refrigerante)/1000; % en kJ/kg�K
                T_VS=CoolProp.PropsSI('T', 'P', app.Punto4(2)*1E5, 'Q', 1, app.refrigerante);  % en K
                h_VS=CoolProp.PropsSI('H', 'P', app.Punto4(2)*1E5, 'Q', 1, app.refrigerante)/1000; % en kJ/kg
            
                valoresProceso4.entalpias(end+1)=h_VS; valoresProceso4.entalpias=sort(valoresProceso4.entalpias);
                valoresProceso4.volumen(end+1)=v_VS; valoresProceso4.volumen=sort(valoresProceso4.volumen);
                valoresProceso4.entropias(end+1)=s_VS; valoresProceso4.entropias=sort(valoresProceso4.entropias);
                valoresProceso4.temperaturas(end+1)=T_VS; valoresProceso4.temperaturas=sort(valoresProceso4.temperaturas);
                valoresProceso4.presiones(end+1)=app.Punto4(2);                              
                   
            end
                 
                        
            h_Proceso4=valoresProceso4.entalpias;
            p_Proceso4=valoresProceso4.presiones;
            v_Proceso4=valoresProceso4.volumen;
            s_Proceso4=valoresProceso4.entropias;
            T_Proceso4=valoresProceso4.temperaturas;
            
            % Diagrama p-h
            hold(app.UIAxes_PH,'on');
            
            app.UIAxes_PH.YScale = 'log';
            
            %domo
            plot(app.UIAxes_PH,  h_LiquidoSaturado,p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
                        
            % puntos y procesos
            plot(app.UIAxes_PH, Entalpias, Presiones,'color','r','Marker','o','LineStyle','none');
            plot(app.UIAxes_PH, h_Proceso1, p_Proceso1,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso2, p_Proceso2,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso3, p_Proceso3,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, h_Proceso4, p_Proceso4,'color','r','Marker','none','LineStyle','-');

            hold(app.UIAxes_PH,'off');
            
            app.UIAxes_PH.XLimMode = 'auto';
            app.UIAxes_PH.YLimMode = 'auto';
 
            % Diagrama p-v
     
            
            hold(app.UIAxes_PV,'on');
            
            app.UIAxes_PV.YScale = 'log';
            app.UIAxes_PV.XScale = 'log';
            
%             % domo
            plot(app.UIAxes_PV, v_LiquidoSaturado, p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');
            
            
            % puntos y procesos
            plot(app.UIAxes_PV,Volumenes, Presiones,'color','b','Marker','o','LineStyle','none');
            plot(app.UIAxes_PV, v_Proceso1, p_Proceso1,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso2, p_Proceso2,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso3, p_Proceso3,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v_Proceso4, p_Proceso4,'color','b','Marker','none','LineStyle','-');


            hold(app.UIAxes_PV,'off');
            
            app.UIAxes_PV.XLimMode = 'auto';
            app.UIAxes_PV.YLimMode = 'auto';
%             
%             app.UIAxes_PV.XLabel.Interpreter = 'latex';
%             app.UIAxes_PV.XLabel.String='$\textrm(Volumen \quad  espec�fico) \quad  (m^{3}/kg)$';

%             ylabel(app.UIAxes_PV,'$\text(Volumen espec�fico )  (m^{3}/kg)$','Interpreter', 'latex');

            
            % Diagrama T-s
            
           hold(app.UIAxes_TS,'on');
           
           
%             
%             % domo
            plot(app.UIAxes_TS, s_LiquidoSaturado, T_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_VaporSaturado, T_VaporSaturado,'color','k','Marker','none','LineStyle','-');
                        
            % puntos y procesos
            plot(app.UIAxes_TS, Entropias,Temperaturas,'color','g','Marker','o','LineStyle','none');
            plot(app.UIAxes_TS, s_Proceso1, T_Proceso1,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso2, T_Proceso2,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso3, T_Proceso3,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s_Proceso4, T_Proceso4,'color','g','Marker','none','LineStyle','-');


            hold(app.UIAxes_TS,'off');
             
            app.UIAxes_TS.XLimMode = 'auto';
            app.UIAxes_TS.YLimMode = 'auto';

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UITable_Procesos.Data={'1-2','Compression';'2-3','Condenser: heat-rejection';...
               '3-4','Expansion';'4-1','Evaporator: heat-addition'};
            app.UITable_Procesos.RowName={};          
                        
            
            [app.refrigerante,app.parametros] = generadorParametrosRefrigeracion(0);           
                        
            CeldaParametros=num2cell(app.parametros);
            [app.T1,app.p1,app.T3,app.p3,...
                app.eficienciaCompresor,app.sobrecalentamiento,app.subenfriamiento]=deal(CeldaParametros{:});
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
                        
        end

        % Button pushed function: EjecutarButton_2
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
            app.UITable_Resultados.Data={};
            app.UITable_Resultados_2.Data={};
            
            fluido=app.RefrigeranteListBox.Value;
            
            [app.refrigerante,app.parametros] = generadorParametrosRefrigeracion(fluido);
            
            
            
            CeldaParametros=num2cell(app.parametros);
            [app.T1,app.p1,app.T3,app.p3,...
                app.eficienciaCompresor,app.sobrecalentamiento,app.subenfriamiento]=deal(CeldaParametros{:});
            
            app.RefrigseleccionadoEditField.Value=app.refrigerante;
            
            app.UITable_DatosIniciales.Data={app.T1; app.T3;app.sobrecalentamiento;app.subenfriamiento;...
                app.eficienciaCompresor};
            app.UITable_DatosIniciales.ColumnName = {''; 'Value'};
            app.UITable_DatosIniciales.RowName={'Compressor inlet temperature (K)','Compressor outlet temperature (K)',...
                'Superheating - evaporator (K)','Subcooling - condenser (K)'...
                'Eficiency Compressor'};

        end

        % Button pushed function: MostrargrficosButton
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end

        % Button pushed function: MostrarresultadosButton
        function MostrarresultadosButtonPushed(app, ~)
            MostrargrficosButtonPushed(app, 'push');
            format shortG        
            
            app.UITable_Resultados.Data={'1',app.Punto1(2),app.Punto1(1), app.Punto1(3),app.Punto1(5),app.Punto1(4);...
            '2',app.Punto2(2),app.Punto2(1),app.Punto2(3),app.Punto2(5),app.Punto2(4);...
           '3',app.Punto3(2),app.Punto3(1), app.Punto3(3),app.Punto3(5),app.Punto3(4);...
            '4',app.Punto4(2),app.Punto4(1), app.Punto4(3),app.Punto4(5),app.Punto4(4)};

            app.UITable_Resultados_2.Data={app.w_compresor;app.Q_condensador; app.Q_evaporador;...
                app.CF_refrigeracion;app.CF_calefaccion};
 
            
            
        end

        % Button pushed function: ExportarresultadosButton
        function ExportarresultadosButtonPushed(app, ~)
            
            Data=get(app.UITable_Resultados,'Data');
            ColumnName=get(app.UITable_Resultados,'ColumnName');
            ColumnName=ColumnName';
            NewData=num2cell(Data);
            Datos1 = cell2table(NewData,'VariableNames',ColumnName);
            writetable(Datos1,'Datos del ciclo de refrigeracion.xls','Sheet','Datos Procesos');
            
            Data1=get(app.UITable_Resultados_2,'Data');
            ColumnName1=get(app.UITable_Resultados_2,'ColumnName');
            ColumnName1=ColumnName1';
            RowName1=get(app.UITable_Resultados_2,'RowName');
            RowName1=RowName1';
            NewData1=num2cell(Data1);
            Datos2= cell2table(NewData1,'VariableNames',ColumnName1,'RowNames',RowName1);
            writetable(Datos2,'Datos del ciclo de refrigeracion.xls','Sheet','Datos ciclo','WriteRowNames',true);


        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 895 671];
            app.UIFigure.Name = 'Vapor-Compression Refrigeration Cycle';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 -1 895 673];

            % Create DatosInicialesTab
            app.DatosInicialesTab = uitab(app.TabGroup);
            app.DatosInicialesTab.Title = 'Initial values';

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.DatosInicialesTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [64 578 327 60];
            app.TextArea_3.Value = {'Vapor-Compression Refrigeration Cycle'};

            % Create UITable_DatosIniciales
            app.UITable_DatosIniciales = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales.ColumnName = {'Variable'; 'Value'};
            app.UITable_DatosIniciales.RowName = {''};
            app.UITable_DatosIniciales.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales.FontWeight = 'bold';
            app.UITable_DatosIniciales.Position = [16 352 280 132];

            % Create TextArea_4
            app.TextArea_4 = uitextarea(app.DatosInicialesTab);
            app.TextArea_4.HorizontalAlignment = 'center';
            app.TextArea_4.FontSize = 18;
            app.TextArea_4.FontWeight = 'bold';
            app.TextArea_4.Position = [64 499 327 30];
            app.TextArea_4.Value = {'Initial values'};

            % Create UIAxes_PH
            app.UIAxes_PH = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH, 'Diagram p-h')
            xlabel(app.UIAxes_PH, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH, 'Pressure (bar)')
            app.UIAxes_PH.Position = [583 437 300 185];

            % Create UIAxes_TS
            app.UIAxes_TS = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS, 'Diagram T-s')
            xlabel(app.UIAxes_TS, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS, 'Temperature (K)')
            app.UIAxes_TS.Position = [583 238 300 185];

            % Create UIAxes_PV
            app.UIAxes_PV = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV, 'Diagram p-v')
            xlabel(app.UIAxes_PV, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV, 'Pressure (bar)')
            app.UIAxes_PV.Position = [583 39 300 185];

            % Create Image
            app.Image = uiimage(app.DatosInicialesTab);
            app.Image.Position = [27 11 182 148];
            app.Image.ImageSource = 'Pollo Transparente.gif';

            % Create EjecutarButton_2
            app.EjecutarButton_2 = uibutton(app.DatosInicialesTab, 'push');
            app.EjecutarButton_2.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton_2.Position = [177 548 100 22];
            app.EjecutarButton_2.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [57 268 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [281 268 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Position = [226 95 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [226 62 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Refrigeration cycles';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [216 27 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create ExportarresultadosButton
            app.ExportarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.ExportarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @ExportarresultadosButtonPushed, true);
            app.ExportarresultadosButton.Position = [151 219 120 22];
            app.ExportarresultadosButton.Text = 'Export results';

            % Create RefrigeranteListBoxLabel
            app.RefrigeranteListBoxLabel = uilabel(app.DatosInicialesTab);
            app.RefrigeranteListBoxLabel.BackgroundColor = [1 1 1];
            app.RefrigeranteListBoxLabel.HorizontalAlignment = 'center';
            app.RefrigeranteListBoxLabel.FontWeight = 'bold';
            app.RefrigeranteListBoxLabel.Position = [312 461 85 22];
            app.RefrigeranteListBoxLabel.Text = 'Refrigerant';

            % Create RefrigeranteListBox
            app.RefrigeranteListBox = uilistbox(app.DatosInicialesTab);
            app.RefrigeranteListBox.Items = {'Random', 'R22', 'R134a', 'R507A', 'R404A', 'R407C', 'R410A'};
            app.RefrigeranteListBox.ItemsData = {'0', '1', '2', '3', '4', '5', '6'};
            app.RefrigeranteListBox.Position = [404 352 92 132];
            app.RefrigeranteListBox.Value = '0';

            % Create RefrigseleccionadoEditFieldLabel
            app.RefrigseleccionadoEditFieldLabel = uilabel(app.DatosInicialesTab);
            app.RefrigseleccionadoEditFieldLabel.HorizontalAlignment = 'right';
            app.RefrigseleccionadoEditFieldLabel.FontWeight = 'bold';
            app.RefrigseleccionadoEditFieldLabel.Position = [280 313 123 22];
            app.RefrigseleccionadoEditFieldLabel.Text = 'Selected Refrig.';

            % Create RefrigseleccionadoEditField
            app.RefrigseleccionadoEditField = uieditfield(app.DatosInicialesTab, 'text');
            app.RefrigseleccionadoEditField.Position = [404 313 50 22];

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Results';

            % Create UITable_Resultados
            app.UITable_Resultados = uitable(app.ResultadosTab);
            app.UITable_Resultados.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados.RowName = {};
            app.UITable_Resultados.Position = [37 460 620 110];

            % Create TextArea_5
            app.TextArea_5 = uitextarea(app.ResultadosTab);
            app.TextArea_5.HorizontalAlignment = 'center';
            app.TextArea_5.FontSize = 18;
            app.TextArea_5.FontWeight = 'bold';
            app.TextArea_5.Position = [150 589 327 30];
            app.TextArea_5.Value = {'Results of the cycle'};

            % Create UITable_Resultados_2
            app.UITable_Resultados_2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2.ColumnName = {'Heat and work exchanged'};
            app.UITable_Resultados_2.RowName = {'w (compressor) (kJ/kg)'; 'q (condenser) (kJ/kg)'; 'q (evaporator) (kJ/kg)'; 'COP refrigerator'; 'COP heat pump'};
            app.UITable_Resultados_2.Position = [37 299 320 135];

            % Create Image2
            app.Image2 = uiimage(app.ResultadosTab);
            app.Image2.Position = [550 18 306 433];
            app.Image2.ImageSource = 'Ciclo refrigeracion vapor.png';

            % Create UITable_Procesos
            app.UITable_Procesos = uitable(app.ResultadosTab);
            app.UITable_Procesos.ColumnName = {'Process'; 'Description'};
            app.UITable_Procesos.ColumnWidth = {60, 'auto'};
            app.UITable_Procesos.RowName = {''};
            app.UITable_Procesos.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Procesos.FontWeight = 'bold';
            app.UITable_Procesos.FontSize = 14;
            app.UITable_Procesos.Position = [37 76 400 125];

            % Create TextArea_8
            app.TextArea_8 = uitextarea(app.ResultadosTab);
            app.TextArea_8.HorizontalAlignment = 'center';
            app.TextArea_8.FontSize = 18;
            app.TextArea_8.FontWeight = 'bold';
            app.TextArea_8.Position = [45 211 330 30];
            app.TextArea_8.Value = {'Processes'};

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = VaporCompressedRefrigeration

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end