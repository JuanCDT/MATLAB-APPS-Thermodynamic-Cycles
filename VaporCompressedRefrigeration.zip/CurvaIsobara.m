function valores=CurvaIsobara(h_Inicial,P, h_Final,refrigerante,  N_Puntos)


    entalpias= linspace(h_Inicial,h_Final,N_Puntos);    
       
    entropias=ones(1,N_Puntos);
    volumen=ones(1,N_Puntos);
    temperaturas= ones(1,N_Puntos);
    presiones=ones(1,N_Puntos)*P;
    
    
    for i=1:N_Puntos
        entropias(i)=CoolProp.PropsSI('S', 'P', P*1E5, 'H', entalpias(i)*1E3, refrigerante)/1000; % en kJ/kg�K
        volumen(i)=CoolProp.PropsSI('D', 'P', P*1E5, 'H', entalpias(i)*1E3, refrigerante)^-1;  % en m3/kg
        temperaturas(i)=CoolProp.PropsSI('T', 'P', P*1E5, 'H', entalpias(i)*1E3, refrigerante); % en K

    end
    
    valores=struct();
    valores.entalpias=entalpias;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;
    valores.volumen=volumen;
    valores.presiones=presiones;


end