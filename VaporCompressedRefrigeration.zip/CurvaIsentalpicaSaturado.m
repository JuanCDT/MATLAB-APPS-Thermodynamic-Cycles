function valores=CurvaIsentalpicaSaturado(P_Inicial,h, P_Final,refrigerante, N_Puntos)
    
    entalpias=ones(1,N_Puntos)*h;
    entropias=ones(1,N_Puntos);
    volumen=ones(1,N_Puntos);
    presiones= linspace(P_Inicial,P_Final,N_Puntos);
    temperaturas=ones(1,N_Puntos);
    

    Q= 0 ;
    entropias(1)=CoolProp.PropsSI('S', 'Q', Q, 'P',  presiones(1)*1E5, refrigerante)/1000; % en kJ/kg�K
    volumen(1)=CoolProp.PropsSI('D', 'Q', Q, 'P',  presiones(1)*1E5, refrigerante)^-1;  % en m3/kg
    temperaturas(1)=CoolProp.PropsSI('T', 'Q',Q, 'P',  presiones(1)*1E5, refrigerante); % en K 

    
    for i=2:N_Puntos
        
        entropias(i)=CoolProp.PropsSI('S', 'P', presiones(i)*1E5, 'H', h*1E3, refrigerante)/1000; % en kJ/kg�K
        volumen(i)=CoolProp.PropsSI('D', 'P', presiones(i)*1E5, 'H', h*1E3, refrigerante)^-1;  % en m3/kg
        temperaturas(i)=CoolProp.PropsSI('T', 'P', presiones(i)*1E5, 'H', h*1E3, refrigerante); % en K  
        
    end
    
    valores=struct();
    valores.entalpias=entalpias;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;
    valores.presiones=presiones;
    valores.volumen=volumen;


end