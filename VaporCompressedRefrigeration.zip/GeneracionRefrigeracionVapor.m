
clc
close all
clearvars

parametros=generadorParametros();
parametrosCiclo=cell2mat(parametros(2:end));
solucion=CicloRefrigeracion(parametros);
[variablesConocidas,Resultados]=GeneradorCasos(parametros,solucion);

fprintf('Datos de partida (temperatura [K];presi�n [bar]; entalp�a/trabajo/calor [kJ/kg]):\n\n');
disp(variablesConocidas);
fprintf('\n\n');


Evaluador(Resultados);

fprintf('\nResultados (temperatura e incrementos de temperatura [K];presi�n [bar]; entalp�a/trabajo/calor [kJ/kg]):\n\n');
disp(Resultados);

PuntosCiclo=struct();
PuntosCiclo.temperaturas=[parametrosCiclo(1),solucion(1),parametrosCiclo(3),solucion(4)];
PuntosCiclo.presiones=[parametrosCiclo(2),solucion(2),parametrosCiclo(4),solucion(5)];
s2=CoolProp.PropsSI('S', 'P', solucion(2)*1E5, 'T',...
        solucion(1), char(parametros(1)))/1000;
s4=CoolProp.PropsSI('S', 'P',parametrosCiclo(2)*1E5, 'Q',...
        solucion(7), char(parametros(1)))/1000;
PuntosCiclo.entropias=[solucion(13)/1000,s2,solucion(16),s4];
EntradaCompresor=cell2mat(parametros(2));
ValoresdomoT=domoTemperatura(char(parametros(1)),(EntradaCompresor(1)-20));
ValoresdomoP=domoPresion(char(parametros(1)),(EntradaCompresor(2)-0.5));
% 
DiagramaPhyPv(char(parametros(1)),PuntosCiclo,ValoresdomoP, cell2mat(parametros(4:end)),solucion);
DiagramaTs(char(parametros(1)),PuntosCiclo,ValoresdomoT,solucion);


% clearvars

function parametros=generadorParametros()

    ListaFluidos={'R22', 'R134a', 'R507A', 'R404A', 'R407C', 'R410A'};
    
    % Selecci�n del refrigerante
    indice=randi([1 6]);
    refrigerante=char(ListaFluidos(indice));
    
    % Problema con compresi�n ideal o real
    a=randi([0 1]);
    if a
        eficienciaCompresor=1;
    else
        eficienciaCompresor = random('Uniform',0.7, 0.95);
    end
    
    % Define si el problema es con subenfriamiento, sobrecalentamiento o
    % ambos casos
   
    b=randi([0 1]);c=randi([0 1]);

    if c && b
        sobrecalentamiento=random('Uniform',2, 10);
        subenfriamiento=random('Uniform',2, 5);
    elseif c
        sobrecalentamiento=random('Uniform',2, 10);
        subenfriamiento =0;
    elseif b
        sobrecalentamiento=0;
        subenfriamiento =random('Uniform',2, 10);
    else
        sobrecalentamiento=0;
        subenfriamiento=0;
    end
    
    
    % Condiciones a la entrada del compresor y a la v�lvula de expansi�n
    T1 = round(random('Uniform',238.15,263.15),1); % Temperatura en K
    T1_VaporSaturado=T1-sobrecalentamiento;
    p1 = CoolProp.PropsSI('P', 'T', T1_VaporSaturado, 'Q', 1, refrigerante)/1E5; % en bar;
    while true 
        T3 = round(random('Uniform',293.15,318.15),1); % Temperatura en K
        T3_LiquidoSaturado=T3+subenfriamiento;
        p3 = CoolProp.PropsSI('P', 'T', T3_LiquidoSaturado, 'Q', 0, refrigerante)/1E5; % en bar;  
        
        if subenfriamiento==0
            h3=CoolProp.PropsSI('H', 'Q', 0, 'T', T3_LiquidoSaturado, refrigerante)/1000; % en kJ/kg
        else
            h3=CoolProp.PropsSI('H', 'P', p3*1E5, 'T', T3, refrigerante)/1000; % en kJ/kg
        end            
        x4=CoolProp.PropsSI('Q', 'P', p1*1E5, 'H', h3*1E3, refrigerante); % en K
        
        if x4>0 && x4<=0.5
            break
        end        
    end
    
    
    EntradaCompresor=[T1,p1];
    EntradaValvula=[T3,p3];
    parametros={refrigerante,EntradaCompresor,EntradaValvula,...
        eficienciaCompresor,sobrecalentamiento,subenfriamiento} ;

end


function solucion=CicloRefrigeracion(parametros)

    refrigerante=char(parametros(1));
    EntradaCompresor=cell2mat(parametros(2));
    EntradaValvula=cell2mat(parametros(3));
    eficienciaCompresor=cell2mat(parametros(4));
    sobrecalentamiento=cell2mat(parametros(5));
    subenfriamiento=cell2mat(parametros(6));
 
    
    % Condiciones conocidas
    P1=EntradaCompresor(2)*1E5; % Cambio a Pa
    P3=EntradaValvula(2)*1E5; % Cambio a Pa
    T1= EntradaCompresor(1); % en K
    T3= EntradaValvula(1);% en K

    % C�lculo salida del compresor
    if sobrecalentamiento==0
        s1=CoolProp.PropsSI('S', 'Q', 1, 'T', T1, refrigerante);
        h1= CoolProp.PropsSI('H', 'P', P1, 'Q', 1, refrigerante)/1000;% en kJ/kg
        V1= CoolProp.PropsSI('D', 'P', P1, 'Q', 1, refrigerante)^-1;% en m3/kg
    else
        s1=CoolProp.PropsSI('S', 'P', P1, 'T', T1, refrigerante);
        h1= CoolProp.PropsSI('H', 'P', P1, 'S', s1, refrigerante)/1000;% en kJ/kg
        V1= CoolProp.PropsSI('D', 'P', P1, 'S', s1, refrigerante)^-1;% en m3/kg
    end  
      

    % C�lculo entalp�as y trabajo en el compresor ideal
    T2= CoolProp.PropsSI('T', 'P', P3, 'S', s1, refrigerante);
    h2= CoolProp.PropsSI('H', 'P', P3, 'S', s1, refrigerante)/1000; % en kJ/kg
    
    w_compresor=h2-h1; % en kJ/kg
    % C�lculo entalp�as y trabajo en el compresor real
    if eficienciaCompresor~=1
        h2=w_compresor/eficienciaCompresor+h1;
        w_compresor=w_compresor/eficienciaCompresor;
        T2= CoolProp.PropsSI('T', 'P', P3, 'H', h2*1000, refrigerante);
    end
    

    % C�lculo calores de evaporaci�n y condensaci�n y condiciones a la
    % salida de la v�lvula de expansi�n
    if subenfriamiento==0
        h3=CoolProp.PropsSI('H', 'Q', 0, 'T', T3, refrigerante)/1000; % en kJ/kg
        V3=CoolProp.PropsSI('D', 'Q', 0, 'T', T3, refrigerante)^-1; % en m3/kg
        s3=CoolProp.PropsSI('S', 'Q', 0, 'T', T3, refrigerante)/1000; % en kJ/kg�K
    else
        h3=CoolProp.PropsSI('H', 'P', P3, 'T', T3, refrigerante)/1000; % en kJ/kg
        V3=CoolProp.PropsSI('D', 'P', P3, 'T', T3, refrigerante)^-1;  % en m3/kg
        s3=CoolProp.PropsSI('S', 'P', P3, 'T', T3, refrigerante)/1000; % en kJ/kg�K
    end  

    q_condensador=h2-h3; % en kJ/kg
    q_evaporador=h1-h3;
    h4= h3;
    T4=CoolProp.PropsSI('T', 'P', P1, 'H', h4*1E3, refrigerante); % en K
    x4=CoolProp.PropsSI('Q', 'P', P1, 'H', h4*1E3, refrigerante); % en K

    
    % C�lculo coeficientes funcionamiento
    CF_refrigeracion=q_evaporador/w_compresor; 
    CF_calefaccion=q_condensador/w_compresor; 
    
    SalidaCompresor=[T2,P3*1E-5,h2];
    SalidaValvula=[T4,P1*1E-5, h4, x4];
    solucion=[SalidaCompresor,SalidaValvula,w_compresor,CF_refrigeracion,CF_calefaccion,h1,h3,s1,V1,V3,s3];
   
end


function [variablesConocidas,Resultados]=GeneradorCasos(parametros,solucion)

    refrigerante=char(parametros(1));
    EntradaCompresor=cell2mat(parametros(2));
    EntradaValvula=cell2mat(parametros(3));
    eficienciaCompresor=cell2mat(parametros(4));
    sobrecalentamiento=cell2mat(parametros(5));
    subenfriamiento=cell2mat(parametros(6));
 
    SalidaCompresor=solucion(1:3);
    SalidaValvula=solucion(4:7);
    w_compresor=solucion(8);
    CF_refrigeracion=solucion(9);
    CF_calefaccion=solucion(10);


    variablesConocidas=table;
    Resultados=table;
    if sobrecalentamiento==0
        sobrecalentamiento='Sin sobrecalentamiento';
    else
        sobrecalentamiento=round(sobrecalentamiento,1);
    end
    
    if subenfriamiento==0
        subenfriamiento='Sin subenfriamiento';
    else
        subenfriamiento=round(subenfriamiento,1);
    end
    
    if eficienciaCompresor==1
        eficienciaCompresor='Compresor ideal';
    else
        
        eficienciaCompresor=round(eficienciaCompresor,3);
    end
 
 

    variablesConocidas(1,:)={refrigerante, round(EntradaCompresor(1),1),sobrecalentamiento,...
        round(EntradaValvula(1),1),subenfriamiento,eficienciaCompresor};
    variablesConocidas.Properties.VariableNames = {'Refrigerante ' 'T1' ...
        'Sobrecalentamiento' 'T3' 'Subenfriamiento' 'Eficiencia_Compresor'};

    Resultados(1,:)={round(EntradaCompresor(2),3),round(EntradaValvula(2),1),...
        round(SalidaCompresor(1),1),round(SalidaValvula(1),1),round(SalidaValvula(4),3),...
        round(w_compresor,1),round(CF_refrigeracion,3), round(CF_calefaccion,3)};
    Resultados.Properties.VariableNames = ...
        {'P1_P4' 'P2_P3' 'T2' 'T4' 'X4' 'Trabajo_Compresor' 'CF_refrigeracion' 'CF_calefaccion' };        
    
end

function Evaluador(Resultados)

    VariablesDesconocidasNombre=Resultados.Properties.VariableNames;
    VariablesDesconocidasValores=Resultados{1,:};
    
    % N�mero de valores a introducir por intento
    NValores=size(VariablesDesconocidasNombre,2);
    
    fprintf('\nTienes dos oportunidades para acertar el resultado del problema (temperatura [K];presi�n [bar]; entalp�a/trabajo/calor [kJ/kg])) \n');
    fprintf('Nota: una cifra decimal para temperaturas, trabajos y entalp�as y tres cifras para presiones (bar) y eficiencias \n');
    
    for i=1:2
        Valores=zeros(size(VariablesDesconocidasNombre));
        fprintf('\nIntento %d :\n',i);
        
        for n=1:NValores
            Valores(n)=input(['Introduce el valor para ' char(VariablesDesconocidasNombre(n)) ':']);
        end
        
        %Contar n�mero de aciertos            
        aciertos=find(arrayfun(@(x,y) (y>=0.98*x & y<=1.02*x)==1,VariablesDesconocidasValores,Valores));
        if size(aciertos,2)==NValores
            fprintf('\n�Has resuelto bien el problema! \n');
            printf('A continuaci�n se muestra la tabla resumen de las soluciones y los diagramas P-h y T-s para el ciclo termodin�mico \n');
        else
            fprintf('\nHas resuelto bien %d variables\n',size(aciertos,2));
        end
                  
    end
    fprintf('\nNo has resuelto correctamente la totalidad del problema');
    fprintf('\nA continuaci�n se muestra la tabla resumen de las soluciones y los diagramas P-h y T-s para el ciclo termodin�mico \n');
end


function Valoresdomo=domoTemperatura(refrigerante,Tmin, varargin)

    numArgumentos = nargin;
    if numArgumentos > 3 
        error('La funci�n tiene m�s par�metros de los permitidos');
    end

    % Se definen los valores por defecto de los par�metros
    N_Puntos = 100;

    % Copia de los valores por defecto
    optargs= cell2mat(varargin);
    % Sustituye los valores por defecto por los introducidos, si es el caso
    if numArgumentos==3
        N_Puntos = optargs(1);
    end
    
    % Limites inferior y superior del domo
    T_Final=CoolProp.Props1SI(refrigerante, 'Tcrit'); % en K
    
    %P_final=CoolProp.PropsSI("Pcrit",refrigerante)/1E5; % en atm
    Valoresdomo=struct();    
    temperaturas=linspace(Tmin,T_Final,N_Puntos);
    Valoresdomo.liqSaturado.temperaturas=temperaturas;
    Valoresdomo.vapSaturado.temperaturas=temperaturas;
    
    
    Valoresdomo.liqSaturado.presiones= zeros(N_Puntos,1);
    Valoresdomo.liqSaturado.entropias= zeros(N_Puntos,1);
    Valoresdomo.liqSaturado.entalpias= zeros(N_Puntos,1);
    Valoresdomo.liqSaturado.volumenes= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.presiones= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.entropias= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.entalpias= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.volumenes= zeros(N_Puntos,1);

    % structuras para los vectores de parametros termodinamico para las
    % curvas de saturaci�n de l�quido y vapor
    
    for i=1:N_Puntos
        
        presiones_liq=CoolProp.PropsSI('P', 'T',temperaturas(i), 'Q', 0, refrigerante)/1E5; % en bar;
        entropias_liq=CoolProp.PropsSI('S', 'T', temperaturas(i), 'Q', 0, refrigerante)/1000; % en kJ/kg�K;
        entalpias_liq=CoolProp.PropsSI('H', 'T', temperaturas(i), 'Q', 0, refrigerante)/1000; % en kJ/kg;
        volumenes_liq=CoolProp.PropsSI('D', 'T', temperaturas(i), 'Q', 0, refrigerante)^-1; % en m3/kg;
                
        presiones_vap=CoolProp.PropsSI('P', 'T',temperaturas(i), 'Q', 1, refrigerante)/1E5 ;% en bar;
        entropias_vap=CoolProp.PropsSI('S', 'T', temperaturas(i), 'Q', 1, refrigerante)/1000; % en kJ/kg�K;
        entalpias_vap=CoolProp.PropsSI('H', 'T', temperaturas(i), 'Q', 1, refrigerante)/1000; % en kJ/kg;
        volumenes_vap=CoolProp.PropsSI('D', 'T', temperaturas(i), 'Q', 1, refrigerante)^-1; % en m3/kg;
        
        Valoresdomo.liqSaturado.presiones(i)= presiones_liq;
        Valoresdomo.liqSaturado.entropias(i)= entropias_liq;
        Valoresdomo.liqSaturado.entalpias(i)= entalpias_liq;
        Valoresdomo.liqSaturado.volumenes(i)=volumenes_liq;
        
        Valoresdomo.vapSaturado.presiones(i)= presiones_vap;
        Valoresdomo.vapSaturado.entropias(i)= entropias_vap;
        Valoresdomo.vapSaturado.entalpias(i)= entalpias_vap;
        Valoresdomo.vapSaturado.volumenes(i)= volumenes_vap;

    end

end


function Valoresdomo=domoPresion(refrigerante,Pmin, varargin)

    numArgumentos = nargin;
    if numArgumentos > 3 
        error('La funci�n tiene m�s par�metros de los permitidos');
    end

    % Se definen los valores por defecto de los par�metros
    N_Puntos = 100;

    % Copia de los valores por defecto
    optargs= cell2mat(varargin);
    % Sustituye los valores por defecto por los introducidos, si es el caso
    if numArgumentos==3
        N_Puntos = optargs;
    end
    
    % Limites inferior y superior del domo
    P_Final=CoolProp.Props1SI(refrigerante, 'Pcrit')/1E5; % en K
    
    %P_final=CoolProp.PropsSI("Pcrit",refrigerante)/1E5; % en atm
    Valoresdomo=struct();    
    presiones=linspace(Pmin,P_Final,N_Puntos);
    Valoresdomo.liqSaturado.presiones=presiones;
    Valoresdomo.vapSaturado.presiones=presiones;
    
    
    Valoresdomo.liqSaturado.temperaturas= zeros(N_Puntos,1);
    Valoresdomo.liqSaturado.entropias= zeros(N_Puntos,1);
    Valoresdomo.liqSaturado.entalpias= zeros(N_Puntos,1);
    Valoresdomo.liqSaturado.volumenes= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.temperaturas= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.entropias= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.entalpias= zeros(N_Puntos,1);
    Valoresdomo.vapSaturado.volumenes= zeros(N_Puntos,1);

    % structuras para los vectores de parametros termodinamico para las
    % curvas de saturaci�n de l�quido y vapor
    
    for i=1:N_Puntos
        
        temperaturas_liq=CoolProp.PropsSI('T', 'P',presiones(i)*1E5, 'Q', 0, refrigerante); % en K;
        entropias_liq=CoolProp.PropsSI('S', 'P', presiones(i)*1E5, 'Q', 0, refrigerante)/1000; % en kJ/kg�K;
        entalpias_liq=CoolProp.PropsSI('H', 'P', presiones(i)*1E5, 'Q', 0, refrigerante)/1000; % en kJ/kg;
        volumenes_liq=CoolProp.PropsSI('D', 'P',presiones(i)*1E5, 'Q', 0, refrigerante)^-1; % en m3/kg;
                
        temperaturas_vap=CoolProp.PropsSI('T', 'P',presiones(i)*1E5, 'Q', 1, refrigerante) ;% en K;
        entropias_vap=CoolProp.PropsSI('S', 'P', presiones(i)*1E5, 'Q', 1, refrigerante)/1000; % en kJ/kg�K;
        entalpias_vap=CoolProp.PropsSI('H', 'P', presiones(i)*1E5, 'Q', 1, refrigerante)/1000; % en kJ/kg;
        volumenes_vap=CoolProp.PropsSI('D', 'P', presiones(i)*1E5, 'Q', 1, refrigerante)^-1; % en m3/kg;
        
        Valoresdomo.liqSaturado.temperaturas(i)= temperaturas_liq;
        Valoresdomo.liqSaturado.entropias(i)= entropias_liq;
        Valoresdomo.liqSaturado.entalpias(i)= entalpias_liq;
        Valoresdomo.liqSaturado.volumenes(i)=volumenes_liq;
        
        Valoresdomo.vapSaturado.temperaturas(i)= temperaturas_vap;
        Valoresdomo.vapSaturado.entropias(i)= entropias_vap;
        Valoresdomo.vapSaturado.entalpias(i)= entalpias_vap;
        Valoresdomo.vapSaturado.volumenes(i)= volumenes_vap;

    end

end


function valoresProceso=ValoresProcesoTrabajo(refrigerante,P_Inicial,...
    P_Final, T_Inicial,T_Final,s1,h1,v1,compresion, eficiencia, varargin)
    
    numArgumentos = nargin;
    if numArgumentos > 11 
        error('La funci�n tiene m�s par�metros de los permitidos');
    end

    % Se definen los valores por defecto de los par�metros
    N_Puntos = 50;

    % Copia de los valores por defecto
    optargs= cell2mat(varargin);
    % Sustituye los valores por defecto por los introducidos, si es el caso
    if numArgumentos==11
        N_Puntos = optargs;
    end
    
    presiones= linspace(P_Inicial,P_Final,N_Puntos);
    temperaturas=linspace(T_Inicial,T_Final,N_Puntos);
    volumen=zeros(1,N_Puntos);
    entalpias=zeros(1,N_Puntos);
    entropias=zeros(1,N_Puntos);
    entropia_adiabatica=s1; % en kJ/kg�K;
    entalpias(1)=h1; % en kJ/kg;
    volumen(1)=v1;
    valoresProceso=struct();

    
    for i=2:N_Puntos
        entalpias(i)=CoolProp.PropsSI('H', 'S', entropia_adiabatica, 'P', presiones(i)*1E5, refrigerante)/1000; % en kJ/kg
        if compresion==1
            entalpias(i)= entalpias(1) +(entalpias(i)-entalpias(1))/eficiencia;
        else
            entalpias(i)= entalpias(1) +(entalpias(i)-entalpias(1))*eficiencia;
            
        end
        entropias(i)=CoolProp.PropsSI('S', 'H', entalpias(i)*1E3, 'P', presiones(i)*1E5, refrigerante)/1000; % en kJ/kg�K;
        temperaturas(i)=CoolProp.PropsSI('T', 'H', entalpias(i)*1E3, 'P', presiones(i)*1E5, refrigerante); % en K
        densidad=CoolProp.PropsSI('D', 'H', entalpias(i)*1E3, 'P', presiones(i)*1E5, refrigerante); % en kg/m3
        volumen(i)=1/densidad;
        
    end
    
    valoresProceso.entropias=entropias;
    valoresProceso.entalpias=entalpias;
    valoresProceso.temperaturas=temperaturas;
    valoresProceso.presiones=presiones;
    valoresProceso.volumen=volumen;

end


function DiagramaPhyPv(refrigerante,PuntosCicloPH,ValoresdomoP,parametros,solucion)
   
    temperatura=PuntosCicloPH.temperaturas;
    presion=PuntosCicloPH.presiones;
    entalpia=zeros(size(temperatura));
    P_liq=ValoresdomoP.liqSaturado.presiones;
    H_liq=ValoresdomoP.liqSaturado.entalpias;
    V_liq=ValoresdomoP.liqSaturado.volumenes;
    
    P_vap=ValoresdomoP.vapSaturado.presiones;
    H_vap=ValoresdomoP.vapSaturado.entalpias;
    V_vap=ValoresdomoP.vapSaturado.volumenes;
    
    eficienciaCompresor=parametros(1);
    entalpia(1)=solucion(11);
    entalpia(3)=solucion(12);
    entalpia(2)=solucion(3);
    entalpia(4)=solucion(6);
    s1=solucion(13);
    
    % C�lculo vol�menes espec�ficos para el ciclo
    volumen(1)=solucion(14);
    volumen(2)=CoolProp.PropsSI('D', 'H', entalpia(2)*1E3, 'P', presion(2)*1E5, refrigerante)^-1;
    volumen(3)=solucion(15);
    volumen(4)=CoolProp.PropsSI('D', 'H', entalpia(4)*1E3, 'P', presion(4)*1E5, refrigerante)^-1;
    
    AdicionCalorEntalpia=[entalpia(3),entalpia(4),entalpia(1)];
    AdicionCalorVolumen=[volumen(3),volumen(4),volumen(1)];
    AdicionCalorPresion=[presion(3),presion(4),presion(1)]; 
    
    RetiradaCalorEntalpia=entalpia(2:3);
    RetiradaCalorVolumen=volumen(2:3);
    RetiradaCalorPresion=presion(2:3); 
    
    compresor=ValoresProcesoTrabajo(refrigerante,presion(1),presion(2), temperatura(1),...
        temperatura(2),s1,entalpia(1),volumen(1), 1, eficienciaCompresor, 50);
    
    figure;
    hold on
    axis([entalpia(3)*0.8,entalpia(2)*1.05,presion(1)*0.65,presion(2)*1.5]);
    set(gca, 'YScale', 'log', 'box', 'on')
    semilogy(compresor.entalpias,compresor.presiones,'-r','Marker','none','LineStyle','-');
    semilogy(H_liq,P_liq,'-k','Marker','none','LineStyle','-');
    semilogy(H_vap,P_vap,'-k','Marker','none','LineStyle','-');
    semilogy(AdicionCalorEntalpia,AdicionCalorPresion,'-r','Marker','o','MarkerSize',6);
    semilogy(RetiradaCalorEntalpia,RetiradaCalorPresion,'-r','Marker','o','MarkerSize',6);
    title('Diagrama P-h. Ciclo de Refrigeraci�n','FontWeight','bold');
    xlabel('Entalp�a (kJ/kg)','FontWeight','bold');ylabel('Presi�n (bar)','FontWeight','bold'); 
    
    figure;
    hold on
    axis([volumen(3)-0.005,volumen(1)*1.05,presion(1)*0.65,presion(2)*1.5]);
    set(gca, 'YScale', 'log', 'box', 'on')
    semilogy(compresor.volumen,compresor.presiones,'-r','Marker','none','LineStyle','-');
    semilogy(V_liq,P_liq,'-k','Marker','none','LineStyle','-');
    semilogy(V_vap,P_vap,'-k','Marker','none','LineStyle','-');
    semilogy(AdicionCalorVolumen,AdicionCalorPresion,'-r','Marker','o','MarkerSize',6);
    semilogy(RetiradaCalorVolumen,RetiradaCalorPresion,'-r','Marker','o','MarkerSize',6);
    title('Diagrama P-v. Ciclo de Refrigeraci�n','FontWeight','bold');
    xlabel('Volumen espec�fico (m^3/kg)','FontWeight','bold');ylabel('Presi�n (bar)','FontWeight','bold'); 
     
end

function valoresProceso=ValoresProcesoIsobaro(refrigerante,T_Inicial,T_Final,Presion, Entropias, varargin)

    numArgumentos = nargin;
    if numArgumentos > 6 
        error('La funci�n tiene m�s par�metros de los permitidos');
    end

    % Se definen los valores por defecto de los par�metros
    N_Puntos = 50;

    % Copia de los valores por defecto
    optargs= cell2mat(varargin);
    % Sustituye los valores por defecto por los introducidos, si es el caso
    if numArgumentos==6
        N_Puntos = optargs;
    end
      
  
    entropias= linspace(Entropias(1),Entropias(2),N_Puntos);    
    temperaturas=zeros(1,N_Puntos);
    temperaturas(1)=T_Inicial;
    temperaturas(end)=T_Final;
    valoresProceso=struct();
    
    for i=2:(N_Puntos-1)
        temperaturas(i)=CoolProp.PropsSI('T', 'P', Presion*1E5, 'S', entropias(i)*1E3, refrigerante); % en kJ/kg
    end
    
    valoresProceso.entropias=entropias;
    valoresProceso.temperaturas=temperaturas;
   
end


function DiagramaTs(refrigerante,PuntosCicloTS,ValoresdomoT,solucion)

    temperatura=PuntosCicloTS.temperaturas;
    presion=PuntosCicloTS.presiones;
    entropia=zeros(size(temperatura));
    
    T_liq=ValoresdomoT.liqSaturado.temperaturas;
    S_liq=ValoresdomoT.liqSaturado.entropias;
    
    T_vap=ValoresdomoT.vapSaturado.temperaturas;
    S_vap=ValoresdomoT.vapSaturado.entropias;

    entropia(1)=solucion(13)/1000;
    entropia(3)=solucion(16);
    entropia(2)=CoolProp.PropsSI('S', 'P', presion(2)*1E5, 'T',...
        temperatura(2), refrigerante)/1000;
    entropia(4)=CoolProp.PropsSI('S', 'P', presion(1)*1E5, 'Q',...
        solucion(7), refrigerante)/1000;

    compresorEntropia=[entropia(1),entropia(2)];
    compresorTemperatura=[temperatura(1),temperatura(2)];
    valvulaEntropia=[entropia(3), entropia(4)];
    valvulaTemperatura=[temperatura(3),temperatura(4)];
    EntropiasCalentamiento=[ entropia(3), entropia(2)];
    EntropiasEnfriamiento=[ entropia(4), entropia(1)] ;
    calentamiento=ValoresProcesoIsobaro(refrigerante,temperatura(3),temperatura(2), presion(2),EntropiasCalentamiento, 100);
    enfriamiento=ValoresProcesoIsobaro(refrigerante,temperatura(4),temperatura(1), presion(1), EntropiasEnfriamiento,100);
    
            
    figure;
    hold on
    axis([entropia(3)*0.95,entropia(1)*1.05,temperatura(1)*0.75,temperatura(2)*1.15]);
    set(gca,  'box', 'on')
    plot(S_liq,T_liq,'-k','Marker','none','LineStyle','-');
    plot(S_vap,T_vap,'-k','Marker','none','LineStyle','-');
    plot(compresorEntropia,compresorTemperatura,'-r','Marker','o','LineStyle','-');
    plot(valvulaEntropia,valvulaTemperatura,'-r','Marker','o','LineStyle','-','MarkerSize',6);
    plot(calentamiento.entropias,calentamiento.temperaturas,'-r','Marker','none','MarkerSize',6);
    plot(enfriamiento.entropias,enfriamiento.temperaturas,'-r','Marker','none','MarkerSize',6);
    title('Diagrama T-s. Ciclo de Refrigeraci�n','FontWeight','bold');
    xlabel('Entrop�a (kJ/kg�K)','FontWeight','bold');ylabel('Temperatura (K)','FontWeight','bold'); 
    
end



