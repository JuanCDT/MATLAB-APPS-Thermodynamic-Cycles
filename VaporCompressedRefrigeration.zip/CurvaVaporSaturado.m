function valores=CurvaVaporSaturado(T_Inicial, T_Final,refrigerante, N_Puntos)
    
    entalpias=ones(1,N_Puntos);
    entropias=ones(1,N_Puntos);
    volumen=ones(1,N_Puntos);
    temperaturas= linspace(T_Inicial,T_Final,N_Puntos);
    presiones=ones(1,N_Puntos);
    Q=1;
    
    for i=1:N_Puntos
        
        entropias(i)=CoolProp.PropsSI('S', 'Q',Q, 'T', temperaturas(i), refrigerante)/1000; % en kJ/kg�K
        volumen(i)=CoolProp.PropsSI('D', 'Q', Q, 'T', temperaturas(i), refrigerante)^-1;  % en m3/kg
        entalpias(i)=CoolProp.PropsSI('H', 'Q', Q, 'T', temperaturas(i), refrigerante)/1000; % en kJ/kg  
        presiones(i)=CoolProp.PropsSI('P', 'Q', Q, 'T', temperaturas(i), refrigerante)/1E5; % en bar 
        
    end
    
    valores=struct();
    valores.entalpias=entalpias;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;
    valores.presiones=presiones;
    valores.volumen=volumen;


end