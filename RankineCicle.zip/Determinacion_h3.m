function h3=Determinacion_h3(eficienciaturbina,X4,P4, rp)
    
    P1=P4*1E5;
    P3=P1*rp;

    h4=CoolProp.PropsSI('H', 'P', P1, 'Q', X4, 'water')/1000;
    options=optimset('Display','on','MaxIter',100000,...
      'MaxFunEvals',100000,'TolFun',1E-8,'TolX',1E-8);
  
  %'levenberg-marquardt'
  %'trust-region-reflective'
  %'Algorithm','levenberg-marquardt'

    lb=(650);
    ub=(10000);
       h3=lsqnonlin(@ecuaciones,(h4+2000),lb,ub,options,h4,eficienciaturbina,P1,P3);

 
end