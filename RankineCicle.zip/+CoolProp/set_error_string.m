function varargout = set_error_string(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(349,varargin{:});
end
