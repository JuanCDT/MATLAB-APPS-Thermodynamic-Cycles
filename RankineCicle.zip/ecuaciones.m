
function residuo=ecuaciones(h3,h4,eficienciaturbina,P1,P3)


    s3=CoolProp.PropsSI('S', 'P', P3, 'H', h3*1E3, 'water');    
    h4_adiabatico=CoolProp.PropsSI('H', 'P', P1, 'S', s3, 'water')/1000;
    
    eficienciaturbina_calculada=(h3-h4)/(h3-h4_adiabatico);
    residuo = eficienciaturbina_calculada - eficienciaturbina;   
    
    
end