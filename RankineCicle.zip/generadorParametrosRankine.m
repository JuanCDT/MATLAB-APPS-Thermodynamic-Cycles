function [parametros]=generadorParametrosRankine()


    fluido='water';
    
    a=randi([0 1]);b=randi([0 1]);
    if a && b % ideal
        eficienciaTurbina=1;
        eficienciaCompresor=1;
    elseif a % turbina ideal
        eficienciaTurbina=1;
        eficienciaCompresor=random('Uniform',0.7, 0.95);
    elseif b % compresor ideal
        eficienciaTurbina = random('Uniform',0.7, 0.95);
        eficienciaCompresor = 1;
    else % real
        eficienciaTurbina = random('Uniform',0.7, 0.95);
        eficienciaCompresor = random('Uniform',0.7, 0.95);
    end
    
    % Define si el problema es con subenfriamiento, sobrecalentamiento o
    % ambos casos
       % Genera las condiciones a la entrada del compresor y de la turbina
    
    p1 = round(random('Uniform',0.06,0.1),3);  % En bar, se convierte en Pa multiplicando por 1E5
    T1 =CoolProp.PropsSI('T', 'P', p1*1E5, 'Q', 0, fluido) ;% Temperatura en K
    p3 = round(random('Uniform',50,80),3);
    rp = p3/p1;
   % X4=round(random('Uniform',0.85,0.95),3);
    
   while 1
        X4_ideal=round(random('Uniform',0.80,0.90),3);  
        s4=CoolProp.PropsSI('S', 'P', p1*1E5, 'Q', X4_ideal, fluido)/1000 ;% Entrop�a en kJ/kg�K
        %T4 = CoolProp.PropsSI('T', 'P', p1*1E5, 'Q', X4, fluido) % Temperatura en K
        h4_ideal = CoolProp.PropsSI('H', 'P', p1*1E5, 'Q', X4_ideal, fluido)/1000 ;% Entalp�a en kJ/k
        T4_vaporSaturado=CoolProp.PropsSI('T', 'P', p1*1E5, 'Q', 1, fluido); % Temperatura en K
        %T3=CoolProp.PropsSI('T', 'P', p3*1E5, 'S', s4*1000, fluido); % Temperatura en K
        h3=CoolProp.PropsSI('H', 'P', p3*1E5, 'S', s4*1000, fluido)/1000 ;% Entalp�a en kJ/kg

        h4=h3-eficienciaTurbina*(h3-h4_ideal);
        T4=CoolProp.PropsSI('T', 'P', p1*1E5, 'H', h4*1000, fluido); % Temperatura en K
        if T4==T4_vaporSaturado
            X4=CoolProp.PropsSI('Q', 'P', p1*1E5, 'H', h4*1000, fluido); % Temperatura en K
            if X4<=0.95 && X4>=0.85
                break
            end
        end
   end
            
        
        
    
    
    

    parametros=[T1,p1,X4,h3,p3,T4,rp,eficienciaCompresor,eficienciaTurbina] ;

end