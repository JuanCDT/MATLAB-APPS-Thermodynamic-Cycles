function solucion=CicloRankine_1(parametros)
    
    solucion=struct;
    
     % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K).  
    
    CeldaParametros=num2cell(parametros);
    [T1,p1,~,h3,~,~,rp,eficienciaCompresor,eficienciaTurbina]=deal(CeldaParametros{:});
    
    % Condiciones conocidas
    P1=p1*1E5; % Cambio a Pa
    P3=P1*rp; % Cambio a Pa
    p3=p1*rp; % en bar

    % C�lculo salida del compresor
    
    
    s1=CoolProp.PropsSI('S', 'Q',0 , 'P', P1, 'water')/1000;
    h1= CoolProp.PropsSI('H', 'Q',0 , 'P', P1, 'water')/1000;
    V1= CoolProp.PropsSI('D', 'P', P1, 'Q', 0, 'water')^-1;% en m3/kg
    
    Punto1=[T1,p1,h1,V1,s1];
    solucion.Punto1=Punto1;


    % C�lculo entalp�as y trabajo en el compresor ideal
    T2= CoolProp.PropsSI('T', 'P', P3, 'S', s1*1E3, 'water');
    h2= CoolProp.PropsSI('H', 'P', P3, 'S', s1*1E3, 'water')/1000; % en kJ/kg    
    w_compresor=h2-h1;% en kJ/kg
    
    
    % C�lculo entalp�as y trabajo en el compresor real
    if eficienciaCompresor~=1
        h2=w_compresor/eficienciaCompresor+h1;
        w_compresor=w_compresor/eficienciaCompresor;
        T2= CoolProp.PropsSI('T', 'P', P3, 'H', h2*1000, 'water');
    end
    V2= CoolProp.PropsSI('D', 'P', P3, 'T', T2, 'water')^-1;% en m3/kg
    s2= CoolProp.PropsSI('S', 'P', P3, 'T', T2, 'water')/1000; % en kJ/kg�K
    
    Punto2=[T2,p3,h2,V2,s2];
    solucion.Punto2=Punto2;
    
    
    % Calculo calentamiento
    
    s3=CoolProp.PropsSI('S', 'P',P3 , 'H', h3*1000, 'water')/1000; % en kJ/kg�K
    T3= CoolProp.PropsSI('T',  'P',P3 , 'H', h3*1000, 'water');% en K
    v3= CoolProp.PropsSI('D', 'P',P3 , 'H', h3*1000, 'water')^-1;% en m3/kg

    Punto3=[T3,p3,h3,v3,s3];
    solucion.Punto3=Punto3;

    % C�lculo entalp�as y trabajo en la turbina ideal
    T4= CoolProp.PropsSI('T', 'P', P1, 'S', s3*1E3, 'water');
    h4= CoolProp.PropsSI('H', 'P', P1, 'S', s3*1E3, 'water')/1000; % en kJ/kg    
    w_turbina=h3-h4; % en kJ/kg
    
    % C�lculo entalp�as y trabajo en el compresor real
    if eficienciaTurbina~=1
        h4=h3-w_turbina*eficienciaTurbina;
        w_turbina=w_turbina*eficienciaTurbina;
        T4= CoolProp.PropsSI('T', 'P', P1, 'H', h4*1000, 'water');
    end
    V4= CoolProp.PropsSI('D', 'P', P1, 'H', h4*1E3, 'water')^-1;% en m3/kg
    s4= CoolProp.PropsSI('S', 'P', P1, 'H', h4*1E3, 'water')/1000; % en kJ/kg�K
    x4= CoolProp.PropsSI('Q', 'P', P1, 'H', h4*1E3, 'water'); 
    
    Punto4=[T4,p1,h4,V4,s4,x4];
    solucion.Punto4=Punto4;
    
    q_condensador=h4-h1; % en kJ/kg
    q_caldera=h3-h2;
    
    eficiencia_termica=(w_turbina-w_compresor)/q_caldera;

    % Soluci�n - valores ciclo. Trabajos compresor y turbina y Calores
    % caldera y condensador  Todos en kJ/kg.
    % Eficiencia t�rmica del ciclo.
    solucion.ParametrosCiclo=[w_compresor,w_turbina,q_caldera,q_condensador,eficiencia_termica];
   
end

