classdef CascadeVaporCompressionRefrigeration < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                       matlab.ui.Figure
        TabGroup                       matlab.ui.container.TabGroup
        DatosInicialesTab              matlab.ui.container.Tab
        TextArea_3                     matlab.ui.control.TextArea
        UITable_DatosIniciales_ciclo1  matlab.ui.control.Table
        TextArea_4                     matlab.ui.control.TextArea
        UIAxes_PH_ciclo1               matlab.ui.control.UIAxes
        UIAxes_TS_ciclo1               matlab.ui.control.UIAxes
        UIAxes_PV_ciclo1               matlab.ui.control.UIAxes
        Image                          matlab.ui.control.Image
        EjecutarButton_2               matlab.ui.control.Button
        MostrargrficosButton           matlab.ui.control.Button
        MostrarresultadosButton        matlab.ui.control.Button
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        ExportarresultadosButton       matlab.ui.control.Button
        Refrigerante1Label             matlab.ui.control.Label
        RefrigeranteListBox_ciclo1     matlab.ui.control.ListBox
        Refrig1seleccionadoLabel       matlab.ui.control.Label
        RefrigseleccionadoEditField_ciclo1  matlab.ui.control.EditField
        UIAxes_PH_ciclo2               matlab.ui.control.UIAxes
        UIAxes_TS_ciclo2               matlab.ui.control.UIAxes
        UIAxes_PV_ciclo2               matlab.ui.control.UIAxes
        UITable_DatosIniciales_ciclo2  matlab.ui.control.Table
        Refrig2seleccionadoLabel       matlab.ui.control.Label
        RefrigseleccionadoEditField_ciclo2  matlab.ui.control.EditField
        Refrigerante2Label             matlab.ui.control.Label
        RefrigeranteListBox_ciclo2     matlab.ui.control.ListBox
        TextArea_9                     matlab.ui.control.TextArea
        TextArea_10                    matlab.ui.control.TextArea
        TextArea_11                    matlab.ui.control.TextArea
        TextArea_12                    matlab.ui.control.TextArea
        ResultadosTab                  matlab.ui.container.Tab
        UITable_Resultados_ciclo1      matlab.ui.control.Table
        TextArea_5                     matlab.ui.control.TextArea
        UITable_Resultados_2_ciclo1    matlab.ui.control.Table
        Image2                         matlab.ui.control.Image
        UITable_Procesos               matlab.ui.control.Table
        TextArea_8                     matlab.ui.control.TextArea
        UITable_Resultados_ciclo2      matlab.ui.control.Table
        UITable_Resultados_2_ciclo2    matlab.ui.control.Table
        TextArea_13                    matlab.ui.control.TextArea
        TextArea_14                    matlab.ui.control.TextArea
        Relacindecaudalesm1m2Label_2   matlab.ui.control.Label
        RefrigseleccionadoEditField_RelacionCaudalesMasicos_2  matlab.ui.control.EditField
        CFrefrigeracindelcicloLabel    matlab.ui.control.Label
        RefrigseleccionadoEditField_CF_Refrigeracion  matlab.ui.control.EditField
        CFcalefaccindelcicloLabel      matlab.ui.control.Label
        RefrigseleccionadoEditField_CF_Calefaccion  matlab.ui.control.EditField
        TextArea_15                    matlab.ui.control.TextArea
        CaudaldecalorCondensadorEvaporadorkWLabel  matlab.ui.control.Label
        RefrigseleccionadoEditField_Q_evaporador  matlab.ui.control.EditField
    end

    
    properties (Access = private)        
       
        parametros_Ciclo1=[];
        parametros_Ciclo2=[];
        
        refrigerante_1=[];refrigerante_2=[]; 
        Punto1=[], Punto2=[]; Punto3=[]; Punto4=[]; 
        Punto5=[], Punto6=[]; Punto7=[]; Punto8=[]; 
        solucion_Ciclo1=[];    
        solucion_Ciclo2=[]; 
        
        w_compresor1=[];q_condensador1=[];q_evaporador1=[];CF_refrigeracion1=[];CF_calefaccion1=[];m1=[];
        w_compresor2=[];q_condensador2=[];q_evaporador2=[];CF_refrigeracion2=[];CF_calefaccion2=[];m2=[];
        
        CF_refrigeracion_ciclo=[];CF_calefaccion_ciclo=[];W_compresorTotal=[];Relacion_Caudales=[];

        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)
                      
            
            app.solucion_Ciclo1=CicloRefrigeracion_BajaPresion(app.refrigerante_1, app.parametros_Ciclo1);
            Q_Condensador=app.solucion_Ciclo1.ParametrosCiclo(3)*app.solucion_Ciclo1.ParametrosCiclo(6);
            app.solucion_Ciclo2=CicloRefrigeracion_AltaPresion(app.refrigerante_2, app.parametros_Ciclo2,...
               Q_Condensador);
            
                        
            app.Punto1=app.solucion_Ciclo1.Punto1;
            app.Punto2=app.solucion_Ciclo1.Punto2;
            app.Punto3=app.solucion_Ciclo1.Punto3;
            app.Punto4=app.solucion_Ciclo1.Punto4;
            
            
            app.Punto5=app.solucion_Ciclo2.Punto1;
            app.Punto6=app.solucion_Ciclo2.Punto2;
            app.Punto7=app.solucion_Ciclo2.Punto3;
            app.Punto8=app.solucion_Ciclo2.Punto4;

            app.w_compresor1=app.solucion_Ciclo1.ParametrosCiclo(5);
            app.q_condensador1=app.solucion_Ciclo1.ParametrosCiclo(3);
            app.q_evaporador1=app.solucion_Ciclo1.ParametrosCiclo(4);
            app.CF_refrigeracion1=app.solucion_Ciclo1.ParametrosCiclo(1);
            app.CF_calefaccion1=app.solucion_Ciclo1.ParametrosCiclo(2);
            app.m1=app.solucion_Ciclo1.ParametrosCiclo(6);
            
            
            app.w_compresor2=app.solucion_Ciclo2.ParametrosCiclo(5);
            app.q_condensador2=app.solucion_Ciclo2.ParametrosCiclo(3);
            app.q_evaporador2=app.solucion_Ciclo2.ParametrosCiclo(4);
            app.CF_refrigeracion2=app.solucion_Ciclo2.ParametrosCiclo(1);
            app.CF_calefaccion2=app.solucion_Ciclo2.ParametrosCiclo(2);
            app.m2=app.solucion_Ciclo2.ParametrosCiclo(6);
            
            app.W_compresorTotal=(app.w_compresor2*app.m2)+(app.w_compresor1*app.m1);
            app.CF_refrigeracion_ciclo=(app.q_evaporador1*app.m1)/app.W_compresorTotal;
            app.CF_calefaccion_ciclo=(app.q_condensador2*app.m2)/app.W_compresorTotal;
            app.Relacion_Caudales=app.m1/app.m2;
            
            
            
            Dibujo_Diagramas(app.refrigerante_1,app.parametros_Ciclo1,app.solucion_Ciclo1,app.UIAxes_PH_ciclo1,...
                app.UIAxes_TS_ciclo1,app.UIAxes_PV_ciclo1);
                       
            Dibujo_Diagramas(app.refrigerante_2,app.parametros_Ciclo2,app.solucion_Ciclo2,app.UIAxes_PH_ciclo2,...
                app.UIAxes_TS_ciclo2,app.UIAxes_PV_ciclo2);

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UITable_Procesos.Data={'1-2','Compression - low temperature';'2-3','Condenser: heat-rejection - low temperature';...
               '3-4','Expansion - low temperature';'4-1','Evaporator: heat-addition - low temperature';'5-6','Compression - high temperature';...
               '6-7','Condenser: heat-rejection - high temperature';'7-8','Expansion - high temperature';...
               '8-5','Evaporator: heat-addition - high temperature'};
            app.UITable_Procesos.RowName={};   
            
            [app.refrigerante_1,app.parametros_Ciclo1]=generadorParametrosRefrigeracion_BajaPresion('0');            
            [app.refrigerante_2,app.parametros_Ciclo2]=generadorParametrosRefrigeracion_AltaPresion('0',app.parametros_Ciclo1(3));
%                    
%                         
%             CeldaParametros=num2cell(app.parametros);
%             [app.T1,app.p1,app.T3,app.p3,...
%                 app.eficienciaCompresor,app.sobrecalentamiento,app.subenfriamiento]=deal(CeldaParametros{:});
%             
                        
            cla(app.UIAxes_PH_ciclo1)
            cla(app.UIAxes_PV_ciclo1)
            cla(app.UIAxes_TS_ciclo1)
            
            
            cla(app.UIAxes_PH_ciclo2)
            cla(app.UIAxes_PV_ciclo2)
            cla(app.UIAxes_TS_ciclo2)
                        
        end

        % Button pushed function: EjecutarButton_2
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH_ciclo1)
            cla(app.UIAxes_PV_ciclo1)
            cla(app.UIAxes_TS_ciclo1)
            
            cla(app.UIAxes_PH_ciclo2)
            cla(app.UIAxes_PV_ciclo2)
            cla(app.UIAxes_TS_ciclo2)
            
            app.UITable_Resultados_ciclo1.Data={};
            app.UITable_Resultados_2_ciclo1.Data={};
            app.UITable_Resultados_ciclo2.Data={};
            app.UITable_Resultados_2_ciclo2.Data={};
            
            app.RefrigseleccionadoEditField_RelacionCaudalesMasicos_2.Value='';
            app.RefrigseleccionadoEditField_Q_evaporador.Value='';
            app.RefrigseleccionadoEditField_CF_Refrigeracion.Value='';
            app.RefrigseleccionadoEditField_CF_Calefaccion.Value='';
            
            fluido1=app.RefrigeranteListBox_ciclo1.Value;
            fluido2=app.RefrigeranteListBox_ciclo2.Value;
            
                        
            [app.refrigerante_1,app.parametros_Ciclo1]=generadorParametrosRefrigeracion_BajaPresion(fluido1);            
            [app.refrigerante_2,app.parametros_Ciclo2]=generadorParametrosRefrigeracion_AltaPresion(fluido2,app.parametros_Ciclo1(3));
          
            app.RefrigseleccionadoEditField_ciclo1.Value=app.refrigerante_1;
            app.RefrigseleccionadoEditField_ciclo2.Value=app.refrigerante_2;
            
                        
            CeldaParametros_Ciclo1=num2cell(app.parametros_Ciclo1);
            [T1,~,T3,~,eficienciaCompresor,sobrecalentamiento,subenfriamiento,~]=deal(CeldaParametros_Ciclo1{:});
            
                   
            app.UITable_DatosIniciales_ciclo1.ColumnName = {' '; 'Value'};
            app.UITable_DatosIniciales_ciclo1.Data={T1;T3;sobrecalentamiento;subenfriamiento;eficienciaCompresor};
            app.UITable_DatosIniciales_ciclo1.RowName={'Compressor inlet temperature (K)','Compressor outlet temperature (K)',...
                'Superheating - evaporator (K)','Subcooling - condenser (K)'...
                'Eficiency Compressor'};
            
               
            
            
            CeldaParametros_Ciclo2=num2cell(app.parametros_Ciclo2);
            [T5,~,T7,~,eficienciaCompresor_2,sobrecalentamiento_2,subenfriamiento_2]=deal(CeldaParametros_Ciclo2{:});
            
                               
            app.UITable_DatosIniciales_ciclo2.ColumnName = {' '; 'Value'};
            app.UITable_DatosIniciales_ciclo2.Data={T5;T7;sobrecalentamiento_2;subenfriamiento_2;eficienciaCompresor_2};
            app.UITable_DatosIniciales_ciclo2.RowName={'Compressor inlet temperature (K)','Compressor outlet temperature (K)',...
                'Superheating - evaporator (K)','Subcooling - condenser (K)'...
                'Eficiency Compressor'};
            
            
            
                        

        end

        % Button pushed function: MostrargrficosButton
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end

        % Button pushed function: MostrarresultadosButton
        function MostrarresultadosButtonPushed(app, ~)
            MostrargrficosButtonPushed(app, 'push');
            format shortG        
            
            app.UITable_Resultados_ciclo1.Data={'5',app.Punto1(2),app.Punto1(1), app.Punto1(3),app.Punto1(5),app.Punto1(4);...
            '6',app.Punto2(2),app.Punto2(1),app.Punto2(3),app.Punto2(5),app.Punto2(4);...
           '7',app.Punto3(2),app.Punto3(1), app.Punto3(3),app.Punto3(5),app.Punto3(4);...
            '8',app.Punto4(2),app.Punto4(1), app.Punto4(3),app.Punto4(5),app.Punto4(4)};

            app.UITable_Resultados_2_ciclo1.Data={app.w_compresor1;app.q_condensador1; app.q_evaporador1;...
                app.CF_refrigeracion1;app.CF_calefaccion1};
 
                        
            app.UITable_Resultados_ciclo2.Data={'1',app.Punto5(2),app.Punto5(1), app.Punto5(3),app.Punto5(5),app.Punto5(4);...
            '2',app.Punto6(2),app.Punto6(1),app.Punto6(3),app.Punto6(5),app.Punto6(4);...
           '3',app.Punto7(2),app.Punto7(1), app.Punto7(3),app.Punto7(5),app.Punto7(4);...
            '4',app.Punto8(2),app.Punto8(1), app.Punto8(3),app.Punto8(5),app.Punto8(4)};

            app.UITable_Resultados_2_ciclo2.Data={app.w_compresor2;app.q_condensador2; app.q_evaporador2;...
                app.CF_refrigeracion2;app.CF_calefaccion2};
            
            Q_condensador=app.q_condensador1*app.m1;  
            app.RefrigseleccionadoEditField_RelacionCaudalesMasicos_2.Value=num2str(round(app.Relacion_Caudales,4));
            app.RefrigseleccionadoEditField_Q_evaporador.Value=num2str(round(Q_condensador,3));
            app.RefrigseleccionadoEditField_CF_Refrigeracion.Value=num2str(round(app.CF_refrigeracion_ciclo,3));
            app.RefrigseleccionadoEditField_CF_Calefaccion.Value=num2str(round(app.CF_calefaccion_ciclo,3));
 
 
            
            
        end

        % Button pushed function: ExportarresultadosButton
        function ExportarresultadosButtonPushed(app, ~)
            
            Data=get(app.UITable_Resultados_ciclo1,'Data');
            ColumnName=get(app.UITable_Resultados_ciclo1,'ColumnName');
            ColumnName=ColumnName';
            Data_Columna1=cell2mat(Data(:,1));Data_Columna1=str2num(Data_Columna1); %#ok<ST2NM> 
            Data_Columna1=num2cell(Data_Columna1);Data(:,1)=Data_Columna1;         
            Data_0=cell2mat(Data);          
            NewData=num2cell(round(Data_0,4));
            Datos1 = cell2table(NewData,'VariableNames',ColumnName);
            writetable(Datos1,'Datos del ciclo de refrigeracion Cascada.xls','Sheet','Datos Procesos ciclo1');
            
            Data1=get(app.UITable_Resultados_2_ciclo1,'Data');
            ColumnName1=get(app.UITable_Resultados_2_ciclo1,'ColumnName');
            ColumnName1=ColumnName1';
            RowName1=get(app.UITable_Resultados_2_ciclo1,'RowName');
            RowName1=RowName1';
            Data_1=cell2mat(Data1);
            NewData1=num2cell(round(Data_1,3));
            Datos2= cell2table(NewData1,'VariableNames',ColumnName1,'RowNames',RowName1);
            writetable(Datos2,'Datos del ciclo de refrigeracion Cascada.xls','Sheet','Datos ciclo1','WriteRowNames',true);           
            
                        
            Data2=get(app.UITable_Resultados_ciclo2,'Data');
            ColumnName2=get(app.UITable_Resultados_ciclo2,'ColumnName');
            ColumnName2=ColumnName2';
            Data_Columna1_1=cell2mat(Data2(:,1));Data_Columna1_1=str2num(Data_Columna1_1); %#ok<ST2NM> 
            Data_Columna1_1=num2cell(Data_Columna1_1);Data2(:,1)=Data_Columna1_1;              
            Data_2=cell2mat(Data2);          
            NewData2=num2cell(round(Data_2,4));
            Datos2 = cell2table(NewData2,'VariableNames',ColumnName2);
            writetable(Datos2,'Datos del ciclo de refrigeracion Cascada.xls','Sheet','Datos Procesos ciclo2');
            
            Data3=get(app.UITable_Resultados_2_ciclo2,'Data');
            ColumnName3=get(app.UITable_Resultados_2_ciclo2,'ColumnName');
            ColumnName3=ColumnName3';
            RowName3=get(app.UITable_Resultados_2_ciclo2,'RowName');
            RowName3=RowName3';
            Data_3=cell2mat(Data3);
            NewData3=num2cell(round(Data_3,3));
            Datos3= cell2table(NewData3,'VariableNames',ColumnName3,'RowNames',RowName3);
            writetable(Datos3,'Datos del ciclo de refrigeracion Cascada.xls','Sheet','Datos ciclo2','WriteRowNames',true);
            
            Q_condensador=app.q_condensador1*app.m1;  
            Data4={round(app.Relacion_Caudales,4);round(Q_condensador,3);round(app.CF_refrigeracion_ciclo,3);round(app.CF_calefaccion_ciclo,3)};
            RowName4={'Relaci�n de caudales (m1/m2)';'Caudal de calor condensador1/evaporador2 (kW)';...
                'C.F. Refrigeraci�n del ciclo';'C.F. Calefacci�n del ciclo'};
            Datos4= cell2table(Data4,'VariableNames',{'Valores'},'RowNames',RowName4);
            writetable(Datos4,'Datos del ciclo de refrigeracion Cascada.xls','Sheet','Datos ciclo completo','WriteRowNames',true);
            

        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 1242 813];
            app.UIFigure.Name = 'Cascade Vapor-Compression Refrigeration Cycle';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [2 1 1259 813];

            % Create DatosInicialesTab
            app.DatosInicialesTab = uitab(app.TabGroup);
            app.DatosInicialesTab.Title = 'Initial values';

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.DatosInicialesTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [64 713 327 60];
            app.TextArea_3.Value = {'Cascade Vapor-Compression Refrigeration Cycle'};

            % Create UITable_DatosIniciales_ciclo1
            app.UITable_DatosIniciales_ciclo1 = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales_ciclo1.ColumnName = {'Variable'; 'Value'};
            app.UITable_DatosIniciales_ciclo1.RowName = {''};
            app.UITable_DatosIniciales_ciclo1.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales_ciclo1.FontWeight = 'bold';
            app.UITable_DatosIniciales_ciclo1.Position = [22 453 290 132];

            % Create TextArea_4
            app.TextArea_4 = uitextarea(app.DatosInicialesTab);
            app.TextArea_4.HorizontalAlignment = 'center';
            app.TextArea_4.FontSize = 18;
            app.TextArea_4.FontWeight = 'bold';
            app.TextArea_4.Position = [64 634 327 30];
            app.TextArea_4.Value = {'Initial values'};

            % Create UIAxes_PH_ciclo1
            app.UIAxes_PH_ciclo1 = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH_ciclo1, 'Diagram p-h')
            xlabel(app.UIAxes_PH_ciclo1, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH_ciclo1, 'Pressure (bar)')
            app.UIAxes_PH_ciclo1.Position = [586 481 300 185];

            % Create UIAxes_TS_ciclo1
            app.UIAxes_TS_ciclo1 = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS_ciclo1, 'Diagram T-s')
            xlabel(app.UIAxes_TS_ciclo1, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS_ciclo1, 'Temperature (K)')
            app.UIAxes_TS_ciclo1.Position = [586 274 300 185];

            % Create UIAxes_PV_ciclo1
            app.UIAxes_PV_ciclo1 = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV_ciclo1, 'Diagram p-v')
            xlabel(app.UIAxes_PV_ciclo1, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV_ciclo1, 'Pressure (bar)')
            app.UIAxes_PV_ciclo1.Position = [586 75 300 185];

            % Create Image
            app.Image = uiimage(app.DatosInicialesTab);
            app.Image.Position = [22 24 182 148];
            app.Image.ImageSource = 'Pollo Transparente.gif';

            % Create EjecutarButton_2
            app.EjecutarButton_2 = uibutton(app.DatosInicialesTab, 'push');
            app.EjecutarButton_2.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton_2.Position = [177 683 100 22];
            app.EjecutarButton_2.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [57 218 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [281 218 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Position = [221 108 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [221 75 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Refrigeration cycles';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [211 40 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create ExportarresultadosButton
            app.ExportarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.ExportarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @ExportarresultadosButtonPushed, true);
            app.ExportarresultadosButton.Position = [157 180 120 22];
            app.ExportarresultadosButton.Text = 'Export results';

            % Create Refrigerante1Label
            app.Refrigerante1Label = uilabel(app.DatosInicialesTab);
            app.Refrigerante1Label.BackgroundColor = [1 1 1];
            app.Refrigerante1Label.HorizontalAlignment = 'center';
            app.Refrigerante1Label.FontWeight = 'bold';
            app.Refrigerante1Label.Position = [337 601 87 22];
            app.Refrigerante1Label.Text = 'Refrigerant 1';

            % Create RefrigeranteListBox_ciclo1
            app.RefrigeranteListBox_ciclo1 = uilistbox(app.DatosInicialesTab);
            app.RefrigeranteListBox_ciclo1.Items = {'Random', 'R22', 'R134a', 'R507A', 'R404A', 'R407C', 'R410A'};
            app.RefrigeranteListBox_ciclo1.ItemsData = {'0', '1', '2', '3', '4', '5', '6'};
            app.RefrigeranteListBox_ciclo1.Position = [430 492 92 132];
            app.RefrigeranteListBox_ciclo1.Value = '0';

            % Create Refrig1seleccionadoLabel
            app.Refrig1seleccionadoLabel = uilabel(app.DatosInicialesTab);
            app.Refrig1seleccionadoLabel.HorizontalAlignment = 'right';
            app.Refrig1seleccionadoLabel.FontWeight = 'bold';
            app.Refrig1seleccionadoLabel.Position = [274 453 133 22];
            app.Refrig1seleccionadoLabel.Text = 'Refrig. 1';

            % Create RefrigseleccionadoEditField_ciclo1
            app.RefrigseleccionadoEditField_ciclo1 = uieditfield(app.DatosInicialesTab, 'text');
            app.RefrigseleccionadoEditField_ciclo1.Position = [422 453 100 22];

            % Create UIAxes_PH_ciclo2
            app.UIAxes_PH_ciclo2 = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH_ciclo2, 'Diagram p-h')
            xlabel(app.UIAxes_PH_ciclo2, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH_ciclo2, 'Pressure (bar)')
            app.UIAxes_PH_ciclo2.Position = [932 483 300 185];

            % Create UIAxes_TS_ciclo2
            app.UIAxes_TS_ciclo2 = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS_ciclo2, 'Diagram T-s')
            xlabel(app.UIAxes_TS_ciclo2, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS_ciclo2, 'Temperature (K)')
            app.UIAxes_TS_ciclo2.Position = [932 274 300 185];

            % Create UIAxes_PV_ciclo2
            app.UIAxes_PV_ciclo2 = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV_ciclo2, 'Diagram p-v')
            xlabel(app.UIAxes_PV_ciclo2, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV_ciclo2, 'Pressure (bar)')
            app.UIAxes_PV_ciclo2.Position = [932 75 300 185];

            % Create UITable_DatosIniciales_ciclo2
            app.UITable_DatosIniciales_ciclo2 = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales_ciclo2.ColumnName = {'Variable'; 'Value'};
            app.UITable_DatosIniciales_ciclo2.RowName = {''};
            app.UITable_DatosIniciales_ciclo2.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales_ciclo2.FontWeight = 'bold';
            app.UITable_DatosIniciales_ciclo2.Position = [26 268 290 132];

            % Create Refrig2seleccionadoLabel
            app.Refrig2seleccionadoLabel = uilabel(app.DatosInicialesTab);
            app.Refrig2seleccionadoLabel.HorizontalAlignment = 'right';
            app.Refrig2seleccionadoLabel.FontWeight = 'bold';
            app.Refrig2seleccionadoLabel.Position = [274 268 133 22];
            app.Refrig2seleccionadoLabel.Text = 'Refrig. 2';

            % Create RefrigseleccionadoEditField_ciclo2
            app.RefrigseleccionadoEditField_ciclo2 = uieditfield(app.DatosInicialesTab, 'text');
            app.RefrigseleccionadoEditField_ciclo2.Position = [426 268 100 22];

            % Create Refrigerante2Label
            app.Refrigerante2Label = uilabel(app.DatosInicialesTab);
            app.Refrigerante2Label.BackgroundColor = [1 1 1];
            app.Refrigerante2Label.HorizontalAlignment = 'center';
            app.Refrigerante2Label.FontWeight = 'bold';
            app.Refrigerante2Label.Position = [337 409 87 22];
            app.Refrigerante2Label.Text = 'Refrigerant 2';

            % Create RefrigeranteListBox_ciclo2
            app.RefrigeranteListBox_ciclo2 = uilistbox(app.DatosInicialesTab);
            app.RefrigeranteListBox_ciclo2.Items = {'Random', 'R22', 'R134a', 'R507A', 'R404A', 'R407C', 'R410A'};
            app.RefrigeranteListBox_ciclo2.ItemsData = {'0', '1', '2', '3', '4', '5', '6'};
            app.RefrigeranteListBox_ciclo2.Position = [430 300 92 132];
            app.RefrigeranteListBox_ciclo2.Value = '0';

            % Create TextArea_9
            app.TextArea_9 = uitextarea(app.DatosInicialesTab);
            app.TextArea_9.HorizontalAlignment = 'center';
            app.TextArea_9.FontSize = 18;
            app.TextArea_9.FontWeight = 'bold';
            app.TextArea_9.Position = [629 710 213 30];
            app.TextArea_9.Value = {'Cycle 1'};

            % Create TextArea_10
            app.TextArea_10 = uitextarea(app.DatosInicialesTab);
            app.TextArea_10.HorizontalAlignment = 'center';
            app.TextArea_10.FontSize = 18;
            app.TextArea_10.FontWeight = 'bold';
            app.TextArea_10.Position = [975 710 213 30];
            app.TextArea_10.Value = {'Cycle 2'};

            % Create TextArea_11
            app.TextArea_11 = uitextarea(app.DatosInicialesTab);
            app.TextArea_11.HorizontalAlignment = 'center';
            app.TextArea_11.FontSize = 18;
            app.TextArea_11.FontWeight = 'bold';
            app.TextArea_11.Position = [40 593 213 30];
            app.TextArea_11.Value = {'Cycle 1'};

            % Create TextArea_12
            app.TextArea_12 = uitextarea(app.DatosInicialesTab);
            app.TextArea_12.HorizontalAlignment = 'center';
            app.TextArea_12.FontSize = 18;
            app.TextArea_12.FontWeight = 'bold';
            app.TextArea_12.Position = [36 409 213 30];
            app.TextArea_12.Value = {'Cycle 2'};

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Results';

            % Create UITable_Resultados_ciclo1
            app.UITable_Resultados_ciclo1 = uitable(app.ResultadosTab);
            app.UITable_Resultados_ciclo1.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados_ciclo1.RowName = {};
            app.UITable_Resultados_ciclo1.Position = [37 567 620 110];

            % Create TextArea_5
            app.TextArea_5 = uitextarea(app.ResultadosTab);
            app.TextArea_5.HorizontalAlignment = 'center';
            app.TextArea_5.FontSize = 18;
            app.TextArea_5.FontWeight = 'bold';
            app.TextArea_5.Position = [150 729 327 30];
            app.TextArea_5.Value = {'Results of the cycle'};

            % Create UITable_Resultados_2_ciclo1
            app.UITable_Resultados_2_ciclo1 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2_ciclo1.ColumnName = {'Heat and work exchanged'};
            app.UITable_Resultados_2_ciclo1.RowName = {'w (compressor) (kJ/kg)'; 'q (condenser) (kJ/kg)'; 'q (evaporator) (kJ/kg)'; 'COP refrigerator'; 'COP heat pump'};
            app.UITable_Resultados_2_ciclo1.Position = [37 406 343 131];

            % Create Image2
            app.Image2 = uiimage(app.ResultadosTab);
            app.Image2.Position = [915 10 280 480];
            app.Image2.ImageSource = 'Ciclo refrigeracion cascada.png';

            % Create UITable_Procesos
            app.UITable_Procesos = uitable(app.ResultadosTab);
            app.UITable_Procesos.ColumnName = {'Process'; 'Description'};
            app.UITable_Procesos.ColumnWidth = {60, 'auto'};
            app.UITable_Procesos.RowName = {''};
            app.UITable_Procesos.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Procesos.FontWeight = 'bold';
            app.UITable_Procesos.FontSize = 14;
            app.UITable_Procesos.Position = [690 495 440 222];

            % Create TextArea_8
            app.TextArea_8 = uitextarea(app.ResultadosTab);
            app.TextArea_8.HorizontalAlignment = 'center';
            app.TextArea_8.FontSize = 18;
            app.TextArea_8.FontWeight = 'bold';
            app.TextArea_8.Position = [732 729 327 30];
            app.TextArea_8.Value = {'Processes'};

            % Create UITable_Resultados_ciclo2
            app.UITable_Resultados_ciclo2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_ciclo2.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados_ciclo2.RowName = {};
            app.UITable_Resultados_ciclo2.Position = [37 236 620 110];

            % Create UITable_Resultados_2_ciclo2
            app.UITable_Resultados_2_ciclo2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2_ciclo2.ColumnName ={'Heat and work exchanged'};
            app.UITable_Resultados_2_ciclo2.RowName = {'w (compressor) (kJ/kg)'; 'q (condenser) (kJ/kg)'; 'q (evaporator) (kJ/kg)'; 'COP refrigerator'; 'COP heat pump'};
            app.UITable_Resultados_2_ciclo2.Position = [37 75 343 131];

            % Create TextArea_13
            app.TextArea_13 = uitextarea(app.ResultadosTab);
            app.TextArea_13.HorizontalAlignment = 'center';
            app.TextArea_13.FontSize = 18;
            app.TextArea_13.FontWeight = 'bold';
            app.TextArea_13.Position = [37 689 213 30];
            app.TextArea_13.Value = {'Cycle 1'};

            % Create TextArea_14
            app.TextArea_14 = uitextarea(app.ResultadosTab);
            app.TextArea_14.HorizontalAlignment = 'center';
            app.TextArea_14.FontSize = 18;
            app.TextArea_14.FontWeight = 'bold';
            app.TextArea_14.Position = [37 359 213 30];
            app.TextArea_14.Value = {'Cycle 2'};

            % Create Relacindecaudalesm1m2Label_2
            app.Relacindecaudalesm1m2Label_2 = uilabel(app.ResultadosTab);
            app.Relacindecaudalesm1m2Label_2.HorizontalAlignment = 'right';
            app.Relacindecaudalesm1m2Label_2.FontWeight = 'bold';
            app.Relacindecaudalesm1m2Label_2.Position = [589 150 181 22];
            app.Relacindecaudalesm1m2Label_2.Text = 'Mas flowrates ratio (m1/m2):';

            % Create RefrigseleccionadoEditField_RelacionCaudalesMasicos_2
            app.RefrigseleccionadoEditField_RelacionCaudalesMasicos_2 = uieditfield(app.ResultadosTab, 'text');
            app.RefrigseleccionadoEditField_RelacionCaudalesMasicos_2.Position = [785 150 100 22];

            % Create CFrefrigeracindelcicloLabel
            app.CFrefrigeracindelcicloLabel = uilabel(app.ResultadosTab);
            app.CFrefrigeracindelcicloLabel.HorizontalAlignment = 'right';
            app.CFrefrigeracindelcicloLabel.FontWeight = 'bold';
            app.CFrefrigeracindelcicloLabel.Position = [616 75 154 22];
            app.CFrefrigeracindelcicloLabel.Text = 'COP refrigerator';

            % Create RefrigseleccionadoEditField_CF_Refrigeracion
            app.RefrigseleccionadoEditField_CF_Refrigeracion = uieditfield(app.ResultadosTab, 'text');
            app.RefrigseleccionadoEditField_CF_Refrigeracion.Position = [785 75 100 22];

            % Create CFcalefaccindelcicloLabel
            app.CFcalefaccindelcicloLabel = uilabel(app.ResultadosTab);
            app.CFcalefaccindelcicloLabel.HorizontalAlignment = 'right';
            app.CFcalefaccindelcicloLabel.FontWeight = 'bold';
            app.CFcalefaccindelcicloLabel.Position = [623 40 147 22];
            app.CFcalefaccindelcicloLabel.Text = 'COP heat pump';

            % Create RefrigseleccionadoEditField_CF_Calefaccion
            app.RefrigseleccionadoEditField_CF_Calefaccion = uieditfield(app.ResultadosTab, 'text');
            app.RefrigseleccionadoEditField_CF_Calefaccion.Position = [785 40 100 22];

            % Create TextArea_15
            app.TextArea_15 = uitextarea(app.ResultadosTab);
            app.TextArea_15.HorizontalAlignment = 'center';
            app.TextArea_15.FontSize = 18;
            app.TextArea_15.FontWeight = 'bold';
            app.TextArea_15.Position = [732 729 327 30];
            app.TextArea_15.Value = {'Processes'};

            % Create CaudaldecalorCondensadorEvaporadorkWLabel
            app.CaudaldecalorCondensadorEvaporadorkWLabel = uilabel(app.ResultadosTab);
            app.CaudaldecalorCondensadorEvaporadorkWLabel.HorizontalAlignment = 'right';
            app.CaudaldecalorCondensadorEvaporadorkWLabel.FontWeight = 'bold';
            app.CaudaldecalorCondensadorEvaporadorkWLabel.Position = [491 116 279 22];
            app.CaudaldecalorCondensadorEvaporadorkWLabel.Text = 'Q heat exchanger (kW)';

            % Create RefrigseleccionadoEditField_Q_evaporador
            app.RefrigseleccionadoEditField_Q_evaporador = uieditfield(app.ResultadosTab, 'text');
            app.RefrigseleccionadoEditField_Q_evaporador.Position = [785 116 100 22];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = CascadeVaporCompressionRefrigeration

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end