function valores=CurvaCompresorRefrigerantes(P_Inicial,rp, T_Inicial,s_inicial,h_inicial, eficiencia, refrigerante, sobrecalentamiento, N_Puntos)
    
    % Equipo: valor 1 para compresores y 0 para turbinas
    % Valores de entrada
    % P en bar; T en K; s en kJ/kg�K; h en kJ/kg; Cp en kJ/kg�K
    entalpias=ones(1,N_Puntos);
    entropias=ones(1,N_Puntos);
    volumen=ones(1,N_Puntos);
    temperaturas=ones(1,N_Puntos);

    %temperaturas= linspace(T_Inicial,T_Final,N_Puntos); % Para diagramas P-v y P-h
    entalpias(1)=h_inicial;
    entropias(1)=s_inicial;
    temperaturas(1)=T_Inicial;
    
    if sobrecalentamiento==0
        volumen(1)=CoolProp.PropsSI('D', 'P', P_Inicial*1E5, 'Q', 1, refrigerante)^-1;  % en m3/kg;
    else
        volumen(1)=CoolProp.PropsSI('D', 'P', P_Inicial*1E5, 'T', temperaturas(1), refrigerante)^-1;  % en m3/kg;
    end

    presiones= linspace(P_Inicial,P_Inicial*rp,N_Puntos);  % en bar (para diagramas T-s y se han de introducir en bar)
        

    
    for i=2:N_Puntos
        h_adiabatica=CoolProp.PropsSI('H', 'P', presiones(i)*1E5, 'S',...
            entropias(1)*1E3, refrigerante)/1000;% en kJ/kg
        
        entalpias(i)=entalpias(1)+(h_adiabatica-entalpias(1))/eficiencia;   
        entropias(i)=CoolProp.PropsSI('S', 'P', presiones(i)*1E5, 'H', entalpias(i)*1E3, refrigerante)/1000; % en kJ/kg�K
        volumen(i)=CoolProp.PropsSI('D', 'P', presiones(i)*1E5, 'H', entalpias(i)*1E3, refrigerante)^-1;  % en m3/kg
        temperaturas(i)=CoolProp.PropsSI('T', 'P', presiones(i)*1E5, 'H', entalpias(i)*1E3, refrigerante); % en kJ/kg�K        
        
    end

    valores=struct();
    valores.presiones=presiones;
    valores.entalpias=entalpias;
    valores.volumen=volumen;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;
end