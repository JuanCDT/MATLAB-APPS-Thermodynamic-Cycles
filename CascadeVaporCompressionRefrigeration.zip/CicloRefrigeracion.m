function solucion=CicloRefrigeracion(refrigerante, parametros)

    

    CeldaParametros=num2cell(parametros);
    [T1,P1,T3,P3,eficienciaCompresor,sobrecalentamiento,subenfriamiento]=deal(CeldaParametros{:});
    
    % Condiciones conocidas
    P1=P1*1E5; % Cambio a Pa
    P3=P3*1E5; % Cambio a Pa

    % C�lculo salida del compresor
    if sobrecalentamiento==0
        s1=CoolProp.PropsSI('S', 'Q', 1, 'T', T1, refrigerante);
        h1= CoolProp.PropsSI('H', 'P', P1, 'Q', 1, refrigerante)/1000;% en kJ/kg
        %V1= CoolProp.PropsSI('D', 'P', P1, 'Q', 1, refrigerante)^-1;% en m3/kg
    else
        s1=CoolProp.PropsSI('S', 'P', P1, 'T', T1, refrigerante);
        h1= CoolProp.PropsSI('H', 'P', P1, 'S', s1, refrigerante)/1000;% en kJ/kg
        %V1= CoolProp.PropsSI('D', 'P', P1, 'S', s1, refrigerante)^-1;% en m3/kg
    end  
      

    % C�lculo entalp�as y trabajo en el compresor ideal
    T2= CoolProp.PropsSI('T', 'P', P3, 'S', s1, refrigerante);
    h2= CoolProp.PropsSI('H', 'P', P3, 'S', s1, refrigerante)/1000; % en kJ/kg
    
    w_compresor=h2-h1; % en kJ/kg
    % C�lculo entalp�as y trabajo en el compresor real
    if eficienciaCompresor~=1
        h2=w_compresor/eficienciaCompresor+h1;
        w_compresor=w_compresor/eficienciaCompresor;
        T2= CoolProp.PropsSI('T', 'P', P3, 'H', h2*1000, refrigerante);
    end
    

    % C�lculo calores de evaporaci�n y condensaci�n y condiciones a la
    % salida de la v�lvula de expansi�n
    if subenfriamiento==0
        h3=CoolProp.PropsSI('H', 'Q', 0, 'T', T3, refrigerante)/1000; % en kJ/kg
        %V3=CoolProp.PropsSI('D', 'Q', 0, 'T', T3, refrigerante)^-1; % en m3/kg
        %s3=CoolProp.PropsSI('S', 'Q', 0, 'T', T3, refrigerante)/1000; % en kJ/kg�K
    else
        h3=CoolProp.PropsSI('H', 'P', P3, 'T', T3, refrigerante)/1000; % en kJ/kg
        %V3=CoolProp.PropsSI('D', 'P', P3, 'T', T3, refrigerante)^-1;  % en m3/kg
        %s3=CoolProp.PropsSI('S', 'P', P3, 'T', T3, refrigerante)/1000; % en kJ/kg�K
    end  

    q_condensador=h2-h3; % en kJ/kg
    q_evaporador=h1-h3;
    h4= h3;
    T4=CoolProp.PropsSI('T', 'P', P1, 'H', h4*1E3, refrigerante); % en K
    x4=CoolProp.PropsSI('Q', 'P', P1, 'H', h4*1E3, refrigerante); % en K

    
    % C�lculo coeficientes funcionamiento
    CF_refrigeracion=q_evaporador/w_compresor; 
    CF_calefaccion=q_condensador/w_compresor; 
    
    SalidaCompresor=[T2,P3*1E-5,h2];
    SalidaValvula=[T4,P1*1E-5, h4, x4];
    solucion=[SalidaCompresor,SalidaValvula,w_compresor,CF_refrigeracion,CF_calefaccion];
   
end

