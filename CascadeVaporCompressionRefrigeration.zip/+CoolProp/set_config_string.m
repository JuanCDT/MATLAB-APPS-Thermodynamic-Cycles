function varargout = set_config_string(varargin)
  [varargout{1:nargout}] = CoolPropMATLAB_wrap(451,varargin{:});
end
