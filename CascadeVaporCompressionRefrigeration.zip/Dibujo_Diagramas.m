         
function  Dibujo_Diagramas(refrigerante,parametros,solucion,PH_ciclo1,TS_ciclo1,PV_ciclo1)

    TCritica=struct('R22',369.295,'R134a',374.21,'R507A',343.765,'R404A',345.27,'R407C',359.345,'R410A',344.494);
    Tc=TCritica.(refrigerante);
    
    Punto1=solucion.Punto1;
    Punto2= solucion.Punto2;
    Punto3= solucion.Punto3;
    Punto4= solucion.Punto4;

                        
    cla(PH_ciclo1);
    cla(TS_ciclo1);
    cla(PV_ciclo1) ; 

    rp= Punto2(2)/Punto1(2);


    % Valores propiedades a lo largo de los procesos            
    % Puntos del proceso

    %Ciclo1
   eficienciaCompresor=  parametros(5);
   sobrecalentamiento=  parametros(6);
   subenfriamiento=  parametros(7);

   Entalpias=[  Punto1(3),  Punto2(3),  Punto3(3),  Punto4(3)];
   Temperaturas=[  Punto1(1),  Punto2(1),  Punto3(1),  Punto4(1)];
   Presiones=[  Punto1(2),  Punto2(2),  Punto3(2),  Punto4(2)];
   Volumenes=[  Punto1(4),  Punto2(4),  Punto3(4),  Punto4(4)];
   Entropias=[  Punto1(5),  Punto2(5),  Punto3(5),  Punto4(5)];

   % Domo saturacion
   T_Inicial=  Punto4(1)-5;
   
   valores_VaporSaturado=CurvaVaporSaturado(T_Inicial, Tc,  refrigerante, 500);
   valores_LiquidoSaturado=CurvaLiquidoSaturado(T_Inicial, Tc,  refrigerante, 500);

    h_VaporSaturado=valores_VaporSaturado.entalpias;
    p_VaporSaturado=valores_VaporSaturado.presiones;
    v_VaporSaturado=valores_VaporSaturado.volumen;
    s_VaporSaturado=valores_VaporSaturado.entropias;
    T_VaporSaturado=valores_VaporSaturado.temperaturas;

    h_LiquidoSaturado=valores_LiquidoSaturado.entalpias;
    p_LiquidoSaturado=valores_LiquidoSaturado.presiones;
    v_LiquidoSaturado=valores_LiquidoSaturado.volumen;
    s_LiquidoSaturado=valores_LiquidoSaturado.entropias;
    T_LiquidoSaturado=valores_LiquidoSaturado.temperaturas;

    % Proceso 1 - Compresi�n
    valoresProceso1=CurvaCompresorRefrigerantes(  Punto1(2),rp,   Punto1(1),  Punto1(5),  Punto1(3),...   
        eficienciaCompresor,   refrigerante, sobrecalentamiento,200);        

    h_Proceso1=valoresProceso1.entalpias;
    p_Proceso1=valoresProceso1.presiones;
    v_Proceso1=valoresProceso1.volumen;
    s_Proceso1=valoresProceso1.entropias;
    T_Proceso1=valoresProceso1.temperaturas;

    % Proceso 2 - Condensador

    valoresProceso2=CurvaIsobara(  Punto2(3),  Punto2(2),   Punto3(3),  refrigerante,  200);

    v_VS=CoolProp.PropsSI('D', 'P',   Punto2(2)*1E5, 'Q', 1,   refrigerante)^-1;  % en m3/kg
    s_VS=CoolProp.PropsSI('S', 'P',   Punto2(2)*1E5, 'Q', 1,   refrigerante)/1000; % en kJ/kg�K
    T_VS=CoolProp.PropsSI('T', 'P',   Punto2(2)*1E5, 'Q', 1,   refrigerante);  % en K
    h_VS=CoolProp.PropsSI('H', 'P',   Punto2(2)*1E5, 'Q', 1,   refrigerante)/1000; % en kJ/kg

    valoresProceso2.entalpias(end+1)=h_VS; valoresProceso2.entalpias=sort(valoresProceso2.entalpias);
    valoresProceso2.volumen(end+1)=v_VS; valoresProceso2.volumen=sort(valoresProceso2.volumen);
    valoresProceso2.entropias(end+1)=s_VS; valoresProceso2.entropias=sort(valoresProceso2.entropias);
    valoresProceso2.temperaturas(end+1)=T_VS; valoresProceso2.temperaturas=sort(valoresProceso2.temperaturas);
    valoresProceso2.presiones(end+1)=  Punto2(2);                              


    if subenfriamiento~=0
        v_LS=CoolProp.PropsSI('D', 'P',   Punto2(2)*1E5, 'Q', 0,   refrigerante)^-1;  % en m3/kg
        s_LS=CoolProp.PropsSI('S', 'P',   Punto2(2)*1E5, 'Q', 0,   refrigerante)/1000; % en kJ/kg�K
        T_LS=CoolProp.PropsSI('T', 'P',   Punto2(2)*1E5, 'Q', 0,   refrigerante);  % en K
        h_LS=CoolProp.PropsSI('H', 'P',   Punto2(2)*1E5, 'Q', 0,   refrigerante)/1000; % en kJ/kg

        valoresProceso2.entalpias(end+1)=h_LS; valoresProceso2.entalpias=sort(valoresProceso2.entalpias);
        valoresProceso2.volumen(end+1)=v_LS; valoresProceso2.volumen=sort(valoresProceso2.volumen);
        valoresProceso2.entropias(end+1)=s_LS; valoresProceso2.entropias=sort(valoresProceso2.entropias);
        valoresProceso2.temperaturas(end+1)=T_LS; valoresProceso2.temperaturas=sort(valoresProceso2.temperaturas);
        valoresProceso2.presiones(end+1)=  Punto2(2);   
    end

    h_Proceso2=valoresProceso2.entalpias;
    p_Proceso2=valoresProceso2.presiones;
    v_Proceso2=valoresProceso2.volumen;
    s_Proceso2=valoresProceso2.entropias;
    T_Proceso2=valoresProceso2.temperaturas;



    % Proceso 3 - Expansion isoentalpica

    if subenfriamiento==0
        valoresProceso3=CurvaIsentalpicaSaturado(  Punto3(2),  Punto3(3),   Punto4(2),  refrigerante, 200);      
    else
        valoresProceso3=CurvaIsentalpica(  Punto3(2),  Punto3(3),   Punto4(2),  refrigerante, 200);  
    end


    h_Proceso3=valoresProceso3.entalpias;
    p_Proceso3=valoresProceso3.presiones;
    v_Proceso3=valoresProceso3.volumen;
    s_Proceso3=valoresProceso3.entropias;
    T_Proceso3=valoresProceso3.temperaturas;

    % Proceso 4 - Evaporador

    valoresProceso4=CurvaIsobara(  Punto4(3),  Punto4(2),   Punto1(3),  refrigerante,  200);                      


    if sobrecalentamiento~=0

        v_VS=CoolProp.PropsSI('D', 'P',   Punto4(2)*1E5, 'Q', 1,   refrigerante)^-1;  % en m3/kg
        s_VS=CoolProp.PropsSI('S', 'P',   Punto4(2)*1E5, 'Q', 1,   refrigerante)/1000; % en kJ/kg�K
        T_VS=CoolProp.PropsSI('T', 'P',   Punto4(2)*1E5, 'Q', 1,   refrigerante);  % en K
        h_VS=CoolProp.PropsSI('H', 'P',   Punto4(2)*1E5, 'Q', 1,   refrigerante)/1000; % en kJ/kg

        valoresProceso4.entalpias(end+1)=h_VS; valoresProceso4.entalpias=sort(valoresProceso4.entalpias);
        valoresProceso4.volumen(end+1)=v_VS; valoresProceso4.volumen=sort(valoresProceso4.volumen);
        valoresProceso4.entropias(end+1)=s_VS; valoresProceso4.entropias=sort(valoresProceso4.entropias);
        valoresProceso4.temperaturas(end+1)=T_VS; valoresProceso4.temperaturas=sort(valoresProceso4.temperaturas);
        valoresProceso4.presiones(end+1)=  Punto4(2);                              

    end


    h_Proceso4=valoresProceso4.entalpias;
    p_Proceso4=valoresProceso4.presiones;
    v_Proceso4=valoresProceso4.volumen;
    s_Proceso4=valoresProceso4.entropias;
    T_Proceso4=valoresProceso4.temperaturas;

    % Diagrama p-h
    hold(PH_ciclo1,'on');

      PH_ciclo1.YScale = 'log';

    %domo
    plot(PH_ciclo1,  h_LiquidoSaturado,p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
    plot(PH_ciclo1, h_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');

    % puntos y procesos
    plot(PH_ciclo1, Entalpias, Presiones,'color','r','Marker','o','LineStyle','none');
    plot(PH_ciclo1, h_Proceso1, p_Proceso1,'color','r','Marker','none','LineStyle','-');
    plot(PH_ciclo1, h_Proceso2, p_Proceso2,'color','r','Marker','none','LineStyle','-');
    plot(PH_ciclo1, h_Proceso3, p_Proceso3,'color','r','Marker','none','LineStyle','-');
    plot(PH_ciclo1, h_Proceso4, p_Proceso4,'color','r','Marker','none','LineStyle','-');

    hold(  PH_ciclo1,'off');

    PH_ciclo1.XLimMode = 'auto';
    PH_ciclo1.YLimMode = 'auto';

    % Diagrama p-v


    hold(  PV_ciclo1,'on');

    PV_ciclo1.YScale = 'log';
    PV_ciclo1.XScale = 'log';

%             % domo
    plot(PV_ciclo1, v_LiquidoSaturado, p_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
    plot(PV_ciclo1, v_VaporSaturado, p_VaporSaturado,'color','k','Marker','none','LineStyle','-');


    % puntos y procesos
    plot(  PV_ciclo1,Volumenes, Presiones,'color','b','Marker','o','LineStyle','none');
    plot(  PV_ciclo1, v_Proceso1, p_Proceso1,'color','b','Marker','none','LineStyle','-');
    plot(  PV_ciclo1, v_Proceso2, p_Proceso2,'color','b','Marker','none','LineStyle','-');
    plot(  PV_ciclo1, v_Proceso3, p_Proceso3,'color','b','Marker','none','LineStyle','-');
    plot(  PV_ciclo1, v_Proceso4, p_Proceso4,'color','b','Marker','none','LineStyle','-');


    hold(PV_ciclo1,'off');

    PV_ciclo1.XLimMode = 'auto';
    PV_ciclo1.YLimMode = 'auto';
%             
%               PV_ciclo1 XLabel Interpreter = 'latex';
%               PV_ciclo1 XLabel String='$\textrm(Volumen \quad  espec�fico) \quad  (m^{3}/kg)$';

%             ylabel(  PV_ciclo1,'$\text(Volumen espec�fico )  (m^{3}/kg)$','Interpreter', 'latex');


    % Diagrama T-s

   hold(TS_ciclo1,'on');


%             
%             % domo
    plot(TS_ciclo1, s_LiquidoSaturado, T_LiquidoSaturado,'color','k','Marker','none','LineStyle','-');
    plot(TS_ciclo1, s_VaporSaturado, T_VaporSaturado,'color','k','Marker','none','LineStyle','-');

    % puntos y procesos
    plot(TS_ciclo1, Entropias,Temperaturas,'color','g','Marker','o','LineStyle','none');
    plot(TS_ciclo1, s_Proceso1, T_Proceso1,'color','g','Marker','none','LineStyle','-');
    plot(TS_ciclo1, s_Proceso2, T_Proceso2,'color','g','Marker','none','LineStyle','-');
    plot(TS_ciclo1, s_Proceso3, T_Proceso3,'color','g','Marker','none','LineStyle','-');
    plot(TS_ciclo1, s_Proceso4, T_Proceso4,'color','g','Marker','none','LineStyle','-');


    hold(TS_ciclo1,'off');

    TS_ciclo1.XLimMode = 'auto';
     TS_ciclo1.YLimMode = 'auto';  
end