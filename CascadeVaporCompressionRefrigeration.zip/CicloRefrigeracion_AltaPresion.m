function solucion=CicloRefrigeracion_AltaPresion(refrigerante, parametros,Q_evaporador)

    solucion=struct();
    
    CeldaParametros=num2cell(parametros);
    [T1,p1,T3,p3,eficienciaCompresor,sobrecalentamiento,subenfriamiento]=deal(CeldaParametros{:});
    
    % Condiciones conocidas
    P1=p1*1E5; % Cambio a Pa
    P3=p3*1E5; % Cambio a Pa

    % C�lculo salida del compresor
    if sobrecalentamiento==0
        s1=CoolProp.PropsSI('S', 'Q', 1, 'T', T1, refrigerante)/1000;
        h1= CoolProp.PropsSI('H', 'P', P1, 'Q', 1, refrigerante)/1000;% en kJ/kg
        V1= CoolProp.PropsSI('D', 'P', P1, 'Q', 1, refrigerante)^-1;% en m3/kg
    else
        s1=CoolProp.PropsSI('S', 'P', P1, 'T', T1, refrigerante)/1000;
        h1= CoolProp.PropsSI('H', 'P', P1, 'S', s1*1E3, refrigerante)/1000;% en kJ/kg
        V1= CoolProp.PropsSI('D', 'P', P1, 'S', s1*1E3, refrigerante)^-1;% en m3/kg
    end  
      
    Punto1=[T1,p1,h1,V1,s1];
    solucion.Punto1=Punto1;

    % C�lculo entalp�as y trabajo en el compresor ideal
    T2= CoolProp.PropsSI('T', 'P', P3, 'S', s1*1E3, refrigerante);
    h2= CoolProp.PropsSI('H', 'P', P3, 'S', s1*1E3, refrigerante)/1000; % en kJ/kg
    
    w_compresor=h2-h1; % en kJ/kg
    % C�lculo entalp�as y trabajo en el compresor real
    if eficienciaCompresor~=1
        h2=w_compresor/eficienciaCompresor+h1;
        w_compresor=w_compresor/eficienciaCompresor;
        T2= CoolProp.PropsSI('T', 'P', P3, 'H', h2*1000, refrigerante);
    end
    
    s2=CoolProp.PropsSI('S', 'P', P3, 'T', T2, refrigerante)/1000;
    V2= CoolProp.PropsSI('D', 'P', P3, 'T', T2, refrigerante)^-1;% en m3/kg
    
    Punto2=[T2,p3,h2,V2,s2];
    solucion.Punto2=Punto2;

    % C�lculo calores de evaporaci�n y condensaci�n y condiciones a la
    % salida de la v�lvula de expansi�n
    if subenfriamiento==0
        h3=CoolProp.PropsSI('H', 'Q', 0, 'T', T3, refrigerante)/1000; % en kJ/kg
        V3=CoolProp.PropsSI('D', 'Q', 0, 'T', T3, refrigerante)^-1; % en m3/kg
        s3=CoolProp.PropsSI('S', 'Q', 0, 'T', T3, refrigerante)/1000; % en kJ/kg�K
    else
        h3=CoolProp.PropsSI('H', 'P', P3, 'T', T3, refrigerante)/1000; % en kJ/kg
        V3=CoolProp.PropsSI('D', 'P', P3, 'T', T3, refrigerante)^-1;  % en m3/kg
        s3=CoolProp.PropsSI('S', 'P', P3, 'T', T3, refrigerante)/1000; % en kJ/kg�K
    end  
    
        
    Punto3=[T3,p3,h3,V3,s3];
    solucion.Punto3=Punto3;


    q_condensador=h2-h3; % en kJ/kg
    q_evaporador=h1-h3;
    h4= h3;
    T4=CoolProp.PropsSI('T', 'P', P1, 'H', h4*1E3, refrigerante); % en K
    V4=CoolProp.PropsSI('D', 'P', P1, 'H', h4*1E3, refrigerante)^-1;  % en m3/kg
    s4=CoolProp.PropsSI('S', 'P', P1, 'H', h4*1E3, refrigerante)/1000; % en kJ/kg�K
    x4=CoolProp.PropsSI('Q', 'P', P1, 'H', h4*1E3, refrigerante); % 
    
            
    Punto4=[T4,p1,h4,V4,s4,x4];
    solucion.Punto4=Punto4;

    
    m=Q_evaporador/q_evaporador;

    
    % C�lculo coeficientes funcionamiento
    CF_refrigeracion=q_evaporador/w_compresor; 
    CF_calefaccion=q_condensador/w_compresor; 
    
    % Puntos: T,P,h,v,s
    
    ParametrosCiclo=[CF_refrigeracion,CF_calefaccion,q_condensador,q_evaporador,w_compresor,m];    
    solucion.ParametrosCiclo=ParametrosCiclo;



end

