function [refrigerante,parametros]=generadorParametrosRefrigeracion_BajaPresion(fluido)

    ListaFluidos={'R22', 'R134a', 'R507A', 'R404A', 'R407C', 'R410A'};
    fluido=str2double((fluido));    
    fluido=int16(fluido);
    
    % Selecci�n del refrigerante
    if fluido==0
        indice=randi([1 6]);
        refrigerante=char(ListaFluidos(indice));
    else
        refrigerante=char(ListaFluidos(fluido));
    end
    
    % Problema con compresi�n ideal o real
    a=randi([0 1]);
    if a
        eficienciaCompresor=1;
    else
        eficienciaCompresor = random('Uniform',0.7, 0.95);
    end
    
    % Define si el problema es con subenfriamiento, sobrecalentamiento o
    % ambos casos
   
    b=randi([0 1]);c=randi([0 1]);

    if c && b
        sobrecalentamiento=random('Uniform',2, 10);
        subenfriamiento=random('Uniform',2, 5);
    elseif c
        sobrecalentamiento=random('Uniform',2, 10);
        subenfriamiento =0;
    elseif b
        sobrecalentamiento=0;
        subenfriamiento =random('Uniform',2, 10);
    else
        sobrecalentamiento=0;
        subenfriamiento=0;
    end
    
    
    % Condiciones a la entrada del compresor y a la v�lvula de expansi�n
    T1 = round(random('Uniform',238.15,263.15),1); % Temperatura en K
    T1_VaporSaturado=T1-sobrecalentamiento;
    p1 = CoolProp.PropsSI('P', 'T', T1_VaporSaturado, 'Q', 1, refrigerante)/1E5; % en bar;
    while true 
        T3 = round(random('Uniform',293.15,300.15),1); % Temperatura en K
        T3_LiquidoSaturado=T3+subenfriamiento;
        p3 = CoolProp.PropsSI('P', 'T', T3_LiquidoSaturado, 'Q', 0, refrigerante)/1E5; % en bar;  
        
        if subenfriamiento==0
            h3=CoolProp.PropsSI('H', 'Q', 0, 'T', T3_LiquidoSaturado, refrigerante)/1000; % en kJ/kg
        else
            h3=CoolProp.PropsSI('H', 'P', p3*1E5, 'T', T3, refrigerante)/1000; % en kJ/kg
        end            
        x4=CoolProp.PropsSI('Q', 'P', p1*1E5, 'H', h3*1E3, refrigerante); % en K
        
        if x4>0 && x4<=0.5
            break
        end        
    end
    
    % Caudal m�sico a baja presi�n
    m = round(random('Uniform',0.75,2.5),3); % Temperatura en kg/s
    
    EntradaCompresor=[T1,p1];
    EntradaValvula=[T3,p3];
    parametros=[EntradaCompresor,EntradaValvula,...
    eficienciaCompresor,sobrecalentamiento,subenfriamiento,m] ;

end