function [Tsalida, hsalida, Tisentropica, TrabajoReal] = Compresor(Tentrada, Pentrada, hentrada, rp,eficiencia, gamma, Cp)

    Tisentropica=Tentrada*(1/rp)^((1-gamma)/gamma); % Temperaturas en K
    Psalida=Pentrada*rp; % Presiones en bar
    Trabajoideal=Cp*(Tisentropica-Tentrada);  % trabajos y entalp�as en kJ/kg y Cp en kJ/kg�K
    TrabajoReal=Trabajoideal/eficiencia;
    hsalida=hentrada+TrabajoReal;
    Tsalida=TrabajoReal/Cp+Tentrada;  


end