classdef Brayton_Cycle < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                      matlab.ui.Figure
        TabGroup                      matlab.ui.container.TabGroup
        DatosInicialesTab             matlab.ui.container.Tab
        TextArea_3                    matlab.ui.control.TextArea
        UITable_DatosIniciales        matlab.ui.control.Table
        TextArea_4                    matlab.ui.control.TextArea
        UIAxes_PH                     matlab.ui.control.UIAxes
        UIAxes_TS                     matlab.ui.control.UIAxes
        UIAxes_PV                     matlab.ui.control.UIAxes
        Image                         matlab.ui.control.Image
        UITable_Referencia            matlab.ui.control.Table
        TextArea_6                    matlab.ui.control.TextArea
        UITable_ParametrosAire        matlab.ui.control.Table
        TextArea_7                    matlab.ui.control.TextArea
        UITable_Eficiencias           matlab.ui.control.Table
        EjecutarButton_2              matlab.ui.control.Button
        MostrargrficosButton          matlab.ui.control.Button
        MostrarresultadosButton       matlab.ui.control.Button
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2  matlab.ui.control.Label
        TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3  matlab.ui.control.Label
        Button_CondicionesAleatorias  matlab.ui.control.Button
        Button_ReferenciaInicial      matlab.ui.control.Button
        ExportarresultadosButton      matlab.ui.control.Button
        ParmetrostablasButton         matlab.ui.control.Button
        ResultadosTab                 matlab.ui.container.Tab
        UITable_Resultados            matlab.ui.control.Table
        TextArea_5                    matlab.ui.control.TextArea
        UITable_Resultados_2          matlab.ui.control.Table
        Image2                        matlab.ui.control.Image
        %Image3                        matlab.ui.control.Image
        UITable_Procesos              matlab.ui.control.Table
        TextArea_8                    matlab.ui.control.TextArea
    end

    
    properties (Access = private)
        
        sreferencia=1.73498; % Entrop�a del aire a 300 K y 1 bar en kJ/kg�K
        hreferencia=300.19; % Entalp�a del aire a 300 K y 1 bar en kJ/kg
        Treferencia=300; % En K
        Preferencia=1; % En bar
        parametros=generadorParametros();
        R=[];
        Punto1=[], Punto2=[]; Punto3=[]; Punto4=[]
        solucion=[];       
        
    end
    
    methods (Access = private)

                
        function  Diagramas(app)
            
            app.solucion=CicloBrayton(app.parametros,app.hreferencia);
            
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
           % Puntos. Vector con T(K), P(bar), h(kJ/kg), v(m3/kg) y s (kJ/kg�K).          
            
            app.Punto1=app.parametros(1:2); app.Punto1(3)=app.hreferencia+app.parametros(7)*(app.parametros(1)-app.Treferencia);
            app.Punto2=app.solucion(1:2); app.Punto2(3)=app.solucion(8)+app.Punto1(3);
            app.Punto3=app.parametros(3:4); app.Punto3(3)=app.hreferencia+app.parametros(7)*(app.Punto3(1)-app.Punto2(1));
            app.Punto4=app.solucion(4:5);app.Punto4(3)=app.Punto3(3)-app.solucion(7);
            
            
            rp=app.Punto2(2)/app.Punto1(2);
           
            x=[app.Punto1(3),app.Punto2(3),app.Punto3(3),app.Punto4(3)];
            y=[app.Punto1(2),app.Punto2(2),app.Punto3(2),app.Punto4(2)];
            v=[Volumenes(app.Punto1(2),app.Punto1(1),app.R),Volumenes(app.Punto2(2),app.Punto2(1),app.R),...
                Volumenes(app.Punto3(2),app.Punto3(1),app.R),Volumenes(app.Punto4(2),app.Punto4(1),app.R)];
            
            % Vol�menes espec�fico
            app.Punto1(4)=v(1);app.Punto2(4)=v(2);app.Punto3(4)=v(3);app.Punto4(4)=v(4);
            
            app.Punto1(5)=Entropias(app.Punto1(2),app.Punto1(1),app.sreferencia,app.Preferencia, app.Treferencia,app.R,app.parametros(7));            
            % Procesos compresi�n y expansi�n
            valoresProceso1=CurvaTrabajo(app.Punto1(2),rp, app.Punto1(1),app.Punto1(5),app.Punto1(3),1, app.parametros(6), app.parametros(8),...
                app.parametros(7), app.R,200); % Compresi�n
            
                        
            % Diagrama p-h
            x1=valoresProceso1.entalpias;
            y1=valoresProceso1.presiones;
            v1=valoresProceso1.volumen;
            s1=valoresProceso1.entropias;
            T1=valoresProceso1.temperaturas;
            
            % Entrop�as
                        
%             if app.parametros(5)==1
%                 app.Punto2(5)=app.Punto1(5);
%             else
%                 app.Punto2(5)=s1(end);
%             end
            
            app.Punto2(5)=s1(end);
          
            % Procesos isobaros (intercambios de calor)
            valoresProceso2=CurvaIsobara(app.Punto2(1),app.Punto2(3),app.Punto2(5), app.Punto3(1),app.parametros(7), 200); % calentamiento
         
            
            s2=valoresProceso2.entropias;    
            T2=valoresProceso2.temperaturas;
            app.Punto3(5)=s2(end);                  

            valoresProceso3=CurvaTrabajo(app.Punto3(2),rp, app.Punto3(1),app.Punto3(5),app.Punto3(3),0, app.parametros(5), app.parametros(8),...
             app.parametros(7),app.R, 200); % Expansi�n

                        
            x3=valoresProceso3.entalpias;
            y3=valoresProceso3.presiones;
            v3=valoresProceso3.volumen;
            s3=valoresProceso3.entropias;
            T3=valoresProceso3.temperaturas;
%             
%             if app.parametros(5)==1
%                 app.Punto4(5)=app.Punto3(5);
%             else
%                 app.Punto4(5)=s3(end);
%             end
            
            app.Punto4(5)=s3(end);
          
            valoresProceso4=CurvaIsobara(app.Punto1(1),app.Punto1(3),app.Punto1(5), app.Punto4(1),app.parametros(7), 200);                         
            s4=valoresProceso4.entropias;
            T4=valoresProceso4.temperaturas;     
                     
            s=[app.Punto1(5),app.Punto2(5),app.Punto3(5),app.Punto4(5)];
            T=[app.Punto1(1),app.Punto2(1),app.Punto3(1),app.Punto4(1)];
    
            % Diagrama p-h
            hold(app.UIAxes_PH,'on');
            plot(app.UIAxes_PH, x, y,'color','r','Marker','o','LineStyle','none');
            plot(app.UIAxes_PH, x1, y1,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, [app.Punto2(3),app.Punto3(3)], [app.Punto2(2),app.Punto3(2)],'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, x3, y3,'color','r','Marker','none','LineStyle','-');
            plot(app.UIAxes_PH, [app.Punto1(3),app.Punto4(3)], [app.Punto1(2),app.Punto4(2)],'color','r','Marker','none','LineStyle','-');

            hold(app.UIAxes_PH,'off');
            
            app.UIAxes_PH.XLimMode = 'auto';
            app.UIAxes_PH.YLimMode = 'auto';

            
            % Diagrama p-v
     
            
            hold(app.UIAxes_PV,'on');
            plot(app.UIAxes_PV, v, y,'color','b','Marker','o','LineStyle','none');
            plot(app.UIAxes_PV,  v1, y1,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, [v(2),v(3)], [app.Punto2(2),app.Punto3(2)],'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, v3, y3,'color','b','Marker','none','LineStyle','-');
            plot(app.UIAxes_PV, [v(1),v(4)], [app.Punto1(2),app.Punto4(2)],'color','b','Marker','none','LineStyle','-');

            hold(app.UIAxes_PV,'off');
            
            app.UIAxes_PV.XLimMode = 'auto';
            app.UIAxes_PV.YLimMode = 'auto';
%             
%             app.UIAxes_PV.XLabel.Interpreter = 'latex';
%             app.UIAxes_PV.XLabel.String='$\textrm(Volumen \quad  espec�fico) \quad  (m^{3}/kg)$';

%             ylabel(app.UIAxes_PV,'$\text(Volumen espec�fico )  (m^{3}/kg)$','Interpreter', 'latex');

            
            % Diagrama T-s
            
            hold(app.UIAxes_TS,'on');
            plot(app.UIAxes_TS, s, T,'color','g','Marker','o','LineStyle','none');
            plot(app.UIAxes_TS,  s1, T1,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s2, T2,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s3, T3,'color','g','Marker','none','LineStyle','-');
            plot(app.UIAxes_TS, s4,T4,'color','g','Marker','none','LineStyle','-');

            hold(app.UIAxes_TS,'off');
             
            app.UIAxes_TS.XLimMode = 'auto';
            app.UIAxes_TS.YLimMode = 'auto';

        end
        
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            app.UITable_Procesos.Data={'1-2','Compression';'2-3','Combustion chamber: heat-addition';...
               '3-4','Expansion';'4-1','Heat exchanger: heat-rejection'};
            app.UITable_Procesos.RowName={};
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
                        
            app.parametros = generadorParametros();
        end

        % Button pushed function: EjecutarButton_2
        function EjecutarButtonPushed(app, ~)
            format shortG
            
                        
            cla(app.UIAxes_PH)
            cla(app.UIAxes_PV)
            cla(app.UIAxes_TS)
            
            app.UITable_Resultados.Data={};         
            app.UITable_Resultados_2.Data={};              
            
            app.parametros = generadorParametros();           
            
            
            CeldaParametros=num2cell(app.parametros);
            [T1,p1,T3,p3,eficienciaTurbina,eficienciaCompresor,Cp,gamma,app.R]=deal(CeldaParametros{:});
            
            
            
            app.UITable_DatosIniciales.Data={1,p1,T1; 3,p3,T3};
            app.UITable_DatosIniciales.RowName={};
            app.UITable_Eficiencias.Data={eficienciaCompresor,eficienciaTurbina};
            app.UITable_ParametrosAire.Data={gamma,Cp};
            app.UITable_Referencia.Data={app.Treferencia,app.Preferencia,app.hreferencia,app.sreferencia};
        end

        % Button pushed function: MostrargrficosButton
        function MostrargrficosButtonPushed(app, ~)
            Diagramas(app);
        end

        % Button pushed function: MostrarresultadosButton
        function MostrarresultadosButtonPushed(app, ~)
            MostrargrficosButtonPushed(app, 'push');
            format shortG        
            
            app.UITable_Resultados.Data={1,app.Punto1(2),app.Punto1(1), app.Punto1(3),app.Punto1(5),app.Punto1(4);...
            2,app.Punto2(2),app.Punto2(1),app.Punto2(3),app.Punto2(5),app.Punto2(4);...
            3,app.Punto3(2),app.Punto3(1), app.Punto3(3),app.Punto3(5),app.Punto3(4);...
            4,app.Punto4(2),app.Punto4(1), app.Punto4(3),app.Punto4(5),app.Punto4(4)};
            
            
            app.UITable_Resultados_2.Data={app.solucion(9);app.solucion(10);app.solucion(8);app.solucion(7);app.solucion(11)};
 
            
            
        end

        % Button pushed function: Button_CondicionesAleatorias
        function Button_CondicionesAleatoriasPushed(app, ~)
            
            app.sreferencia=random('Uniform',0.8, 2); % Entrop�a del aire kJ/kg�K
            app.hreferencia=random('Uniform',100, 400); % Entalp�a del aire en kJ/kg
            app.Treferencia=random('Uniform',273.15,350); % En K
            app.Preferencia=random('Uniform',1,2.5); % En bar
            app.UITable_Referencia.Data={app.Treferencia,app.Preferencia,app.hreferencia,app.sreferencia};
            
        end

        % Button pushed function: Button_ReferenciaInicial
        function Button_ReferenciaInicialPushed(app, ~)
               
            app.sreferencia=1.73498; % Entrop�a del aire a 300 K y 1 bar en kJ/kg�K
            app.hreferencia=300.19; % Entalp�a del aire a 300 K y 1 bar en kJ/kg
            app.Treferencia=300; % En K
            app.Preferencia=1; % En bar
            app.UITable_Referencia.Data={app.Treferencia,app.Preferencia,app.hreferencia,app.sreferencia};
           
        end

        % Button pushed function: ExportarresultadosButton
        function ExportarresultadosButtonPushed(app, ~)
            Data=get(app.UITable_Resultados,'Data');
            ColumnName=get(app.UITable_Resultados,'ColumnName');
            ColumnName=ColumnName';
            NewData=num2cell(Data);
            T = cell2table(NewData,'VariableNames',ColumnName);
            writetable(T,'Datos del ciclo Brayton Simple.xls','Sheet','Datos Procesos');
            
            Data1=get(app.UITable_Resultados_2,'Data');
            ColumnName1=get(app.UITable_Resultados_2,'ColumnName');
            ColumnName1=ColumnName1';
            RowName1=get(app.UITable_Resultados_2,'RowName');
            RowName1=RowName1';
            NewData1=num2cell(Data1);
            T1= cell2table(NewData1,'VariableNames',ColumnName1,'RowNames',RowName1);
            writetable(T1,'Datos del ciclo Brayton Simple.xls','Sheet','Datos ciclo','WriteRowNames',true);

            
            Data2=get(app.UITable_Referencia,'Data');
            ColumnName2=get(app.UITable_Referencia,'ColumnName');
            ColumnName2=ColumnName2';
            NewData2=num2cell(Data2);
            T2 = cell2table(NewData2,'VariableNames',ColumnName2);
            writetable(T2,'Datos del ciclo Brayton Simple.xls','Sheet','Condiciones Referencia');
                       
            Data3=get(app.UITable_ParametrosAire,'Data');
            ColumnName3=get(app.UITable_ParametrosAire,'ColumnName');
            ColumnName3=ColumnName3';
            NewData3=num2cell(Data3);
            T3 = cell2table(NewData3,'VariableNames',ColumnName3);
            writetable(T3,'Datos del ciclo Brayton Simple.xls','Sheet','Propiedades Aire');
            
            Data4=get(app.UITable_Eficiencias,'Data');
            ColumnName4=get(app.UITable_Eficiencias,'ColumnName');
            ColumnName4=ColumnName4';
            NewData4=num2cell(Data4);
            T4 = cell2table(NewData4,'VariableNames',ColumnName4);
            writetable(T4,'Datos del ciclo Brayton Simple.xls','Sheet','Eficiencias Ciclo');
            
        end

        % Button pushed function: ParmetrostablasButton
        function ParmetrostablasButtonPushed(app, ~)
            app.parametros(7)=1.0532; 
            app.parametros(8)=1.3747;
            app.R=0.28705;
            app.UITable_ParametrosAire.Data={app.parametros(8),app.parametros(7)};
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 895 671];
            app.UIFigure.Name = 'Brayton Cycle';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 -1 895 673];

            % Create DatosInicialesTab
            app.DatosInicialesTab = uitab(app.TabGroup);
            app.DatosInicialesTab.Title = 'Initial values';

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.DatosInicialesTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontSize = 18;
            app.TextArea_3.FontWeight = 'bold';
            app.TextArea_3.Position = [73 565 327 30];
            app.TextArea_3.Value = {'Brayton Cycle'};

            % Create UITable_DatosIniciales
            app.UITable_DatosIniciales = uitable(app.DatosInicialesTab);
            app.UITable_DatosIniciales.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'};
            app.UITable_DatosIniciales.ColumnWidth = {70, 'auto', 'auto'};
            app.UITable_DatosIniciales.RowName = {''};
            app.UITable_DatosIniciales.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_DatosIniciales.FontWeight = 'bold';
            app.UITable_DatosIniciales.Position = [25 385 422 67];

            % Create TextArea_4
            app.TextArea_4 = uitextarea(app.DatosInicialesTab);
            app.TextArea_4.HorizontalAlignment = 'center';
            app.TextArea_4.FontSize = 18;
            app.TextArea_4.FontWeight = 'bold';
            app.TextArea_4.Position = [73 470 327 30];
            app.TextArea_4.Value = {'Initial values'};

            % Create UIAxes_PH
            app.UIAxes_PH = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PH, 'Diagram p-h')
            xlabel(app.UIAxes_PH, 'Enthalpy (kJ/kg)')
            ylabel(app.UIAxes_PH, 'Pressure (bar)')
            app.UIAxes_PH.Position = [583 437 300 185];

            % Create UIAxes_TS
            app.UIAxes_TS = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_TS, 'Diagram T-s')
            xlabel(app.UIAxes_TS, 'Entropy (kJ/kg�K)')
            ylabel(app.UIAxes_TS, 'Temperature (K)')
            app.UIAxes_TS.Position = [583 238 300 185];

            % Create UIAxes_PV
            app.UIAxes_PV = uiaxes(app.DatosInicialesTab);
            title(app.UIAxes_PV, 'Diagram p-v')
            xlabel(app.UIAxes_PV, 'Specific volume (m^3/kg) ')
            ylabel(app.UIAxes_PV, 'Pressure (bar)')
            app.UIAxes_PV.Position = [583 39 300 185];

            % Create Image
            app.Image = uiimage(app.DatosInicialesTab);
            app.Image.Position = [27 11 182 148];
            app.Image.ImageSource = 'Pollo Blanco.gif';

            % Create UITable_Referencia
            app.UITable_Referencia = uitable(app.DatosInicialesTab);
            app.UITable_Referencia.ColumnName = {'T (K)'; 'P (bar)'; 'h (kJ/kg)'; 's (kJ/kg�K)'};
            app.UITable_Referencia.RowName = {};
            app.UITable_Referencia.ForegroundColor = [0.4941 0.1843 0.5569];
            app.UITable_Referencia.FontWeight = 'bold';
            app.UITable_Referencia.Position = [238 225 345 45];

            % Create TextArea_6
            app.TextArea_6 = uitextarea(app.DatosInicialesTab);
            app.TextArea_6.HorizontalAlignment = 'center';
            app.TextArea_6.FontSize = 18;
            app.TextArea_6.FontWeight = 'bold';
            app.TextArea_6.Position = [291 273 237 30];
            app.TextArea_6.Value = {'Reference state'};

            % Create UITable_ParametrosAire
            app.UITable_ParametrosAire = uitable(app.DatosInicialesTab);
            app.UITable_ParametrosAire.ColumnName = {'Gamma'; 'Cp (kJ/kg�K)'};
            app.UITable_ParametrosAire.RowName = {};
            app.UITable_ParametrosAire.ForegroundColor = [0.8392 0.6706 0.2706];
            app.UITable_ParametrosAire.FontWeight = 'bold';
            app.UITable_ParametrosAire.Position = [27 250 203 45];

            % Create TextArea_7
            app.TextArea_7 = uitextarea(app.DatosInicialesTab);
            app.TextArea_7.HorizontalAlignment = 'center';
            app.TextArea_7.FontSize = 18;
            app.TextArea_7.FontWeight = 'bold';
            app.TextArea_7.Position = [29 298 198 30];
            app.TextArea_7.Value = {'Air-standard properties'};

            % Create UITable_Eficiencias
            app.UITable_Eficiencias = uitable(app.DatosInicialesTab);
            app.UITable_Eficiencias.ColumnName = {'Efic. compressor'; 'Efic. turbine'};
            app.UITable_Eficiencias.RowName = {};
            app.UITable_Eficiencias.ForegroundColor = [0.4667 0.6745 0.1882];
            app.UITable_Eficiencias.FontWeight = 'bold';
            app.UITable_Eficiencias.Position = [27 168 202 45];

            % Create EjecutarButton_2
            app.EjecutarButton_2 = uibutton(app.DatosInicialesTab, 'push');
            app.EjecutarButton_2.ButtonPushedFcn = createCallbackFcn(app, @EjecutarButtonPushed, true);
            app.EjecutarButton_2.Position = [186 518 100 22];
            app.EjecutarButton_2.Text = 'Run';

            % Create MostrargrficosButton
            app.MostrargrficosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrargrficosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrargrficosButtonPushed, true);
            app.MostrargrficosButton.Position = [66 360 103 22];
            app.MostrargrficosButton.Text = 'Show diagrams';

            % Create MostrarresultadosButton
            app.MostrarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.MostrarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @MostrarresultadosButtonPushed, true);
            app.MostrarresultadosButton.Position = [290 360 116 22];
            app.MostrarresultadosButton.Text = 'Show results';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Position = [226 95 303 48];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel.Text = {'2nd B.Sc. Chemical Engineering'; 'Applied Thermodynamics'};

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.FontAngle = 'italic';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Position = [226 62 303 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_2.Text = 'Gas power cycles';

            % Create TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3 = uilabel(app.DatosInicialesTab);
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.HorizontalAlignment = 'center';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontSize = 18;
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.FontWeight = 'bold';
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Position = [216 27 323 27];
            app.TermodinmicaAplicadaEjerciciosCicloBraytonLabel_3.Text = 'Prof. Juan Carlos Dom�nguez Toribio';

            % Create Button_CondicionesAleatorias
            app.Button_CondicionesAleatorias = uibutton(app.DatosInicialesTab, 'push');
            app.Button_CondicionesAleatorias.ButtonPushedFcn = createCallbackFcn(app, @Button_CondicionesAleatoriasPushed, true);
            app.Button_CondicionesAleatorias.Position = [251 200 135 22];
            app.Button_CondicionesAleatorias.Text = 'Change reference state';

            % Create Button_ReferenciaInicial
            app.Button_ReferenciaInicial = uibutton(app.DatosInicialesTab, 'push');
            app.Button_ReferenciaInicial.ButtonPushedFcn = createCallbackFcn(app, @Button_ReferenciaInicialPushed, true);
            app.Button_ReferenciaInicial.Position = [462 200 120 22];
            app.Button_ReferenciaInicial.Text = 'Initial reference state';

            % Create ExportarresultadosButton
            app.ExportarresultadosButton = uibutton(app.DatosInicialesTab, 'push');
            app.ExportarresultadosButton.ButtonPushedFcn = createCallbackFcn(app, @ExportarresultadosButtonPushed, true);
            app.ExportarresultadosButton.Position = [437 518 120 22];
            app.ExportarresultadosButton.Text = 'Export results';

            % Create ParmetrostablasButton
            app.ParmetrostablasButton = uibutton(app.DatosInicialesTab, 'push');
            app.ParmetrostablasButton.ButtonPushedFcn = createCallbackFcn(app, @ParmetrostablasButtonPushed, true);
            app.ParmetrostablasButton.Position = [35 225 180 22];
            app.ParmetrostablasButton.Text = 'Change Air-standard properties';

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Results';

            % Create UITable_Resultados
            app.UITable_Resultados = uitable(app.ResultadosTab);
            app.UITable_Resultados.ColumnName = {'State'; 'Pressure (bar)'; 'Temperature (K)'; 'Enthalpy (kJ/kg)'; 'Entropy (kJ/kg�K)'; 'Volume (m3/kg)'};
            app.UITable_Resultados.RowName = {};
            app.UITable_Resultados.Position = [37 460 620 110];

            % Create TextArea_5
            app.TextArea_5 = uitextarea(app.ResultadosTab);
            app.TextArea_5.HorizontalAlignment = 'center';
            app.TextArea_5.FontSize = 18;
            app.TextArea_5.FontWeight = 'bold';
            app.TextArea_5.Position = [150 589 355 30];
            app.TextArea_5.Value = {'Results of the cycle'};

            % Create UITable_Resultados_2
            app.UITable_Resultados_2 = uitable(app.ResultadosTab);
            app.UITable_Resultados_2.ColumnName = {'Heat and work exchanged'};
            app.UITable_Resultados_2.RowName = {'Q (inlet) (kJ/kg)'; 'Q (outlet) (kJ/kg)'; 'w (compressor) (kJ/kg)'; 'w (turbine) (kJ/kg)'; 'Thermal efficiency'};
            app.UITable_Resultados_2.Position = [37 299 343 133];

            % Create Image2
            app.Image2 = uiimage(app.ResultadosTab);
            app.Image2.ScaleMethod = 'fit';
            app.Image2.Position = [480 38 380 300];
            app.Image2.ImageSource = 'Ciclo Brayton.png';
% 
%             % Create Image3
%             app.Image3 = uiimage(app.ResultadosTab);
%             app.Image3.Position = [616 343 264 227];
%             app.Image3.ImageSource = 'CicloBrayton_Cerrado.png';

            % Create UITable_Procesos
            app.UITable_Procesos = uitable(app.ResultadosTab);
            app.UITable_Procesos.ColumnName = {'Process'; 'Description'};
            app.UITable_Procesos.ColumnWidth = {60, 'auto'};
            app.UITable_Procesos.RowName = {''};
            app.UITable_Procesos.ForegroundColor = [0 0.4471 0.7412];
            app.UITable_Procesos.FontWeight = 'bold';
            app.UITable_Procesos.FontSize = 14;
            app.UITable_Procesos.Position = [37 76 343 123];

            % Create TextArea_8
            app.TextArea_8 = uitextarea(app.ResultadosTab);
            app.TextArea_8.HorizontalAlignment = 'center';
            app.TextArea_8.FontSize = 18;
            app.TextArea_8.FontWeight = 'bold';
            app.TextArea_8.Position = [45 211 327 30];
            app.TextArea_8.Value = {'Processes'};

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = Brayton_Cycle

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end