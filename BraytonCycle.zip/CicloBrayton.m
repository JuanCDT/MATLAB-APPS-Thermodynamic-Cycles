function solucion=CicloBrayton(parametros,hreferencia)
    
    % hreferencia es la entalp�a de referencia a la entrada del compresor
    
    EntradaCompresor=parametros(1:2);
    EntradaTurbina=parametros(3:4);
    Eficiencias=parametros(5:6);
    Cp=parametros(7);
    gamma=parametros(8);
    
    h1=hreferencia;
    P1=EntradaCompresor(2); % En bar
    P2=EntradaTurbina(2); % En bar
    T1= EntradaCompresor(1);
    T3= EntradaTurbina(1);
    rp=P2/P1;
    
    % Calculo compresor
    [T2, h2, T2_ideal, w_compresor] = Compresor(T1, P1, h1, rp,Eficiencias(2), gamma, Cp);
    
    % Calculo caldera
    h3=h2+Cp*(T3-T2);
    Q_entrada=h3-h2;
    
    % Calculo turbina
    [T4,h4, T4_ideal, w_turbina] = Turbina(T3, P2, h3, rp,Eficiencias(1), gamma, Cp);
    
        
    % Calculo escape
    Q_salida=h4-h1;
    
        % C�lculo eficiencia t�rmica del ciclo
    Eficiencia_termica=1-Q_salida/Q_entrada; % en kJ/kg
    
    SalidaCompresor=[T2,P2, T2_ideal];
    SalidaTurbina=[T4,P1, T4_ideal];
    Trabajos=[w_turbina,w_compresor];
    Calores=[Q_entrada,Q_salida];
    solucion=[SalidaCompresor,SalidaTurbina,Trabajos,Calores,Eficiencia_termica];

   
end