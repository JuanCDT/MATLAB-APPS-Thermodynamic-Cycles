function valores=CurvaTrabajo(P_Inicial,rp, T_Inicial,s_inicial,h_inicial,Equipo, eficiencia, gamma, Cp, R, N_Puntos)
    
    % Equipo: valor 1 para compresores y 0 para turbinas
    % Valores de entrada
    % P en bar; T en K; s en kJ/kg�K; h en kJ/kg; Cp en kJ/kg�K
    
    
    %R=0.28705; % Para el aire en kJ/kg�K o (m3*Pa)/(K*kg)

    %temperaturas= linspace(T_Inicial,T_Final,N_Puntos); % Para diagramas P-v y P-h

   
    if Equipo==1  % C�lculo para un compresor    
        presiones= linspace(P_Inicial,P_Inicial*rp,N_Puntos);  % en bar (para diagramas T-s y se han de introducir en bar)
        relaciones_Presion=presiones./presiones(1);
    
        temperaturas_ideales=T_Inicial*(1./relaciones_Presion).^((1-gamma)/gamma); % en K
        entalpias_ideales=(temperaturas_ideales-temperaturas_ideales(1))*Cp+h_inicial;% en kJ/kg (si Cp en kJ/kg�K)
        trabajos_ideales=entalpias_ideales-entalpias_ideales(1); % en kJ/kg 
        entalpias=h_inicial+trabajos_ideales./eficiencia; % en kJ/kg 
        temperaturas=T_Inicial+(entalpias-entalpias(1))/Cp;  % en K
        volumen=R*1000*temperaturas./(presiones*1E5); % en m3/kg
        if eficiencia==1
            entropias=ones(N_Puntos)*s_inicial;
            else
            entropias=s_inicial+Cp*log((temperaturas./temperaturas(1)))-R*log(relaciones_Presion);
        end
     
    else  % C�lculo para una turbina    
        presiones= linspace(P_Inicial,P_Inicial/rp,N_Puntos);  % en bar (para diagramas T-s y se han de introducir en bar)
        relaciones_Presion=presiones(1)./presiones;
        
        temperaturas_ideales=T_Inicial*(relaciones_Presion).^((1-gamma)/gamma); % en K
        entalpias_ideales=h_inicial-(temperaturas_ideales(1)-temperaturas_ideales)*Cp;% en kJ/kg (si Cp en kJ/kg�K)
        trabajos_ideales=entalpias_ideales(1)-entalpias_ideales; % en kJ/kg 
        entalpias=h_inicial-trabajos_ideales.*eficiencia; % en kJ/kg 
        temperaturas=T_Inicial-(entalpias(1)-entalpias)/Cp;  % en K
        volumen=R*1000*temperaturas./(presiones*1E5); % en m3/kg
        
        if eficiencia==1
            entropias=ones(N_Puntos)*s_inicial;
            else
            entropias=s_inicial+Cp*log((temperaturas./temperaturas(1)))-R*log(1./relaciones_Presion);
        end
     
            
    end
        
    valores=struct();
    valores.presiones=presiones;
    valores.entalpias=entalpias;
    valores.volumen=volumen;
    valores.entropias=entropias;
    valores.temperaturas=temperaturas;
end